package com.alibaba.ad.code.hsf.consumer;

import org.springframework.context.annotation.Configuration;

import com.alibaba.boot.hsf.annotation.HSFConsumer;
import com.alibaba.ad.code.hsf.HelloService;

/**
 * hsf服务的统一个Config类，在其它需要使用的地方，直接@Autowired注入即可。详情见
 * https://gitlab.alibaba-inc.com/middleware-container/pandora-boot/wikis/spring-boot-hsf
 */
@Configuration
public class HsfConfig {

    @HSFConsumer
    private HelloService helloService;
}

