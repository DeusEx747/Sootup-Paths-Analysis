package com.alibaba.ad.code.dependencyAnalyzer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sootup.core.jimple.basic.Local;
import sootup.core.jimple.basic.Value;
import sootup.core.jimple.common.constant.Constant;
import sootup.core.jimple.common.expr.AbstractBinopExpr;
import sootup.core.jimple.common.expr.AbstractInvokeExpr;
import sootup.core.jimple.common.expr.JCastExpr;
import sootup.core.jimple.common.expr.JDynamicInvokeExpr;
import sootup.core.jimple.common.expr.JInstanceOfExpr;
import sootup.core.jimple.common.expr.JInterfaceInvokeExpr;
import sootup.core.jimple.common.expr.JLengthExpr;
import sootup.core.jimple.common.expr.JNegExpr;
import sootup.core.jimple.common.expr.JNewArrayExpr;
import sootup.core.jimple.common.expr.JNewExpr;
import sootup.core.jimple.common.expr.JNewMultiArrayExpr;
import sootup.core.jimple.common.expr.JSpecialInvokeExpr;
import sootup.core.jimple.common.expr.JStaticInvokeExpr;
import sootup.core.jimple.common.expr.JVirtualInvokeExpr;
import sootup.core.jimple.common.ref.JArrayRef;
import sootup.core.jimple.common.ref.JInstanceFieldRef;
import sootup.core.jimple.common.ref.JStaticFieldRef;
import sootup.core.jimple.common.stmt.JAssignStmt;
import sootup.core.jimple.common.stmt.JGotoStmt;
import sootup.core.jimple.common.stmt.JIdentityStmt;
import sootup.core.jimple.common.stmt.JIfStmt;
import sootup.core.jimple.common.stmt.JInvokeStmt;
import sootup.core.jimple.common.stmt.JReturnStmt;
import sootup.core.jimple.common.stmt.JReturnVoidStmt;
import sootup.core.jimple.common.stmt.JThrowStmt;
import sootup.core.jimple.common.stmt.Stmt;
import sootup.core.jimple.javabytecode.stmt.JSwitchStmt;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
public class CFGWithDependency {
    private static final Logger log = LoggerFactory.getLogger(CFGWithDependency.class);
    private String className;
    private String funcName;
    private String returnType;
    private ArrayList<String> parameter;
    private Map<Stmt, Integer> Stmt2LineMap;
    private String CSVNanme;
    private Map<Integer, Stmt> Line2StmtMap;
    public Map<Integer, Stmt> getLine2StmtMap(){
        return this.Line2StmtMap;
    }
    private ArrayList<ArrayList<nodeWithDependency>> routeList;
    public ArrayList<ArrayList<nodeWithDependency>> getRouteList(){
        return this.routeList;
    }
    public CFGWithDependency(Map<Stmt, Integer> Stmt2LineMap, Map<Integer, Stmt> Line2StmtMap, ArrayList<ArrayList<Integer>> routeList) {
        this.Stmt2LineMap = Stmt2LineMap;
        this.Line2StmtMap = Line2StmtMap;
        this.routeList = new ArrayList<ArrayList<nodeWithDependency>>();
        for (int i = 0; i < routeList.size(); i++) {
            this.routeList.add(new ArrayList<nodeWithDependency>());
            for (int j = 0; j < routeList.get(i).size(); j++) {
                nodeWithDependency node = new nodeWithDependency(routeList.get(i).get(j));
                this.routeList.get(i).add(node);
            }
        }
    }
    public CFGWithDependency(Map<Stmt, Integer> Stmt2LineMap, Map<Integer, Stmt> Line2StmtMap, ArrayList<ArrayList<Integer>> routeList,String csvName) {
        this.CSVNanme=csvName;
        this.Stmt2LineMap = Stmt2LineMap;
        this.Line2StmtMap = Line2StmtMap;
        this.routeList = new ArrayList<ArrayList<nodeWithDependency>>();
        for (int i = 0; i < routeList.size(); i++) {
            this.routeList.add(new ArrayList<nodeWithDependency>());
            for (int j = 0; j < routeList.get(i).size(); j++) {
                nodeWithDependency node = new nodeWithDependency(routeList.get(i).get(j));
                this.routeList.get(i).add(node);
            }
        }
    }
    public CFGWithDependency(Map<Stmt, Integer> Stmt2LineMap, Map<Integer, Stmt> Line2StmtMap, ArrayList<ArrayList<Integer>> routeList,String className,String funcName, String returnType,ArrayList<String> parameter) {
        this.Stmt2LineMap = Stmt2LineMap;
        this.Line2StmtMap = Line2StmtMap;
        this.routeList = new ArrayList<ArrayList<nodeWithDependency>>();
        this.className=className;
        this.funcName=funcName;
        this.returnType=returnType;
        this.parameter=parameter;
        for (int i = 0; i < routeList.size(); i++) {
            this.routeList.add(new ArrayList<nodeWithDependency>());
            for (int j = 0; j < routeList.get(i).size(); j++) {
                nodeWithDependency node = new nodeWithDependency(routeList.get(i).get(j));
                this.routeList.get(i).add(node);
            }
        }
    }
    public void analyse() {
        for (int i = 0; i < routeList.size(); i++) {
//            System.out.println(i + ":");
//            System.out.println();
            for (int j = 0; j < routeList.get(i).size(); j++) {
                //System.out.println(routeList.get(i).get(j).pathnode + ": " + Line2StmtMap.get(routeList.get(i).get(j).pathnode));
                analyseStmtDependency(this.routeList.get(i), j);
            }
//            System.out.println();
        }
    }
    public void analyseStmtDependency(ArrayList<nodeWithDependency> route, Integer index) {
        int pathnode = route.get(index).pathnode; // 实际的node节点号
        Stmt curStmt = Line2StmtMap.get(pathnode);
        ArrayList<Value> values = getStmtLocal(curStmt);//可能包含const，并不全是value
        values.removeIf(i -> i instanceof Constant);
        if (!values.isEmpty()) //System.out.println("发现依赖信息：");
            for (Value i : values) {
                int lastAssignIndex = findLastAssigned(route, index, i);
                int lastAssignPathnode=route.get(lastAssignIndex).pathnode;
                if (lastAssignIndex != -1) {//找到了上一个被赋值的语句
                    Dependency dependency = new Dependency(i, lastAssignIndex, Line2StmtMap.get(route.get(lastAssignIndex).pathnode),lastAssignPathnode);
                    route.get(index).dependencies.add(dependency);
                    //System.out.println("变量" + dependency.value + "上一次被赋值在: " + route.get(dependency.lastAssignIndex).pathnode + ": " + dependency.lastAssignStmt);
                }

//                int distance=index-lastAssignIndex;
//                System.out.println("cur:"+index+"  lasrassign:"+lastAssignIndex+"  distance="+distance);

            }
        //todo:methodsiginure
    }
    public ArrayList<Value> getStmtLocal(Stmt stmt) {
        //可能包含const，并不全是value，调用时可以用 values.removeIf(i -> i instanceof Constant);
        if (stmt instanceof JInvokeStmt) {
            JInvokeStmt jInvokeStmt = (JInvokeStmt) stmt;
            return getJinvokeStmtLocal(jInvokeStmt);
        } else if (stmt instanceof JAssignStmt) {
            JAssignStmt jAssignStmt = (JAssignStmt) stmt;
            return getJassignStmtLocal(jAssignStmt);
        } else if (stmt instanceof JThrowStmt) {
            JThrowStmt jThrowStmt = (JThrowStmt) stmt;
            return new ArrayList<>();
        } else if (stmt instanceof JIfStmt) {
            JIfStmt jIfStmt = (JIfStmt) stmt;
            return getJifStmtLocal(jIfStmt);
        } else if (stmt instanceof JSwitchStmt) {
            JSwitchStmt jSwitchStmt = (JSwitchStmt) stmt;
            return getJswitchStmtLocal(jSwitchStmt);
        } else if (stmt instanceof JReturnStmt) {
            JReturnStmt jReturnStmt = (JReturnStmt) stmt;
            return getJReturnStmtLocal(jReturnStmt);
        } else if (stmt instanceof JIdentityStmt || stmt instanceof JReturnVoidStmt || stmt instanceof JGotoStmt) {
            //这些语句不追踪
        } else {
            System.out.println(stmt);
            System.out.println("未覆盖到的语句：" + stmt.getClass());
        }
        return new ArrayList<>();
    }
    public ArrayList<Value> getJReturnStmtLocal(JReturnStmt jReturnStmt) {
        ArrayList<Value> values = new ArrayList<>();
        values.add(jReturnStmt.getOp());
        return values;
    }
    public ArrayList<Value> getJThrowStmtLocal(JThrowStmt jThrowStmt) {
        ArrayList<Value> values = new ArrayList<>();
        //todo:待完成
        return values;
    }
    public ArrayList<Value> getJswitchStmtLocal(JSwitchStmt jSwitchStmt) {
        ArrayList<Value> values = new ArrayList<>();
        values.add(jSwitchStmt.getKey());
        return values;
    }
    public ArrayList<Value> getJinvokeStmtLocal(JInvokeStmt jInvokeStmt) {
        ArrayList<Value> values = new ArrayList<>();
        if (jInvokeStmt.getInvokeExpr().get() instanceof JVirtualInvokeExpr) {
            JVirtualInvokeExpr jVirtualInvokeExpr = (JVirtualInvokeExpr) jInvokeStmt.getInvokeExpr().get();
            values.add(jVirtualInvokeExpr.getBase());
            values.addAll(jVirtualInvokeExpr.getArgs());
            return values;
        } else if (jInvokeStmt.getInvokeExpr().get() instanceof JSpecialInvokeExpr) {
            JSpecialInvokeExpr jSpecialInvokeExpr = (JSpecialInvokeExpr) jInvokeStmt.getInvokeExpr().get();
            values.add(jSpecialInvokeExpr.getBase());
            values.addAll(jSpecialInvokeExpr.getArgs());
            return values;
        } else if (jInvokeStmt.getInvokeExpr().get() instanceof JStaticInvokeExpr) {
            JStaticInvokeExpr jStaticInvokeExpr = (JStaticInvokeExpr) jInvokeStmt.getInvokeExpr().get();
            values.addAll(jStaticInvokeExpr.getArgs());
            return values;
        } else if (jInvokeStmt.getInvokeExpr().get() instanceof JInterfaceInvokeExpr) {
            JInterfaceInvokeExpr jInterfaceInvokeExpr = (JInterfaceInvokeExpr) jInvokeStmt.getInvokeExpr().get();
        } else if (jInvokeStmt.getInvokeExpr().get() instanceof JDynamicInvokeExpr) {
            JDynamicInvokeExpr jDynamicInvokeExpr = (JDynamicInvokeExpr) jInvokeStmt.getInvokeExpr().get();
        }
        return values;
    }
    public ArrayList<Value> getJinvokeExprLocal(AbstractInvokeExpr abstractInvokeExpr) {
        ArrayList<Value> values = new ArrayList<>();
        if (abstractInvokeExpr instanceof JVirtualInvokeExpr) {
            JVirtualInvokeExpr jVirtualInvokeExpr = (JVirtualInvokeExpr) abstractInvokeExpr;
            values.add(jVirtualInvokeExpr.getBase());
            values.addAll(jVirtualInvokeExpr.getArgs());
            return values;
        } else if (abstractInvokeExpr instanceof JSpecialInvokeExpr) {
            JSpecialInvokeExpr jSpecialInvokeExpr = (JSpecialInvokeExpr) abstractInvokeExpr;
            values.add(jSpecialInvokeExpr.getBase());
            values.addAll(jSpecialInvokeExpr.getArgs());
            return values;
        } else if (abstractInvokeExpr instanceof JStaticInvokeExpr) {
            JStaticInvokeExpr jStaticInvokeExpr = (JStaticInvokeExpr) abstractInvokeExpr;
            values.addAll(jStaticInvokeExpr.getArgs());
            return values;
        } else if (abstractInvokeExpr instanceof JInterfaceInvokeExpr) {
            JInterfaceInvokeExpr jInterfaceInvokeExpr = (JInterfaceInvokeExpr) abstractInvokeExpr;
        } else if (abstractInvokeExpr instanceof JDynamicInvokeExpr) {
            JDynamicInvokeExpr jDynamicInvokeExpr = (JDynamicInvokeExpr) abstractInvokeExpr;
        }
        return values;
    }
    public ArrayList<Value> getJifStmtLocal(JIfStmt jIfStmt) {
        ArrayList<Value> values = new ArrayList<>();
        values.add(jIfStmt.getCondition().getOp1());
        values.add(jIfStmt.getCondition().getOp2());// 都是立即数
        return values;
    }
    public ArrayList<Value> getJassignStmtLocal(JAssignStmt jAssignStmt) {
        ArrayList<Value> values = new ArrayList<>();
        if (jAssignStmt.getRightOp() instanceof Local) {
            Local local = (Local) jAssignStmt.getRightOp();
            values.add(local);
            return values;
        } else if (jAssignStmt.getRightOp() instanceof AbstractBinopExpr) {
            AbstractBinopExpr abstractBinopExpr = (AbstractBinopExpr) jAssignStmt.getRightOp();
            values.add(abstractBinopExpr.getOp1());
            values.add(abstractBinopExpr.getOp2());
            return values;
        } else if (jAssignStmt.getRightOp() instanceof AbstractInvokeExpr) {
            AbstractInvokeExpr abstractInvokeExpr = (AbstractInvokeExpr) jAssignStmt.getRightOp();
            return getJinvokeExprLocal(abstractInvokeExpr);
        } else if (jAssignStmt.getRightOp() instanceof JArrayRef) {
            JArrayRef jArrayRef = (JArrayRef) jAssignStmt.getRightOp();
            values.add(jArrayRef.getBase());// 追踪到定义处
            values.add(jArrayRef.getIndex());// 追踪index到上次出现（变量）
            return values;
        } else if (jAssignStmt.getRightOp() instanceof JInstanceFieldRef) {
            JInstanceFieldRef jInstanceFieldRef = (JInstanceFieldRef) jAssignStmt.getRightOp();
            if (!jInstanceFieldRef.getBase().toString().contains("this")) {
                values.add(jInstanceFieldRef.getBase());//只追踪实例，不追踪字段；
                return values;
            }
        } else if (jAssignStmt.getRightOp() instanceof JCastExpr) {
            JCastExpr jCastExpr = (JCastExpr) jAssignStmt.getRightOp();
            values.add(jCastExpr.getOp());
            return values;
        } else if (jAssignStmt.getRightOp() instanceof JInstanceOfExpr) {
            JInstanceOfExpr jInstanceOfExpr = (JInstanceOfExpr) jAssignStmt.getRightOp();
            values.add(jInstanceOfExpr.getOp());
            return values;
        } else if (jAssignStmt.getRightOp() instanceof JStaticFieldRef) {
            //静态字段，不追踪
        } else if (jAssignStmt.getRightOp() instanceof Constant) {
            //常量不追踪
        } else if (jAssignStmt.getRightOp() instanceof JNewArrayExpr) {
            JNewArrayExpr jNewArrayExpr = (JNewArrayExpr) jAssignStmt.getRightOp();
            values.add(jNewArrayExpr.getSize());
            return values;
        } else if (jAssignStmt.getRightOp() instanceof JNewExpr) {
            //无变量 不追踪
        } else if (jAssignStmt.getRightOp() instanceof JLengthExpr) {
            JLengthExpr jLengthExpr = (JLengthExpr) jAssignStmt.getRightOp();
            values.add(jLengthExpr.getOp());
            return values;
        } else if (jAssignStmt.getRightOp() instanceof JNegExpr) {
            JNegExpr jNegExpr = (JNegExpr) jAssignStmt.getRightOp();
            values.add(jNegExpr.getOp());
            return values;
        } else if (jAssignStmt.getRightOp() instanceof JNewMultiArrayExpr) {
            JNewMultiArrayExpr jNewMultiArrayExpr = (JNewMultiArrayExpr) jAssignStmt.getRightOp();
            values.addAll(jNewMultiArrayExpr.getSizes());
            return values;
        } else {
            System.out.println(jAssignStmt);
            System.out.println("未覆盖的类型：" + jAssignStmt.getRightOp().getClass());
        }
        return values;
    }
    public int findLastAssigned(ArrayList<nodeWithDependency> route, Integer curIndexOfroute, Value value) {
        for (int i = curIndexOfroute - 1; i >= 0; i--) {
            Stmt stmt = Line2StmtMap.get(route.get(i).pathnode);
            if (stmt instanceof JAssignStmt) {
                JAssignStmt jAssignStmt = (JAssignStmt) stmt;
                if (jAssignStmt.getLeftOp().toString().equals(value.toString())) {
                    return i;
                }
            } else if (stmt instanceof JIdentityStmt) {
                JIdentityStmt jIdentityStmt = (JIdentityStmt) stmt;
                if (jIdentityStmt.getLeftOp().toString().equals(value.toString())) {
                    return i;
                }
            }
        }
        return -1;
    }
    public static <V> V[] mapValuesToArray(Map<?, V> map) {
        // 获取 Map 的值集合
        Collection<V> values = map.values();
        // 创建一个数组并将值复制到数组中
        // 注意通过泛型数组辅助函数创建正确类型的数组
        V[] array = values.toArray((V[]) java.lang.reflect.Array.newInstance(values.iterator().next().getClass(), values.size()));
        return array;
    }
    public static String MethodEmbeddingWithDEP(String className, String functionName, String returnType, List<String> paramTypes){
        return "_CFGWithDep_"
                +"_CLASSNAME_" + className.replace('<', '_').replace('[', '+').replace(']', '+').replace('>', '_').replace(", ", "+")
                + "_FUNCTIONNAME_" + functionName.replace('<', '_').replace('>', '_').replace('[', '+').replace(']', '+').replace(", ", "+")
                + "_RETURNTYPE_" + returnType.replace('<', '_').replace('>', '_').replace('[', '+').replace(']', '+').replace(", ", "+")
                + "_Parameters_" + paramTypes.toString().replace('<', '_').replace('>', '_').replace('[', '+').replace(']', '+').replace(", ", "+");
    }
    public static void CFGWithDependency2CSV(CFGWithDependency cfgWithDependency){
        String directoryPath = "./Dependency";
        String filePath = directoryPath + "/"+cfgWithDependency.CSVNanme;
        // 检查并创建目录
        try {
            Path path = Paths.get(directoryPath);
            if (!Files.exists(path)) {
                Files.createDirectories(path);
            }
        } catch (IOException e) {
            System.err.println("Failed to create directory: " + e.getMessage());
            return;
        }
        // 创建并写入CSV文件
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            // 写入列标题
            writer.write("routeId,nodeId,stmt,dependency");
            writer.newLine();

            for (ArrayList<nodeWithDependency> route : cfgWithDependency.getRouteList()) {
                String routeId = cfgWithDependency.getRouteList().indexOf(route) + "";
                for (nodeWithDependency node : route) {
                    String nodeId = node.pathnode + "";
                    String stmt = cfgWithDependency.getLine2StmtMap().get(node.pathnode) + "";
                    String dependency = node.getDependencyInf();

                    // 转义字段
                    String escapedRouteId = escapeCsvField(routeId);
                    String escapedNodeId = escapeCsvField(nodeId);
                    String escapedStmt = escapeCsvField(stmt);
                    String escapedDependency = escapeCsvField(dependency);

                    // 拼接 CSV 行
                    String line = String.join(",",
                            escapedRouteId,
                            escapedNodeId,
                            escapedStmt,
                            escapedDependency
                    );
                    writer.write(line);
                    writer.newLine();
                }
            }

            System.out.println("CSV file created successfully at: " + filePath);
        } catch (IOException e) {
            System.err.println("Failed to create CSV file: " + e.getMessage());
        }

/**
 * 转义CSV字段：处理逗号、双引号、换行符
 */
    }
    private static String escapeCsvField(String field) {
        if (field == null) return "";
        if (field.contains(",") || field.contains("\"") || field.contains("\n")) {
            field = field.replace("\"", "\"\"");
            return "\"" + field + "\"";
        }
        return field;
    }
    public String getDepInf(int routeID){
        String DepInf="";
        for(nodeWithDependency node:this.routeList.get(routeID)){
            DepInf=DepInf+node.getDependencyInf();
        }
        return DepInf;
    }
    public static void main(String[] args) {
//        CFGGeneration cfgGeneration = new CFGGeneration();
//        cfgGeneration.AllCfgGenerate("cfg_generation/target/classes");
//        System.out.println("******************************************进行依赖分析**********************************");
//        Set<Map.Entry<String,CFGGeneration>> cfg_set=cfgGeneration.getAllFuncMethodMap().entrySet();
//        CFGWithDependency cfgWithDependency;
//        for(Map.Entry<String,CFGGeneration> cfg:cfg_set){
//            File file = new File("./Dependency/"+"_CFGDependency_"+cfg.getKey()+".csv");
//            // 检查文件是否存在
//            if (file.exists()) {
//                System.out.println("文件存在");
//                continue;
//            }else if(cfg.getValue().toolarge){
//                System.out.println("文件过大");
//                continue;
//            }
//            if(cfg.getValue().getRouteList().size()<500000){
//                cfgWithDependency= new CFGWithDependency(cfg.getValue().getStmt2LineMap(), cfg.getValue().getLine2StmtMap(), cfg.getValue().getRouteList(),"_CFGDependency_"+cfg.getKey()+".csv");
//                cfgWithDependency.analyse();
//                CFGWithDependency.CFGWithDependency2CSV(cfgWithDependency);
//                cfgWithDependency=null;
//            }else{
//                System.out.println("**************************************************************************");
//                System.out.println("路径数："+cfg.getValue().getRouteList().size());
//            }
//        }
    }
}
