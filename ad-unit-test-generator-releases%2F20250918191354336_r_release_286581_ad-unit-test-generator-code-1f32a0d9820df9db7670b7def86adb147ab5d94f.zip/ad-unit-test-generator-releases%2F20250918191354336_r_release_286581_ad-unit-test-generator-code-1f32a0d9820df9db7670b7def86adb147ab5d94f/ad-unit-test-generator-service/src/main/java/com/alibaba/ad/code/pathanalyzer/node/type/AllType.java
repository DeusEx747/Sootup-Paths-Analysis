package com.alibaba.ad.code.pathanalyzer.node.type;

public enum AllType {
    // 条件语句
    IF,
    ELSE,
    ELSE_IF,
    SWITCH,
    SWITCH_EXPRESSION, // Java 12+
    TERNARY_OPERATOR, // ? :

    // 循环结构
    FOR,
    ENHANCED_FOR, // for-each loop
    WHILE,
    DO_WHILE,

    // 跳转语句
    BREAK,
    CONTINUE,
    RETURN,
    GOTO,

    // 异常处理
    TRY,
    CATCH,
    FINALLY,
    TRY_WITH_RESOURCES, // Java 7+

    // 其他控制流相关
    LABELED_STATEMENT,
    ASSERT,
    THROW,

    // 方法调用
    METHOD_INVOCATION,

    //默认
    DEFULT
}
