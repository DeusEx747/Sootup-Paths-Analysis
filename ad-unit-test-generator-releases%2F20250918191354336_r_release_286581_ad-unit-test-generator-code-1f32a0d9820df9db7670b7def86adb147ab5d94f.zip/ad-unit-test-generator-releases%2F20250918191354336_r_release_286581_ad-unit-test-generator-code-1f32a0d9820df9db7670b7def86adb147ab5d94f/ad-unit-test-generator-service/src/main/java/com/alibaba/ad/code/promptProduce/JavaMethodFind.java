package com.alibaba.ad.code.promptProduce;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
public class JavaMethodFind {

    public static boolean hasCommonSubstring(String str1, String str2) {
        int[][] dp = new int[str1.length() + 1][str2.length() + 1];
        int maxLength = 0;

        for (int i = 1; i <= str1.length(); i++) {
            for (int j = 1; j <= str2.length(); j++) {
                if (str1.charAt(i-1) == str2.charAt(j-1)) {
                    dp[i][j] = dp[i-1][j-1] + 1;
                    maxLength = Math.max(maxLength, dp[i][j]);
                }
            }
        }

        return maxLength > 0;
    }

    public boolean ExistMethod(String input) {
        try {
            // 1. 解析输入字符串，获取类名和方法名
            String className = extractClassName(input);
            String methodName = extractMethodName(input);
            String returnType= extractReturnType(input);

            // 2. 将类名转换为文件路径
            String filePath = convertClassNameToPath(className);

            // 3. 读取Java文件并查找方法
            try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    // 检查是否包含目标方法
                    if (line.contains(methodName)) {
                        // 确认是方法定义而不是方法调用且必须是public,且返回值一样
                        if (line.contains("(") && (line.contains("public")) && (line.contains("handle")) && JavaMethodFind.hasCommonSubstring(line,returnType)) {
                            return true;
                        }
                    }
                }
            }

            // 没有找到对应的方法
            return false;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean ExistMethod(String taskCreateTime,String input) {
        try {
            // 1. 解析输入字符串，获取类名和方法名
            String className = extractClassName(input);
            String methodName = extractMethodName(input);
            String returnType= extractReturnType(input);

            // 2. 将类名转换为文件路径
            String filePath = convertClassNameToPath(taskCreateTime,className);


            // 3. 读取Java文件并查找方法
            try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    // 检查是否包含目标方法
                    if (line.contains(methodName)) {
                        // 确认是方法定义而不是方法调用且必须是public,且返回值一样
                        if (line.contains("(") && (line.contains("public")) && (line.contains("handle")) && JavaMethodFind.hasCommonSubstring(line,returnType)) {
                            return true;
                        }
                    }
                }
            }
            catch (Exception e) {
                System.out.println();
                System.out.println("!!!!!!!!!!!!!filePath:"+filePath);
            }

            // 没有找到对应的方法
            return false;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public String getClassContent(String input){
        try {
            // 1. 解析输入字符串，获取类名
            String className = extractClassName(input);
            String methodName = extractMethodName(input);
            // 2. 将类名转换为文件路径
            String filePath = convertClassNameToPath(className);

            // 3. 读取Java文件
            StringBuilder content = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
                String line;
                boolean isInTargetMethod = false;
                int braceCount = 0;
                while ((line = reader.readLine()) != null) {
                    content.append(line).append("\n");
                }
            }
            return content.toString();

        } catch (Exception e) {
            e.printStackTrace();
            return "Error: " + e.getMessage();
        }
    }

    private String convertClassNameToPath(String className) throws IOException {
        // 假设源代码根目录在某个固定位置，需要根据实际情况修改
        //String sourceRoot = "brand-onebp-domain/src/main/java/";
        String targetContent = new String(Files.readAllBytes(Paths.get("./src/main/java/com/alibaba/config/target.json")));
        JSONObject targetJson = new JSONObject(targetContent);
        String sourceRoot = targetJson.getString("java_path");
        if(!sourceRoot.endsWith("/")){
            sourceRoot=sourceRoot+"/";
        }
        return sourceRoot + className.replace('.', '/') + ".java";
    }

    public String getClassContent(String testCreateTime,String input){
        try {
            // 1. 解析输入字符串，获取类名
            String className = extractClassName(input);
//            String methodName = extractMethodName(input);
            // 2. 将类名转换为文件路径
            String filePath = convertClassNameToPath(testCreateTime,className);

            // 3. 读取Java文件
            StringBuilder content = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
                String line;
                boolean isInTargetMethod = false;
                int braceCount = 0;
                while ((line = reader.readLine()) != null) {
                    content.append(line).append("\n");
                }
            }
            return content.toString();

        } catch (Exception e) {
            e.printStackTrace();
            return "Error: " + e.getMessage();
        }
    }

    public String getMethodContent(String TaskCreateTime,String input) {
        try {
            // 1. 解析输入字符串，获取类名
            String className = extractClassName(input);
            String methodName = extractMethodName(input);
            // 2. 将类名转换为文件路径
            String filePath = convertClassNameToPath(TaskCreateTime,className);

            // 3. 读取Java文件
            StringBuilder content = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
                String line;
                boolean isInTargetMethod = false;
                int braceCount = 0;

                while ((line = reader.readLine()) != null) {
                    // 寻找目标方法的开始
                    if (!isInTargetMethod && line.contains(methodName)) {
                        if (line.contains("(") && (line.contains("public") || line.contains("private") || line.contains("protected"))) {
                            isInTargetMethod = true;
                            braceCount = 0;
                            content.append(line).append("\n");
                            if (line.contains("{")) {
                                braceCount++;
                            }
                            continue;
                        }
                    }

                    // 如果已经在目标方法内
                    if (isInTargetMethod) {
                        content.append(line).append("\n");
                        braceCount += countChar(line, '{');
                        braceCount -= countChar(line, '}');

                        // 如果花括号配对完成，说明方法结束
                        if (braceCount == 0) {
                            break;
                        }
                    }
                }
            }

            return content.toString();

        } catch (Exception e) {
            e.printStackTrace();
            return "Error: " + e.getMessage();
        }
    }

    public  String extractClassName(String input) {
        // 假设类名在_CLASSNAME_和第一个_FUNCTIONNAME_之间
        int startIndex = input.indexOf("_CLASSNAME_") + "_CLASSNAME_".length();
        int endIndex = input.indexOf("_FUNCTIONNAME_");
        if (startIndex >= 0 && endIndex >= 0) {
            return input.substring(startIndex, endIndex);
        }
        return null;
//        throw new IllegalArgumentException("Invalid input format: Cannot find class name");
    }
    public String extractReturnType(String input) {
        // 假设类名在_CLASSNAME_和第一个_FUNCTIONNAME_之间
        int startIndex = input.indexOf("_RETURNTYPE_") + "_RETURNTYPE_".length();
        int endIndex = input.indexOf("_Parameters_");
        if (startIndex >= 0&& endIndex >= 0) {
            return input.substring(startIndex, endIndex);
        }
        return null;
    }

    public String extractMethodName(String input) {
        // 假设方法名在_FUNCTIONNAME_和_RETURNTYPE_之间
        int startIndex = input.indexOf("_FUNCTIONNAME_") + "_FUNCTIONNAME_".length();
        int endIndex = input.indexOf("_RETURNTYPE_");
        if (startIndex >= 0 && endIndex >= 0) {
            return input.substring(startIndex, endIndex);
        }
        throw new IllegalArgumentException("Invalid input format: Cannot find method name"+input);
    }


    private String convertClassNameToPath(String taskCreateTime,String className) throws IOException {
        // 假设源代码根目录在某个固定位置，需要根据实际情况修改
        //String sourceRoot = "brand-onebp-domain/src/main/java/";
        String targetContent = new String(Files.readAllBytes(Paths.get(taskCreateTime+"/target.json")));
        JSONObject targetJson = new JSONObject(targetContent);
        String sourceRoot = targetJson.getString("java_path");
        if(!sourceRoot.endsWith("/")){
            sourceRoot=sourceRoot+"/";
        }
        return sourceRoot + className.replace('.', '/') + ".java";
    }

    private int countChar(String str, char target) {
        return (int) str.chars().filter(ch -> ch == target).count();
    }

    // 使用示例
    public static void main(String[] args) {
    }

}
