package com.alibaba.ad.code.cfganalyser.code.util;

import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import com.google.common.collect.Sets;
import org.apache.commons.collections4.CollectionUtils;
import sootup.core.types.ClassType;
import sootup.java.core.AnnotationUsage;
import sootup.java.core.JavaSootClass;

/**
 * @author guoliang
 * @date 2025/08/19
 */
public class ClassFilterUtil {

    /**
     * 返回false当sootClass没有特定注解
     *
     * @param sootClass      sootClass
     * @param hasAnnotations 目标类需要实现的注解
     * @return boolean
     */
    public static boolean hasAnnotation(JavaSootClass sootClass, Set<String> hasAnnotations) {
        // 根据注解过滤
        if (CollectionUtils.isNotEmpty(hasAnnotations)) {
            // 将sootClass.getAnnotations()转为stream并转为string集合
            Set<String> annotationSet = StreamSupport.stream(sootClass.getAnnotations().spliterator(), false)
                .map(AnnotationUsage::getAnnotation)
                .map(ClassType::getFullyQualifiedName)
                .collect(Collectors.toSet());
            // 如果hasAnnotations和annotationSet没有交集，则跳过
            if (Sets.intersection(hasAnnotations, annotationSet).isEmpty()) {
                return false;
            }
        }
        return true;
    }

    /**
     * 返回false当sootClass没有实现特定接口
     *
     * @param sootClass           sootClass
     * @param implementInterfaces 目标类需要实现的接口
     * @return boolean
     */
    public static boolean implementInterfaces(JavaSootClass sootClass, Set<String> implementInterfaces) {
        // 根据接口过滤类
        if (CollectionUtils.isNotEmpty(implementInterfaces)) {
            Set<? extends ClassType> classInterfaces = sootClass.getInterfaces();
            // 将sootClass.getInterfaces()转为stream并转为string集合
            Set<String> interfaceSet = classInterfaces.stream()
                .map(ClassType::getFullyQualifiedName)
                .collect(Collectors.toSet());
            // 如果implementInterfaces和interfaceSet没有交集，则跳过
            if (Sets.intersection(implementInterfaces, interfaceSet).isEmpty()) {
                return false;
            }
        }
        return true;
    }

    /**
     * 返回false当sootClass不是目标类
     *
     * @param sootClass   sootClass
     * @param classNames 目标类
     * @return boolean
     */
    public static boolean isTargetClass(JavaSootClass sootClass, Set<String> classNames) {
        if (CollectionUtils.isNotEmpty(classNames)) {
            return classNames.contains(sootClass.getName());
        }
        return true;
    }

}
