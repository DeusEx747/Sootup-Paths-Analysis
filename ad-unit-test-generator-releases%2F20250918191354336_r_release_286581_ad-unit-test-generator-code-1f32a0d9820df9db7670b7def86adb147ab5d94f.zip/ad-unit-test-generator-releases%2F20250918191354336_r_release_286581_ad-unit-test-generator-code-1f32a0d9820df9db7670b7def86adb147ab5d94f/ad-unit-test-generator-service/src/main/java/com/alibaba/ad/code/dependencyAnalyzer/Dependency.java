package com.alibaba.ad.code.dependencyAnalyzer;

import sootup.core.jimple.basic.Value;
import sootup.core.jimple.common.stmt.Stmt;
import sootup.core.signatures.MethodSignature;

public class Dependency {
    public String type;
    public Value value;
    public MethodSignature methodSignature;
    public int lastAssignIndex;//route中的index
    public Stmt lastAssignStmt;
    public int lastAssignPathnode;
    public Dependency(Value value,int lastAssignIndex,Stmt lastAssignStmt,int lastAssignPathnode){
        this.value=value;
        this.lastAssignIndex=lastAssignIndex;
        this.lastAssignStmt=lastAssignStmt;
        this.lastAssignPathnode=lastAssignPathnode;
        this.type="I";
    }
    public Dependency(MethodSignature methodSignature){
        this.methodSignature=methodSignature;
        this.type="m";
    }


}
