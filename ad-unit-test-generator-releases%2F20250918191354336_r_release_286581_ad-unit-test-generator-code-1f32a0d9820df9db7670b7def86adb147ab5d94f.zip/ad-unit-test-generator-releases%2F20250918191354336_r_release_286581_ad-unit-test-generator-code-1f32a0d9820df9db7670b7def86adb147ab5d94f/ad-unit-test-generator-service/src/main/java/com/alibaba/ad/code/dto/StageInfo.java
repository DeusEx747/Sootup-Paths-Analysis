package com.alibaba.ad.code.dto;

import lombok.Data;

/**
 * 各类信息
 *
 * @author zhangheng
 */
@Data
public class StageInfo {

    private String savePath;

    private String data;

}
