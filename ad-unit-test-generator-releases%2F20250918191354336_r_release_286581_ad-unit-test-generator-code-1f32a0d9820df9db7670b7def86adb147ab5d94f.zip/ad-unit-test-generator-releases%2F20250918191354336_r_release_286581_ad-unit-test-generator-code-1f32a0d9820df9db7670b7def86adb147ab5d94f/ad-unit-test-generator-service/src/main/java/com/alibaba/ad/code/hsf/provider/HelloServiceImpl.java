package com.alibaba.ad.code.hsf.provider;

import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.ad.code.hsf.HelloService;

/**
 * 通过HSFProvider声明一个HSF服务,详情见 https://gitlab.alibaba-inc.com/middleware-container/pandora-boot/wikis/spring-boot-hsf
 */
@HSFProvider(serviceInterface = HelloService.class)
public class HelloServiceImpl implements HelloService {

    @Override
    public String sayHello(String name) {
        return "Hello, " + name;
    }
}

