package com.alibaba.ad.code.pathanalyzer.node.type;

/**
 * 表示路径分析系统中节点的类型。
 * 这个类封装了一个 {@link AllType} 枚举值，并提供了与之交互的方法。
 */
public class Type {
    /** 默认节点类型 */
    private AllType nodeType = AllType.DEFULT;

    /**
     * 使用指定的节点类型构造一个新的 Type 对象。
     *
     * @param nodeType 要设置的 AllType 枚举值
     */
    public Type(AllType nodeType) {
        this.nodeType = nodeType;
    }

    /**
     * 检查这个 Type 是否匹配指定的 AllType。
     *
     * @param type 要比较的 AllType
     * @return 如果这个 Type 的 nodeType 匹配指定的 type，则返回 true，否则返回 false
     */
    public boolean isThisType(AllType type) {
        return this.nodeType == type;
    }

    /**
     * 获取当前的节点类型。
     *
     * @return 这个 Type 的当前 AllType 值
     */
    public AllType getNodeType() {
        return nodeType;
    }

    /**
     * 将节点类型设置为新值。
     *
     * @param nodeType 要设置的新 AllType 值
     */
    public void setNodeType(AllType nodeType) {
        this.nodeType = nodeType;
    }

    /**
     * 返回这个 Type 的字符串表示。
     *
     * @return nodeType 枚举值的名称
     */
    @Override
    public String toString() {
        return nodeType.name();
    }

    /**
     * 检查这个 Type 是否等于另一个对象。
     *
     * @param obj 要比较的对象
     * @return 如果对象相等则返回 true，否则返回 false
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Type type = (Type) obj;
        return nodeType == type.nodeType;
    }

    /**
     * 为这个 Type 生成哈希码。
     *
     * @return 这个 Type 的哈希码值
     */
    @Override
    public int hashCode() {
        return nodeType.hashCode();
    }
}
