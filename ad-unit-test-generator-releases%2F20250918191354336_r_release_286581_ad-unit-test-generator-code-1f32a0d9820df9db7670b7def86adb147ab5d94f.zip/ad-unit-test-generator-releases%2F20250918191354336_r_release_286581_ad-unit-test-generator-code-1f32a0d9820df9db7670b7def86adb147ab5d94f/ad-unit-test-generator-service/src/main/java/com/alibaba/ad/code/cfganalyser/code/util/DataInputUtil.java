package com.alibaba.ad.code.cfganalyser.code.util;

import com.alibaba.ad.code.logger.Logger;
import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Objects;

public class DataInputUtil {

    private static final String dataMethodType = "DATA_CONSTRUCTOR";
    private static boolean DEBUG_MODE = true;
    private static final Logger logger = Logger.getInstance();

    static {
        Path globalJsonPath = Paths.get("./src/main/java/com/alibaba/config/global.json");
        JSONObject globalJson;

        if (Files.exists(globalJsonPath)) {
            // 如果文件存在，读取它
            String globalContent = null;
            try {
                globalContent = new String(Files.readAllBytes(globalJsonPath));
                globalJson = new JSONObject(globalContent);
                DEBUG_MODE = globalJson.getBoolean("debug_mode");
            } catch (Exception ignored) {}
        }
    }

    public static void transCsvFileToPrompt(){

        Path globalJsonPath = Paths.get("./src/main/java/com/alibaba/config/target.json");
        Path errorReportPath = Paths.get("D:/Java/WorkProject/python/test-inputs-outputs-set-generation/route_analyze_result.csv");
        JSONObject globalJson;

        try{
            if (Files.exists(globalJsonPath)) {
                String globalContent = new String(Files.readAllBytes(globalJsonPath));
                globalJson = new JSONObject(globalContent);
                String pythonWordDir = globalJson.getString("python_project_directory");
                errorReportPath = Paths.get(pythonWordDir,"route_analyze_result.csv");
            }
        }catch (Exception ignored){}

        ArrayList<ArrayList<String>> allColumnValueList = new ArrayList<>();
        try (CSVReader reader = new CSVReader(new FileReader(String.valueOf(errorReportPath)))) {
            // 跳过标题行
            reader.readNext();
            String[] nextLine;
            while ((nextLine = reader.readNext()) != null) {
                if (nextLine.length > 0) {
                    ArrayList<String> addLine = new ArrayList<>(Arrays.asList(nextLine));
                    allColumnValueList.add(addLine);
                }
            }
        } catch (IOException | CsvValidationException e) {
            System.err.println("读取文件时发生错误: " + e.getMessage());
        }

        File directory = Paths.get("./Output/stage1").toFile();
        for (File file : Objects.requireNonNull(directory.listFiles())) {
            if (file.isDirectory()) {
                deleteDirectory(file);
            } else {
                boolean success = file.delete();
                if(!success) System.err.println("WARN: delete stage1 file fail!");
            }
        }

        for(ArrayList<String> informationList : allColumnValueList){
            String className = informationList.get(0);
            String dirName = informationList.get(1);
            String routeIndex = informationList.get(informationList.size() - 1);
            String problemType = informationList.get(6);
            String newData = informationList.get(2);
            if(DEBUG_MODE){
                System.out.println("className:" + className);
                System.out.println("dirName:" + dirName);
                System.out.println("routeIndex:" + routeIndex);
                System.out.println("problemType:" + problemType);
                System.out.println("newData:" + newData);
            }
            if(problemType.equals(DataInputUtil.dataMethodType)){
                File file = new File("./Output/stage1/" + dirName + "/"+ routeIndex + ".json");
                file.getParentFile().mkdirs();

                try (FileWriter writer = new FileWriter(file)) {
                    writer.write(newData);
                    System.out.println("内容已成功写入文件：" + file.getPath());
                } catch (IOException e) {
                    System.err.println(e.getMessage());
                }
            }
        }
    }

    public static void deleteDirectory(File dir) {
        if (dir.isDirectory()) {
            for (File child : Objects.requireNonNull(dir.listFiles())) {
                deleteDirectory(child);
            }
        }
        dir.delete();
    }

    public static void main(String[] args){
        DataInputUtil.transCsvFileToPrompt();
    }
}
