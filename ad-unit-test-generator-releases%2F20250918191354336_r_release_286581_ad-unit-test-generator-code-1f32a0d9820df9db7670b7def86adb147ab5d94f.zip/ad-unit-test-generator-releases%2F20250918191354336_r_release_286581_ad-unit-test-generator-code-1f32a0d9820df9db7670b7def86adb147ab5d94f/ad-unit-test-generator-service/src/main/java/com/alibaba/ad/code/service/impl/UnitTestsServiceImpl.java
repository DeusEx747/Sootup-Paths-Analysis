package com.alibaba.ad.code.service.impl;

import com.alibaba.ad.code.cfganalyser.code.CFGGeneration;
import com.alibaba.ad.code.cfganalyser.code.DependencyGeneration;
import com.alibaba.ad.code.cfganalyser.code.util.DataInputUtil;
import com.alibaba.ad.code.cfganalyser.code.util.PathRouteUtil;
import com.alibaba.ad.code.diamond.AppNameRepositoryDiamond;
import com.alibaba.ad.code.dto.ResultDTO;
import com.alibaba.ad.code.dto.StageInfo;
import com.alibaba.ad.code.http.HttpComponent;
import com.alibaba.ad.code.oss.OssComponent;
import com.alibaba.ad.code.promptProduce.PathUtils;
import com.alibaba.ad.code.promptProduce.Stage1;
import com.alibaba.ad.code.promptProduce.Stage2;
import com.alibaba.ad.code.promptProduce.JavaMethodFind;
import com.alibaba.ad.code.service.UnitTestsService;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.normandy.credential.CredentialProvider;
import com.alibaba.normandy.credential.CredentialProviderFactory;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;

/**
 * @author jys
 * @date 2025/7/29 11:40
 */
@Slf4j
@HSFProvider(serviceInterface = UnitTestsService.class, clientTimeout = 15000)
public class UnitTestsServiceImpl implements UnitTestsService {

    private static final String REPOSITORY_PATH = "/home/admin/uinttest/project/";

    private static final String GIT_PATH_PREFIX = "feature/unit/test/";

    private static final String WORK_PATH = "/home/admin/uinttest";

    private static final String MAVEN_REPOSITORY_PATH = "/home/admin/.m2/repository/com/alibaba";

    private static final String RESULT_PATH = "/result/";

    private static final String GLOBAL_FILE = "/global.json";

    private final ForkJoinPool workStealingPool = new ForkJoinPool(
        10, ForkJoinPool.defaultForkJoinWorkerThreadFactory, null, true);

    @Resource
    private AppNameRepositoryDiamond appNameRepositoryDiamond;

    @Resource
    private HttpComponent httpComponent;

    @Resource
    private OssComponent ossComponent;

    private final ExecutorService executorService = Executors.newScheduledThreadPool(4);

    @Override
    public ResultDTO stage1PromptGeneration(String uuid, String moduleName, String appName, String subPath,
        Set<String> hasAnnotations, Set<String> implementInterfaces, Set<String> classNames, String callbackUrl) {
        gitCloneRepository(appName, uuid);
        compileModule(appName, uuid);

        // 进行流程多线程优化
        String resultPath = WORK_PATH + RESULT_PATH + appName + "/" + moduleName + "/" + uuid;
        Path globalPath = Paths.get(resultPath + GLOBAL_FILE);
        JSONObject globalJson;
        String fileName = "target.json";
        Set<String> classNameSet = new HashSet<>();
        Map<String, List<String>> cfgInfoMap = new ConcurrentHashMap<>();
        try {
            if (Files.exists(globalPath)) {
                // 如果文件存在，读取它
                log.info("UnitTestsServiceImpl::multiPathPromptGeneration global.json file exists.");
                String globalContent = new String(Files.readAllBytes(globalPath));
                globalJson = new JSONObject(globalContent);
            } else {
                log.info("UnitTestsServiceImpl::multiPathPromptGeneration global.json file not exists.");
                // 如果文件不存在，创建默认配置
                globalJson = new JSONObject();
                globalJson.put("cfg_analyse", true);
                globalJson.put("path_analyse", true);
                globalJson.put("dependency_analyse", true);
                globalJson.put("use_json_input", true);
                globalJson.put("debug_mode", false);
                // 将默认配置写入文件
                Files.createDirectories(globalPath.getParent());
                Files.write(globalPath, globalJson.toString(4).getBytes());
                log.info("Default global.json file created.");
            }

            // 读取配置
            boolean cfgAnalyse = globalJson.getBoolean("cfg_analyse");
            boolean pathAnalyse = globalJson.getBoolean("path_analyse");
            boolean dependencyAnalyse = globalJson.getBoolean("dependency_analyse");
            boolean useJsonInput = globalJson.getBoolean("use_json_input");
            boolean debugMode = globalJson.getBoolean("debug_mode");

            // [1]读取输入,将目标class文件CP到classPath中
            log.info("UnitTestsServiceImpl::multiPathPromptGeneration read input.");
            String classPath = getResultClassPath(appName, moduleName, subPath, resultPath, uuid);
            String javaPath = REPOSITORY_PATH + uuid + "/" + appName + "/" + moduleName + "/src/main/java/";
            String find_dependency_path = REPOSITORY_PATH + uuid + "/" + appName + "/";
            String maven_repository = MAVEN_REPOSITORY_PATH;

            if (useJsonInput) {
                // 创建target.json对象
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("class_path", classPath);
                jsonObject.put("java_path", javaPath);
                jsonObject.put("has_annotations", hasAnnotations);
                jsonObject.put("implement_interfaces", implementInterfaces);
                jsonObject.put("find_dependency_path", REPOSITORY_PATH + uuid + "/" + appName + "/");
                jsonObject.put("maven_repository", MAVEN_REPOSITORY_PATH);
                jsonObject.put("test_out_path", REPOSITORY_PATH + uuid + "/" + appName + "/" + moduleName + "/src/test/java/");
                jsonObject.put("app_name", appName);
                jsonObject.put("module_name", moduleName);
                try {
                    // 写 JSON 到文件
                    File directory = new File(resultPath);
                    if (!directory.exists()) {
                        directory.mkdirs(); // 创建目标目录
                    }
                    log.info("UnitTestsServiceImpl::multiPathPromptGeneration write target.json.");
                    Files.write(Path.of(resultPath + "/" + fileName), jsonObject.toString(4).getBytes());
                } catch (Exception e) {
                    log.error("UnitTestsServiceImpl::multiPathPromptGeneration write target.json error", e);
                    httpComponent.onCallbackAgent(callbackUrl, "false", null, null, moduleName, uuid);
                }
            }

            if (dependencyAnalyse) {
                // [2]将所有目标class的路径依赖生成到csv文件里
                log.info("UnitTestsServiceImpl::multiPathPromptGeneration dependency analysis.");
                DependencyGeneration dependencyGeneration = new DependencyGeneration(resultPath, maven_repository,
                    find_dependency_path, find_dependency_path);
                classNameSet = dependencyGeneration.FetchAllDependency(classPath, hasAnnotations, implementInterfaces, classNames);
            }
            if (cfgAnalyse) {
                // [3]将全部目标class的cfg路径生成到一个csv文件里
                log.info("UnitTestsServiceImpl::multiPathPromptGeneration cfg analysis.");
                CFGGeneration cfgGeneration = new CFGGeneration(resultPath, debugMode, pathAnalyse);
                cfgGeneration.AllCfgGenerate(classPath, hasAnnotations, implementInterfaces, classNames);
                cfgInfoMap = cfgGeneration.CfgToRouteClassDependency(cfgGeneration);
            }

            // stag1 start:
            String csvFilePath = resultPath + "/AllCFGPath.csv";
            ArrayList<ArrayList<String>> targetMethodDetailInfo = Stage1.getAllColumnValues(csvFilePath);
            List<String> allStage1Path = new ArrayList<>();
            allStage1Path.add(resultPath);
            Map<String, String> savaPathMap = new ConcurrentHashMap<>();
            // [4]遍历所有目标cfg, 每个cfg构建一个prompt，输出到txt文件
            log.info("UnitTestsServiceImpl::multiPathPromptGeneration cfg analysis.");

            //List<Future<String>> futures = new ArrayList<>();

            for (ArrayList<String> targetInfoList : targetMethodDetailInfo) {
                try {
                    generateStage1Prompt(targetInfoList, resultPath, csvFilePath, savaPathMap, cfgInfoMap);
                } catch (Exception e) {
                    log.error("UnitTestsServiceImpl::generateStage1Prompt error targetInfoList: " +  targetInfoList);
                    log.error("UnitTestsServiceImpl::generateStage1Prompt error: " +  e.getMessage());
                }
               // Map<String, List<String>> finalCfgInfoMap = cfgInfoMap;
               // Future<String> future = executorService.submit(() -> {
               //     generateStage1Prompt(targetInfoList, resultPath, csvFilePath, savaPathMap, finalCfgInfoMap);
               //     return "success";
               // });
               // futures.add(future);
            }

            //for (Future<String> future : futures) {
            //    future.get();
            //}

            //cleanupDirectories(resultPath + "/Prompt/stage1");
            log.info("UnitTestsServiceImpl::multiPathPromptGeneration stage1 prompt generation done.");

            // 将生产的中间文件也上传oss
            try {
                // 遍历路径下所有非目录文件，并上传到oss
                File directory = Paths.get(resultPath).toFile();
                for (File file : Objects.requireNonNull(directory.listFiles())) {
                    if (file.isFile()) {
                        ossComponent.writeData(file.getAbsolutePath().substring(1), new String(Files.readAllBytes(file.toPath())));
                    }
                }
            } catch (Exception e) {
                log.error("UnitTestsServiceImpl::multiPathPromptGeneration upload csv and json error", e);
            }
            Set<String> savePaths = savaPathMap.keySet();
            allStage1Path.addAll(savePaths);
            httpComponent.onCallbackAgent(callbackUrl, "true", allStage1Path, classNameSet, moduleName, uuid);

        } catch (IOException e) {
            log.error(e.getMessage(), e);
            httpComponent.onCallbackAgent(callbackUrl, "false", null, null, moduleName, uuid);
            //} catch (ExecutionException | InterruptedException e) {
            //    throw new RuntimeException(e);
            //}
        }
        return ResultDTO.successResult();
    }

    private void generateStage1Prompt(ArrayList<String> targetInfoList, String resultPath, String csvFilePath, Map<String,
        String> savaPathMap, Map<String, List<String>> cfgInfoMap) {
        String generatePromptId = UUID.randomUUID().toString();
        long startTime = System.currentTimeMillis();
        String targetMethodInf = targetInfoList.get(0);
        Integer pathNumber = Integer.parseInt(targetInfoList.get(1));
        // log.info("targetMethodInf:" + targetMethodInf);
        JavaMethodFind processor = new JavaMethodFind();
        if (!processor.ExistMethod(resultPath, targetMethodInf)) {
            return;
        }
        String methodContent = processor.getClassContent(resultPath, targetMethodInf);
        String classname = processor.extractClassName(targetMethodInf);
        long infoFetchTime = System.currentTimeMillis();
        log.info(generatePromptId + " :infoFetchTime cost- " + (infoFetchTime - startTime));
        if (!methodContent.isEmpty()) {
            // log.info(targetMethodInf);
            // log.info(methodContent);//构建prompt存放dir
            Stage1 promptBuilder = new Stage1();
            promptBuilder.method_java = methodContent;
            promptBuilder.Class_java = classname;
            String saveDir = resultPath + "/Prompt/stage1/" + promptBuilder.parseSimpleClassAndMethodName(targetMethodInf);
            if (saveDir.endsWith("+handle+java.lang.Object")) {
                return;
            }
            PathRouteUtil.addFileNameToPathMap(saveDir, targetMethodInf, pathNumber);
            long parseSimpleClassNameTime = System.currentTimeMillis();
            log.info(generatePromptId + " :parseSimpleClassNameTime cost- " + (parseSimpleClassNameTime - infoFetchTime));

            //boolean result = PathUtils.ensureDirectoryExists(saveDir);
            //if (result) {
            //    log.info("目录存在或已成功创建。" + saveDir);
            //} else {
            //    log.info("目录创建失败或路径被占用。");
            //}

            //prompt产生
            Map<String, String> saveFileMap = promptBuilder.AllPromptBuildAndSave2TXT(csvFilePath, targetMethodInf, saveDir, cfgInfoMap);
            long promptBuildTime = System.currentTimeMillis();
            log.info(generatePromptId + " :promptBuildTime cost- " + (promptBuildTime - parseSimpleClassNameTime));
            for (String saveFilePath : saveFileMap.keySet()) {
                savaPathMap.put(saveFilePath.substring(1), "1");
                ossComponent.writeData(saveFilePath.substring(1), saveFileMap.get(saveFilePath));
                //构建LLM输出dir
                String outDir = resultPath + "/Output/stage1/" + promptBuilder.parseSimpleClassAndMethodName(targetMethodInf);
                boolean result = PathUtils.ensureDirectoryExists(outDir);
                //if (result) {
                //    log.info("目录存在或已成功创建。" + outDir);
                //} else {
                //    log.info("目录创建失败或路径被占用。");
                //}
            }
            long outputBuildTime = System.currentTimeMillis();
            log.info(generatePromptId + " :outputBuildTime cost- " + (outputBuildTime - promptBuildTime));
        }
    }

    @Override
    public ResultDTO stage2PromptGeneration(String workDir, String callbackUrl) {

        List<String> allSavePath = new ArrayList<>();
        allSavePath.add(workDir);
        Map<String, String> savaPathMap = new ConcurrentHashMap<>();
        // stage2 start:
        String dependencyCsvFilePath = workDir + "/AllDependency.csv";
        /*File directory = Paths.get(workDir + "/Prompt/stage2").toFile();
        for (File file : Objects.requireNonNull(directory.listFiles())) {
            if (file.isDirectory()) {
                DataInputUtil.deleteDirectory(file);
            } else {
                boolean success = file.delete();
                if (!success) {System.err.println("WARN: delete stage2 file fail!");}
            }
        }*/

        // 从oss获取stage1的output

        try (CSVReader reader = new CSVReader(new FileReader(dependencyCsvFilePath))) {
            // 跳过标题行
            reader.readNext();
            List<Future<String>> futures = new ArrayList<>();

            String[] nextLine;
            while ((nextLine = reader.readNext()) != null) {
                String[] finalNextLine = nextLine;
                Future<String> future = executorService.submit(() -> {
                    generateStage2Prompt(finalNextLine, workDir, savaPathMap, dependencyCsvFilePath);
                    return "success";
                });
                futures.add(future);
            }

            for (Future<String> future : futures) {
                future.get();
            }

        } catch (Exception e) {
            log.error("Error Occur in stage2.getAllPathPrompt: {}", e.getMessage(), e);
        }
        log.info("UnitTestsServiceImpl::stage2PromptGeneration stage2 prompt generation done.");
        Set<String> savePaths =  savaPathMap.keySet();
        allSavePath.addAll(savePaths);
        httpComponent.onCallbackAgent(callbackUrl, "true", allSavePath, null, null, null);
        return ResultDTO.successResult();
    }

    private void generateStage2Prompt(String[] nextLine, String workDir, Map<String, String> savaPathMap, String dependencyCsvFilePath)
        throws Exception {
        if (nextLine.length > 0) {
            String firstColumnValue = nextLine[0].trim();
            String secondColumnValue = nextLine[1].trim();
            String DirPath = workDir + "/Output/stage1/" + Stage2.combineElements(firstColumnValue, secondColumnValue)
                + "/";
            log.info("UnitTestsServiceImpl::stage2PromptGeneration stage2 {}", Stage2.combineElements(firstColumnValue, secondColumnValue));
            ArrayList<Integer> routeIndexList = new ArrayList<>();
            for (int routeIndex = 1; ; routeIndex++) {
                String stage1outFilePath = DirPath + routeIndex + ".json";
                try {
                    ossComponent.copyDataToLocal(stage1outFilePath);
                    routeIndexList.add(routeIndex);
                } catch (Exception e) {
                    log.error("UnitTestsServiceImpl::stage2PromptGeneration copyDataToLocal error", e);
                    if (routeIndexList.isEmpty()) {break;}
                    String savePath = workDir + "/Prompt/stage2/" + Stage2.combineElements(firstColumnValue,
                        secondColumnValue) + "/1.txt";
                    if (savaPathMap.containsKey(savePath)) {
                        break;
                    }
                    savaPathMap.put(savePath, "1");
                    Stage2 promptBuilder = new Stage2(workDir);
                    promptBuilder.path = routeIndex;
                    StageInfo stageInfo = promptBuilder.PromptBuildAndSaveForAllCfgRoute(dependencyCsvFilePath, secondColumnValue,
                        DirPath, savePath, routeIndexList, firstColumnValue);
                    if (null != stageInfo) {
                        ossComponent.writeData(stageInfo.getSavePath().substring(1), stageInfo.getData());
                    }
                    break;
                }
            }
        }
    }

    private String getResultClassPath(String appName, String moduleName, String subPath, String resultPath, String uuid) {
        String classPath = REPOSITORY_PATH + uuid + "/" + appName + "/" + moduleName + "/target/classes";
        if (StringUtils.isNotBlank(subPath)) {
            classPath = classPath + "/" + subPath;
        }
        File srcDir = new File(classPath);
        File destDir = new File(resultPath + "/target/classes/" + subPath);
        // 确保目标目录存在
        if (!destDir.exists()) {
            destDir.mkdirs();
        }
        // 递归复制源目录下的所有文件和子目录
        copyDirectory(srcDir, destDir);
        return resultPath + "/target/classes";
    }

    /**
     * 递归复制目录及其所有内容
     * @param srcDir 源目录
     * @param destDir 目标目录
     */
    private static void copyDirectory(File srcDir, File destDir) {
        // 获取源目录下的所有文件和子目录
        File[] files = srcDir.listFiles();
        if (files != null) {
            for (File file : files) {
                // 构造目标文件或目录
                File destFile = new File(destDir, file.getName());
                try {
                    if (file.isFile()) {
                        // 执行文件复制
                        copyFile(file, destFile);
                        System.out.println("Copied: " + file.getName());
                    } else if (file.isDirectory()) {
                        // 递归复制子目录
                        boolean mkdirs = destFile.mkdirs();
                        log.info("UnitTestsServiceImpl::copyDirectory mkdirs:{}", mkdirs);
                        copyDirectory(file, destFile);
                    }
                } catch (Exception e) {
                    log.error("UnitTestsServiceImpl::copyDirectory copy file error", e);
                    throw new RuntimeException(e);
                }
            }
        }
    }

    @Override
    public ResultDTO dependencyGeneration(String uuid, String moduleName, String appName, String subPath) {
        // 在进行依赖分析时，需要将目录下的class文件拷贝一份，不然sootUP比较难处理
        // 定义输出目录
        String outputDir = WORK_PATH + RESULT_PATH + appName + "/" + uuid;
        String fileName = "target.json";
        String classPath = REPOSITORY_PATH + uuid + "/" + appName + "/" + moduleName + "/target/classes";
        String javaPath = REPOSITORY_PATH + uuid + "/" + appName + "/" + moduleName + "/src/main/java/";

        if (StringUtils.isNotBlank(subPath)) {
            classPath = classPath + "/" + subPath;
        }

        File srcDir = new File(classPath);
        File destDir = new File(outputDir + "/target/classes" + "/" + subPath);

        // 确保目标目录存在
        if (!destDir.exists()) {
            destDir.mkdirs();
        }

        // 递归复制源目录下的所有文件和子目录
        copyDirectory(srcDir, destDir);

        classPath = outputDir + "/target/classes";

        // 创建 JSON 对象并填充数据
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("class_path", classPath);
        jsonObject.put("java_path", javaPath);
        jsonObject.put("find_dependency_path", REPOSITORY_PATH + uuid + "/" + appName + "/");
        jsonObject.put("maven_repository", MAVEN_REPOSITORY_PATH);
        jsonObject.put("test_out_path", REPOSITORY_PATH + uuid + "/" + appName + "/" + moduleName + "/src/test/java/");
        try {
            // 写 JSON 到文件
            File directory = new File(REPOSITORY_PATH + uuid + "/" + appName + "/" + uuid);
            if (!directory.exists()) {
                directory.mkdirs(); // 创建目标目录
            }
            Files.write(Path.of(REPOSITORY_PATH + uuid + "/" + appName + "/" + uuid + "/" + fileName),
                jsonObject.toString(4).getBytes());
            System.out.println(REPOSITORY_PATH + uuid + "/" + appName + "/" + uuid + "/" + fileName + "写入文件成功!");
        } catch (Exception e) {
            log.error("UnitTestsServiceImpl::dependencyGeneration write json error", e);
            return ResultDTO.errorResult("UnitTestsServiceImpl::dependencyGeneration write json error");
        }
        String finalClassPath = classPath;
        CompletableFuture.runAsync(() -> {
            // 依赖生成
            String csvSaveDir = REPOSITORY_PATH + uuid + "/" + appName + "/" + uuid;
            DependencyGeneration dependencyGeneration = new DependencyGeneration(
                csvSaveDir, MAVEN_REPOSITORY_PATH, REPOSITORY_PATH + uuid + "/" + appName + "/",
                REPOSITORY_PATH + uuid + "/" + appName + "/");
            dependencyGeneration.FetchAllDependency(finalClassPath);
        });

        return ResultDTO.successResult();
    }

    private static void copyFile(File source, File dest) throws IOException {
        try (InputStream is = new FileInputStream(source);
             OutputStream os = new FileOutputStream(dest)) {

            byte[] buffer = new byte[1024];
            int length;
            while ((length = is.read(buffer)) > 0) {
                os.write(buffer, 0, length);
            }
        }
    }

    @Override
    public ResultDTO testOssUpload(String localFilePath, String ossFilePath) throws IOException {
        // 遍历路径下所有非目录文件，并上传到oss
        File directory = Paths.get(localFilePath).toFile();
        for (File file : Objects.requireNonNull(directory.listFiles())) {
            if (file.isFile()) {
                ossComponent.writeData(file.getAbsolutePath().substring(1), new String(Files.readAllBytes(file.toPath())));
            }
        }
        return ResultDTO.successResult();
    }
    @Override
    public ResultDTO testOssDownload() {
        //try {
        //    //String result = ossComponent.readData("/test/oss");
        //    return ResultDTO.successResultWithObject(result);
        //} catch (Exception e) {
        //    log.error("UnitTestsServiceImpl::testOssDownload read json error", e);
        //}
        return ResultDTO.successResult();

    }

    @Override
    public ResultDTO cfgGeneration(String uuid, String moduleName, String appName, String subPath) {
        String outputDir = WORK_PATH + RESULT_PATH + appName + "/" + uuid;
        String classPath = outputDir + "/target/classes";

        CompletableFuture.runAsync(() -> {
            // cfg生成
            CFGGeneration cfgGeneration = new CFGGeneration(REPOSITORY_PATH + uuid + "/" + appName + "/" + uuid, false, true);
            cfgGeneration.AllCfgGenerate(classPath);
            cfgGeneration.CfgToRouteClassDependency(cfgGeneration);
        });

        return ResultDTO.successResult();
    }

    @Override
    public ResultDTO stag1PromptGeneration(String uuid, String moduleName, String appName) {
        String csvSaveDir = REPOSITORY_PATH + uuid + "/" + appName + "/" + uuid;
        String csvFilePath = REPOSITORY_PATH + uuid + "/" + appName + "/" + uuid + "/" + "AllCFGPath.csv";
        String[] targetMethodInfs = Stage1.getUniqueFirstColumnValues(csvFilePath);
        for (String targetMethodInf : targetMethodInfs) {
            System.out.println("targetMethodInf:" + targetMethodInf);
            JavaMethodFind processor = new JavaMethodFind();
            if (!processor.ExistMethod(csvSaveDir, targetMethodInf)) {//判断条件：存在且为public，且返回值一样
                continue;
            }
            String methodContent = processor.getClassContent(csvSaveDir, targetMethodInf);
            String classname = processor.extractClassName(targetMethodInf);
            if (!methodContent.isEmpty()) {
                Stage1 promprBuilder = new Stage1(csvSaveDir);
                promprBuilder.method_java = methodContent;
                promprBuilder.Class_java = classname;
                String saveDir = csvSaveDir + "/Prompt/stage1/" + promprBuilder.parseSimpleClassAndMethodName(
                    targetMethodInf);
                boolean result = PathUtils.ensureDirectoryExists(saveDir);
                if (result) {
                    System.out.println("目录存在或已成功创建。" + saveDir);
                } else {
                    System.out.println("目录创建失败或路径被占用。");
                }
                //prompt产生
                promprBuilder.AllPromptBuildAndSave2TXT(csvFilePath, targetMethodInf, saveDir, new HashMap<>());
            }
        }
        return ResultDTO.successResult();
    }

    @Override
    public ResultDTO stag2PromptGeneration(String uuid, String moduleName, String appName) {
        String outputPath = REPOSITORY_PATH + uuid + "/" + appName + "/" + uuid;
        String csvFilePath = outputPath + "/AllDependency.csv";
        try (CSVReader reader = new CSVReader(new FileReader(csvFilePath))) {
            // 跳过标题行
            reader.readNext();
            String[] nextLine;
            while ((nextLine = reader.readNext()) != null) {
                if (nextLine.length > 0) {
                    String firstColumnValue = nextLine[0].trim();
                    String secondColumnValue = nextLine[1].trim();
                    String DirPath = outputPath + "/Prompt/stage1/" + Stage2.combineElements(firstColumnValue,
                        secondColumnValue) + "/";
                    System.out.println(Stage2.combineElements(firstColumnValue, secondColumnValue));
                    for (int i = 1; ; i++) {
                        String stage1PromptFilePath = DirPath + String.valueOf(i) + ".txt";
                        if (!Stage2.isFileExist(stage1PromptFilePath)) {
                            System.out.println(stage1PromptFilePath + "不存在");
                            break;
                        }
                        String savePath = outputPath + "/Prompt/stage2/" +
                            Stage2.combineElements(firstColumnValue, secondColumnValue) + "/" +
                            String.valueOf(i) + ".txt";
                        Stage2 promptbuilder = new Stage2(outputPath);
                        promptbuilder.path = i;
                        promptbuilder.PromptBulidAndSava2TXT(csvFilePath, secondColumnValue, savePath, i,
                            firstColumnValue);
                    }
                }
            }
        } catch (IOException | CsvValidationException e) {
            System.err.println("读取文件时发生错误: " + e.getMessage());
            e.printStackTrace();
        }

        return ResultDTO.successResult();
    }

    @Override
    public ResultDTO dependencyAndCfgGeneration(String uuid, String moduleName, String appName) {
        // 定义输出目录
        String outputDir = REPOSITORY_PATH + uuid + "/" + appName + "/" + uuid;
        String fileName = "target.json";
        String class_path = REPOSITORY_PATH + uuid + "/" + appName + "/" + moduleName + "/target/classes";
        // 创建 JSON 对象并填充数据
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("class_path", class_path);
        jsonObject.put("java_path", REPOSITORY_PATH + uuid + "/" + appName + "/" + moduleName + "/src/main/java/");
        jsonObject.put("find_dependency_path", REPOSITORY_PATH + uuid + "/" + appName + "/");
        jsonObject.put("maven_repository", MAVEN_REPOSITORY_PATH);
        jsonObject.put("test_out_path", REPOSITORY_PATH + uuid + "/" + appName + "/" + moduleName + "/src/test/java/");
        try {
            // 写 JSON 到文件
            File directory = new File(outputDir);
            if (!directory.exists()) {
                directory.mkdirs(); // 创建目标目录
            }
            Files.write(Path.of(outputDir + "/" + fileName), jsonObject.toString(4).getBytes());
            System.out.println(outputDir + "/" + fileName + "写入文件成功!");
        } catch (Exception e) {
            log.error("UnitTestsServiceImpl::dependencyGeneration write json error", e);
            return ResultDTO.errorResult("UnitTestsServiceImpl::dependencyGeneration write json error");
        }

        // 依赖生成
        String csvSaveDir = REPOSITORY_PATH + uuid + "/" + appName + "/" + uuid;
        DependencyGeneration dependencyGeneration = new DependencyGeneration(
            csvSaveDir, MAVEN_REPOSITORY_PATH, REPOSITORY_PATH + uuid + "/" + appName + "/",
            REPOSITORY_PATH + uuid + "/" + appName + "/");
        dependencyGeneration.FetchAllDependency(class_path);

        // cfg生成
        CFGGeneration cfgGeneration = new CFGGeneration(REPOSITORY_PATH + uuid + "/" + appName + "/" + uuid, false, true);
        cfgGeneration.AllCfgGenerate(class_path);
        cfgGeneration.CfgToRouteClassDependency(cfgGeneration);

        //stage1-Prompt
        String csvFilePath = REPOSITORY_PATH + uuid + "/" + appName + "/" + uuid + "/" + "AllCFGPath.csv";
        String[] targetMethodInfs = Stage1.getUniqueFirstColumnValues(csvFilePath);
        for (String targetMethodInf : targetMethodInfs) {
            System.out.println("targetMethodInf:" + targetMethodInf);
            JavaMethodFind processor = new JavaMethodFind();
            if (!processor.ExistMethod(csvSaveDir, targetMethodInf)) {//判断条件：存在且为public，且返回值一样
                continue;
            }
            String methodContent = processor.getClassContent(csvSaveDir, targetMethodInf);
            String classname = processor.extractClassName(targetMethodInf);
            if (!methodContent.isEmpty()) {
                Stage1 promprBuilder = new Stage1(csvSaveDir);
                promprBuilder.method_java = methodContent;
                promprBuilder.Class_java = classname;
                String saveDir = "./" + csvSaveDir + "/Prompt/stage1/" + promprBuilder.parseSimpleClassAndMethodName(
                    targetMethodInf);
                boolean result = PathUtils.ensureDirectoryExists(saveDir);
                if (result) {
                    System.out.println("目录存在或已成功创建。" + saveDir);
                } else {
                    System.out.println("目录创建失败或路径被占用。");
                }
                //prompt产生
                promprBuilder.AllPromptBuildAndSave2TXT(csvFilePath, targetMethodInf, saveDir, new HashMap<>());
            }
        }
        cleanupDirectories("./" + csvFilePath + "/Prompt/stage1");

        //stage2:没改完，找依赖信息的没确认
        csvFilePath = csvFilePath + "/AllDependency.csv";
        try (CSVReader reader = new CSVReader(new FileReader(csvFilePath))) {
            // 跳过标题行
            reader.readNext();
            String[] nextLine;
            while ((nextLine = reader.readNext()) != null) {
                if (nextLine.length > 0) {
                    String firstColumnValue = nextLine[0].trim();
                    String secondColumnValue = nextLine[1].trim();
                    String DirPath = csvFilePath + "/Prompt/stage1/" + Stage2.combineElements(firstColumnValue,
                        secondColumnValue) + "/";
                    System.out.println(Stage2.combineElements(firstColumnValue, secondColumnValue));
                    for (int i = 1; ; i++) {
                        String stage1PromptFilePath = DirPath + String.valueOf(i) + ".txt";
                        if (!Stage2.isFileExist(stage1PromptFilePath)) {
                            System.out.println(stage1PromptFilePath + "不存在");
                            break;
                        }
                        String savePath = csvFilePath + "/Prompt/stage2/" +
                            Stage2.combineElements(firstColumnValue, secondColumnValue) + "/" +
                            String.valueOf(i) + ".txt";
                        Stage2 promptbuilder = new Stage2(csvFilePath);
                        promptbuilder.path = i;
                        promptbuilder.PromptBulidAndSava2TXT(csvFilePath, secondColumnValue, savePath, i,
                            firstColumnValue);
                    }
                }
            }
        } catch (IOException | CsvValidationException e) {
            System.err.println("读取文件时发生错误: " + e.getMessage());
            e.printStackTrace();
        }

        return ResultDTO.successResult();
    }

    private void cleanupDirectories(String rootPath) {
        try {
            Files.walkFileTree(Paths.get(rootPath), new SimpleFileVisitor<Path>() {
                @Override
                public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                    // 检查目录名是否以"+handle+java.lang.Object"结尾
                    if (dir.getFileName().toString().endsWith("+handle+java.lang.Object")) {
                        try {
                            // 获取目录中的文件列表
                            File[] files = dir.toFile().listFiles();

                            // 检查目录是否只包含一个文件
                            if (files != null && files.length == 1 && files[0].isFile()) {
                                // 先删除文件
                                Files.delete(files[0].toPath());
                                // 再删除目录
                                Files.delete(dir);
                                System.out.println("Deleted directory: " + dir);
                                return FileVisitResult.SKIP_SUBTREE;
                            }
                        } catch (IOException e) {
                            System.err.println("Error processing directory: " + dir);
                            e.printStackTrace();
                        }
                    }
                    return FileVisitResult.CONTINUE;
                }

                @Override
                public FileVisitResult visitFileFailed(Path file, IOException exc) {
                    System.err.println("Failed to access file: " + file);
                    return FileVisitResult.CONTINUE;
                }
            });
        } catch (IOException e) {
            System.err.println("Error walking through directory tree");
            e.printStackTrace();
        }
    }

    @Override
    public ResultDTO compileModule(String appName, String uuid) {
        try {
            // 切换JVM中的环境变量

            ProcessBuilder processBuilder = new ProcessBuilder(
                "mvn",
                "compile",
                "-f",
                REPOSITORY_PATH + uuid + "/" + appName + "/pom.xml",
                "-Dmaven.compiler.useIncrementalCompilation=false",
                "-Dmaven.compiler.source=1.8",
                "-Dmaven.compiler.target=1.8",
                "-l",
                "/home/admin/amaven/maven.log"
            );

            Map<String, String> env = processBuilder.environment();
            env.put("JAVA_HOME", "/opt/taobao/java8");

            Process process = processBuilder.start();

            int exitCode = process.waitFor();
            if (exitCode != 0) {
                log.error(
                    String.format("UnitTestsServiceImpl::compileModule compile module error, errorCode: %s", exitCode));
                return ResultDTO.errorResult("UnitTestsServiceImpl::compileModule compile module error");
            }
        } catch (Exception e) {
            log.error("UnitTestsServiceImpl::compileModule compile module error", e);
            return ResultDTO.errorResult("UnitTestsServiceImpl::compileModule compile module error");
        }
        return ResultDTO.successResult();
    }

    @Override
    public ResultDTO gitCloneRepository(String appName, String uuid) {
        File file = new File(REPOSITORY_PATH + uuid + "/" + appName);
        boolean exists = file.exists();
        if (!exists || file.listFiles().length == 0) {
            try {
                file.mkdirs();
                ProcessBuilder processBuilder = new ProcessBuilder(
                    "git",
                    "clone",
                    "-b",
                    GIT_PATH_PREFIX + uuid,
                    appNameRepositoryDiamond.getAppNameRepositoryMapping().get(appName),
                    REPOSITORY_PATH + uuid + "/" + appName
                );

                Process process = processBuilder.start();
                // 等待命令执行完成
                int exitCode = process.waitFor();
                if (exitCode == 0) {
                    log.info("UnitTestsServiceImpl::gitCloneRepository clone repository success");
                } else {
                    log.error(
                        String.format("UnitTestsServiceImpl::gitCloneRepository clone repository error, errorCode: %s",
                            exitCode));
                    return ResultDTO.errorResult("UnitTestsServiceImpl::gitCloneRepository clone repository error");
                }
            } catch (Exception e) {
                log.error("UnitTestsServiceImpl::gitCloneRepository clone repository error", e);
                return ResultDTO.errorResult("UnitTestsServiceImpl::gitCloneRepository clone repository error");
            }
        }
        return ResultDTO.successResult();
    }

}