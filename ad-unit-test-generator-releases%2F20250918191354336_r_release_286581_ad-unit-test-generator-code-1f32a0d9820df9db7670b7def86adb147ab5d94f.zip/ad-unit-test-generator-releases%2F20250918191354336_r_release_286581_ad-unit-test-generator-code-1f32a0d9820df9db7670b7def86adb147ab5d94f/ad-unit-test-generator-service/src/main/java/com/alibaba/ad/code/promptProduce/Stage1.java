//package com.alibaba.promptProduce;
//import com.alibaba.Starter;
//import com.alibaba.cfganalyser.code.DependencyUtil;
//import com.opencsv.CSVReader;
//import com.opencsv.exceptions.CsvValidationException;
//
//import javax.management.relation.Role;
//import java.io.*;
//import java.lang.reflect.Array;
//import java.util.ArrayList;
//import java.util.HashSet;
//import java.util.List;
//import java.util.Set;
//
//public class stage1 {
//    public String method_java;
//    public String Class_java;
//    public String Role(){
//        StringBuilder role=new StringBuilder();
//        role.append("# 角色定义:\n" +
//                "你是一个 Java 方法测试用例输入数据生成器。你的任务是：\n" +
//                "你需要理解我给你的Java方法，然后根据指定的执行路径（以 Jimple
//                中间代码形式表示）、以及该路径相关的分支信息，请你用“描述性的语言”输出应该如何构造输入数据使得这条路径被有效覆盖，需要初始化哪些变量或属性，需要mock
//                哪些方法，以及如何构造测试方法的验证点，最后总结这组数据的测试意图\n" +
//                "\n");
//        return role.toString();
//    }
//    public String method_java(){
//        return "\n## 2、目标java方法源代码：\n"+"```java\n"+this.method_java+"\n```\n";
//    }
//    public String dependency_stage1(String [] line) {
//        String methodEmd = line[0].trim();
//        int path = Integer.parseInt(line[1].trim());
//        StringBuilder result = new StringBuilder();
//        String dependency=DependencyUtil.getRouteCodeSourceDependency(methodEmd, path);
//        if(dependency.length()>1){
//            result.append("#下面是与目标java方法同属一个类的方法，我不希望这些方法被mock:\n");
//            result.append("```java\n");
//            result.append(dependency);
//            result.append("```\n");
//        }
//        return result.toString();
//    }
//    public String JimpleDependencyBranch_for1Path(String [] line){
//        StringBuilder result=new StringBuilder();
//        result.append("\n## 3、下面是你的生成数据需要覆盖的一条执行路径，用中间代码(Jimple)表示：\n");
//        result.append("```\n");
//        result.append(line[2].trim()).append("\n");
//        result.append("\n");
//        result.append("```\n");
//        result.append("下面是为该路径补充的分支信息，请你充分利用他们\n");
////        result.append("4、路径中的数据依赖：\n");
////        result.append(line[3].trim()).append("\n");
//        result.append("\n");
//        result.append("## 4、路径中的分支信息：\n");
//        result.append("```\n");
//        for(int i=4;i<line.length;i++){
//            if(line[i].trim().equals("NAN")) break;
//            else result.append(line[i].trim()).append("\n");
//        }
//        result.append("\n");
//        result.append("```\n");
//        return result.toString();
//    }
//    public String COT(){
//        StringBuilder result=new StringBuilder();
//        result.append("\n# 工作步骤：\n"+
//                "1. 解析方法逻辑,阅读并理解 Java 方法的功能\n"+
//                "2. 映射路径到源码，将 Jimple 中的路径转换为 Java 源码中的对应执行路径，明确这条路径上各个分支的选择结果。\n"+
//                "3. 分析依赖与约束，结合分支条件，确定输入变量应满足的约束条件。\n"+
//                "4. 用“描述性的语言”构造输入数据，使得我按照你的描述可以构造出输入数据，且该数据可以使得程序在运行时能够沿着指定路径执行。\n"+
//                "5. 用“描述性的语言”构造测试方法的验证点 \n"+
//                "6. 总结这组数据的测试意图\n"+
//                "7. 你需要用描述性的语言将“路径分析”、“输入数据构造”、“验证点”、“测试意图”以json形式输出，我会将你的输出直接存在
//                .json文件中，因此请不要输出任何无关内容，你的输出是要以\"{\"开始的，而不是\"```json\"\n"
//        );
//        return result.toString();
//    }
//    public String constraint(){
//        StringBuilder result=new StringBuilder();
//        return result.toString();
//    }
//    public String good_example(){
//        StringBuilder result=new StringBuilder();
//        result.append("# 请参考下面的任务示例\n"+
//                        "## 1、目标java方法所在类：\n" +
//                        "com.taobao.ad.brand.bp.domain.account.atomability.DefaultAccountAdcRoleGetAbility\n" +
//                        "## 2、目标java方法：\n" +
//                        "```java\n"+
//                        "    private void fillAgencyXRole(HashSet<String> adcRoleSet, Long memberId) {\n" +
//                        "        if (!memberRepository.isAgencyX(memberId)) {\n" +
//                        "            return;\n" +
//                        "        }\n" +
//                        "        Long agencyMemberId = memberRepository.queryAgencyMemberId(memberId);\n" +
//                        "        if (agencyMemberId == null) {\n" +
//                        "            return;\n" +
//                        "        }\n" +
//                        "        Set<String> mainUicRoleCodeSet = memberRepository.findRoleCodeByMemberId
//                        (agencyMemberId);\n" +
//                        "        if (CollectionUtils.isNotEmpty(mainUicRoleCodeSet) && mainUicRoleCodeSet.contains
//                        (AdcRoleConstant.INTELLIGENT_STRATEGY_PROXY_WHITE)) {\n" +
//                        "            adcRoleSet.add(AdcRoleConstant.INTELLIGENT_STRATEGY_PROXY_WHITE);\n" +
//                        "        }\n" +
//                        "    }\n" +
//                        "\n" +
//                        "```\n"+
//                        "## 3、执行路径，用中间代码(Jimple)表示：\n" +
//                        "```\n"+
//                        "### 1 : this := @this: com.taobao.ad.brand.bp.domain.account.atomability
//                        .DefaultAccountAdcRoleGetAbility### 2 : adcRoleSet := @parameter0: java.util.HashSet### 3 :
//                        memberId := @parameter1: java.lang.Long### 4 : $stack5 = this.<com.taobao.ad.brand.bp
//                        .domain.account.atomability.DefaultAccountAdcRoleGetAbility: com.taobao.ad.brand.bp.domain
//                        .memeber.MemberRepository memberRepository>### 5 : $stack6 = interfaceinvoke $stack5.<com
//                        .taobao.ad.brand.bp.domain.memeber.MemberRepository: java.lang.Boolean isAgencyX(java.lang
//                        .Long)>(memberId)### 6 : $stack7 = virtualinvoke $stack6.<java.lang.Boolean: boolean
//                        booleanValue()>()### 7 : if $stack7 != 0### 9 : $stack8 = this.<com.taobao.ad.brand.bp
//                        .domain.account.atomability.DefaultAccountAdcRoleGetAbility: com.taobao.ad.brand.bp.domain
//                        .memeber.MemberRepository memberRepository>### 10 : agencyMemberId = interfaceinvoke
//                        $stack8.<com.taobao.ad.brand.bp.domain.memeber.MemberRepository: java.lang.Long
//                        queryAgencyMemberId(java.lang.Long)>(memberId)### 11 : if agencyMemberId != null### 13 :
//                        $stack9 = this.<com.taobao.ad.brand.bp.domain.account.atomability
//                        .DefaultAccountAdcRoleGetAbility: com.taobao.ad.brand.bp.domain.memeber.MemberRepository
//                        memberRepository>### 14 : mainUicRoleCodeSet = interfaceinvoke $stack9.<com.taobao.ad.brand
//                        .bp.domain.memeber.MemberRepository: java.util.Set findRoleCodeByMemberId(java.lang.Long)>
//                        (agencyMemberId)### 15 : $stack10 = staticinvoke <org.apache.commons.collections
//                        .CollectionUtils: boolean isNotEmpty(java.util.Collection)>(mainUicRoleCodeSet)### 16 : if
//                        $stack10 == 0### 17 : $stack11 = interfaceinvoke mainUicRoleCodeSet.<java.util.Set: boolean
//                        contains(java.lang.Object)>(\"Intelligent_strategy_proxy_white\")### 18 : if $stack11 ==
//                        0### 19 : virtualinvoke adcRoleSet.<java.util.HashSet: boolean add(java.lang.Object)>
//                        (\"Intelligent_strategy_proxy_white\")### 20 : return\n" +
//                        "```"+
//                        "\n" +
////                "4、路径中的数据依赖：\n" +
////                "The variable \"$stack6\" in the statement numbered 6 was assigned: ###5 $stack6 =
// interfaceinvoke $stack5.<com.taobao.ad.brand.bp.domain.memeber.MemberRepository: java.lang.Boolean isAgencyX(java
// .lang.Long)>(memberId);\n" +
////                "The variable \"$stack7\" in the statement numbered 7 was assigned: ###6 $stack7 = virtualinvoke
// $stack6.<java.lang.Boolean: boolean booleanValue()>();\n" +
////                "The variable \"agencyMemberId\" in the statement numbered 11 was assigned: ###10 agencyMemberId
// = interfaceinvoke $stack8.<com.taobao.ad.brand.bp.domain.memeber.MemberRepository: java.lang.Long
// queryAgencyMemberId(java.lang.Long)>(memberId);\n" +
////                "The variable \"mainUicRoleCodeSet\" in the statement numbered 15 was assigned: ###14
// mainUicRoleCodeSet = interfaceinvoke $stack9.<com.taobao.ad.brand.bp.domain.memeber.MemberRepository: java.util
// .Set findRoleCodeByMemberId(java.lang.Long)>(agencyMemberId);\n" +
////                "The variable \"$stack10\" in the statement numbered 16 was assigned: ###15 $stack10 =
// staticinvoke <org.apache.commons.collections.CollectionUtils: boolean isNotEmpty(java.util.Collection)>
// (mainUicRoleCodeSet);\n" +
////                "The variable \"$stack11\" in the statement numbered 18 was assigned: ###17 $stack11 =
// interfaceinvoke mainUicRoleCodeSet.<java.util.Set: boolean contains(java.lang.Object)>
// (\"Intelligent_strategy_proxy_white\");\n" +
////                "The variable \"adcRoleSet\" in the statement numbered 19 was assigned: ###2 adcRoleSet :=
// @parameter0: java.util.HashSet;\n" +
////                "\n" +
//                        "## 4、路径中的分支信息：\n" +
//                        "```\n"+
//                        "节点编号7为if分支语句，判断条件为if $stack7 != 0。if分支语句的true分支为$stack8 = this.<com.taobao.ad.brand.bp
//                        .domain.account.atomability.DefaultAccountAdcRoleGetAbility: com.taobao.ad.brand.bp.domain
//                        .memeber.MemberRepository memberRepository>，false分支为return。其中的栈信息为：[$stack7 =
//                        virtualinvoke$stack6.<java.lang.Boolean:booleanbooleanValue()>(), $stack8 = this.<com
//                        .taobao.ad.brand.bp.domain.account.atomability.DefaultAccountAdcRoleGetAbility:com.taobao
//                        .ad.brand.bp.domain.memeber.MemberRepositorymemberRepository>]。\n" +
//                        "节点编号11为if分支语句，判断条件为if agencyMemberId != null。if分支语句的true分支为$stack9 = this.<com.taobao.ad
//                        .brand.bp.domain.account.atomability.DefaultAccountAdcRoleGetAbility: com.taobao.ad.brand
//                        .bp.domain.memeber.MemberRepository memberRepository>，false分支为return。其中的栈信息为：[$stack9 =
//                        this.<com.taobao.ad.brand.bp.domain.account.atomability.DefaultAccountAdcRoleGetAbility:com
//                        .taobao.ad.brand.bp.domain.memeber.MemberRepositorymemberRepository>]。\n" +
//                        "节点编号16为if分支语句，判断条件为if $stack10 == 0。if分支语句的true分支为return，false分支为$stack11 =
//                        interfaceinvoke mainUicRoleCodeSet.<java.util.Set: boolean contains(java.lang.Object)>
//                        (\"Intelligent_strategy_proxy_white\")。其中的栈信息为：[$stack10 = staticinvoke<org.apache.commons
//                        .collections.CollectionUtils:booleanisNotEmpty(java.util.Collection)>(mainUicRoleCodeSet),
//                        $stack11 = interfaceinvokemainUicRoleCodeSet.<java.util.Set:booleancontains(java.lang
//                        .Object)>(\"Intelligent_strategy_proxy_white\")]。\n" +
//                        "节点编号18为if分支语句，判断条件为if $stack11 == 0。if分支语句的true分支为return，false分支为virtualinvoke adcRoleSet
//                        .<java.util.HashSet: boolean add(java.lang.Object)>(\"Intelligent_strategy_proxy_white\")
//                        。其中的栈信息为：[$stack11 = interfaceinvokemainUicRoleCodeSet.<java.util.Set:booleancontains(java
//                        .lang.Object)>(\"Intelligent_strategy_proxy_white\")]。\n"+
//                        "```\n"+
//                        "你需要根据上述输入信息（类名、方法源代码、路径信息、分支信息），来输出下面的json结构：\n"+
//                        "```json\n"+
//                        "{\n" +
//                        "  \"path analysis\": \"该执行路径覆盖了fillAgencyXRole方法的完整成功流程：首先通过memberRepository.isAgencyX
//                        (memberId)判断成员是否为AgencyX类型，返回true进入主逻辑；然后通过memberRepository.queryAgencyMemberId(memberId)
//                        获取代理成员ID，返回非null值继续执行；接着通过memberRepository.findRoleCodeByMemberId(agencyMemberId)
//                        获取角色代码集合，返回非空集合且包含'Intelligent_strategy_proxy_white'角色；最终将该角色添加到输入的adcRoleSet中。路径经过了4
//                        个关键分支判断：isAgencyX返回true、agencyMemberId非null、角色集合非空、角色集合包含目标角色，所有条件都满足才能到达最终的添加操作。\",\n" +
//                        "  \n" +
//                        "  \"input data construction\":
//                        \"需要准备以下输入数据：1）创建一个空的HashSet<String>作为adcRoleSet参数；2）创建一个有效的Long类型memberId作为成员ID参数；3）mock
//                        MemberRepository的三个方法：isAgencyX(memberId)返回Boolean.TRUE，queryAgencyMemberId(memberId)
//                        返回一个非null的Long值（如1001L）作为agencyMemberId，findRoleCodeByMemberId(agencyMemberId)
//                        返回一个包含'Intelligent_strategy_proxy_white'字符串的非空Set集合（如Set.of
//                        ('Intelligent_strategy_proxy_white', 'other_role')
//                        ）；4）需要初始化DefaultAccountAdcRoleGetAbility实例，并将mock的MemberRepository注入到其memberRepository
//                        字段中。\",\n" +
//                        "  \n" +
//                        "  \"verification points\":
//                        \"验证执行完成后adcRoleSet中包含了'Intelligent_strategy_proxy_white'角色，具体验证：1）验证adcRoleSet.size()
//                        等于1，确认只添加了一个角色；2）验证adcRoleSet.contains('Intelligent_strategy_proxy_white')
//                        返回true，确认正确添加了目标角色；3）验证memberRepository的三个方法都被正确调用：isAgencyX(memberId)
//                        被调用1次，queryAgencyMemberId(memberId)被调用1次，findRoleCodeByMemberId(agencyMemberId)
//                        被调用1次，通过mock验证确保方法调用的参数和次数正确。\",\n" +
//                        "  \n" +
//                        "  \"test intention\":
//                        \"该测试用例旨在验证当成员是AgencyX类型且其对应的代理成员具有'Intelligent_strategy_proxy_white'角色时，fillAgencyXRole
//                        方法能够正确识别并将该角色添加到结果集合中。这是一个正向的成功场景测试，验证了方法在所有前置条件都满足时的核心业务逻辑：代理成员角色的继承和角色权限的传递机制，确保AgencyX
//                        成员能够获得其代理成员的智能策略代理白名单角色权限。\"\n" +
//                        "}\n"+
//                        "```\n"
//        );
//
//        return result.toString();
//    }
//    public String Class_java() {
//        return "\n# 现在请你来完成下面这个任务，\n## 1、目标java方法所在类：\n"+this.Class_java;
//    }
//    public String Struct_Example(){
//        StringBuilder result=new StringBuilder();
//        result.append("\n# 示例输出结构：\n"+
//                "```json\n"+
//                "{\n" +
//                "  \"path analysis\": \"...\",\n" +
//                "  \n" +
//                "  \"input data construction\": \"...\",\n" +
//                "  \n" +
//                "  \"verification points\": \"...\",\n" +
//                "  \n" +
//                "  \"test intention\": \"...\"\n" +
//                "}\n"+
//                "```");
//
//        return result.toString();
//    }
//    public String promptBuild(String csvFilePath,String targetMethodName,String targetPathId,String saveFile){
//        try (CSVReader reader = new CSVReader(new FileReader(csvFilePath))) {
//            // 跳过标题行（如果有）
//            reader.readNext();
//            String[] nextLine;
//            while ((nextLine = reader.readNext()) != null) {
//                // 检查方法名和路径ID是否匹配
//                if (nextLine.length >= 2 &&
//                        nextLine[0].trim().equals(targetMethodName) &&
//                        nextLine[1].trim().equals(targetPathId)) {
//                    StringBuilder result = new StringBuilder();
//                    result.append(this.Role());
//                    result.append(this.good_example());
//                    result.append(this.Class_java());
//                    result.append(this.method_java());
//                    result.append("待测方法为："+targetMethodName+"\n");
//                    result.append(this.JimpleDependencyBranch_for1Path(nextLine));
//                    result.append(this.dependency_stage1(nextLine));
//                    result.append(this.COT());
//                    //result.append(this.constraint());
//                    result.append(this.Struct_Example());
//                    PromptSave2TXT(result.toString(),saveFile);
//                    return result.toString();
//                }
//            }
//            System.out.println("未找到匹配的行");
//            return null;
//        } catch (IOException | CsvValidationException e) {
//            System.err.println("读取文件时发生错误: " + e.getMessage());
//            e.printStackTrace();
//        }
//        return null;
//    }
//    public void PromptSave2TXT(String prompt,String fileName){
//        try {
//            // 创建File对象
//            File file = new File(fileName);
//            FileWriter fw = new FileWriter(file, false);
//            BufferedWriter bw = new BufferedWriter(fw);
//            bw.write(prompt);
//            bw.close();
//            System.out.println("内容已成功写入 " + fileName);
//        } catch (IOException e) {
//            System.out.println("写入文件时发生错误：" + e.getMessage());
//            e.printStackTrace();
//        }
//    }
//    public void AllPromptBuildAndSave2TXT(String csvFilePath,String targetMethodName,String saveDir){
//        for(int i=1;;i++){
//            String targetPathId=String.valueOf(i);
//            String saveFile=saveDir+"/"+targetPathId+".txt";
//            if(promptBuild(csvFilePath,targetMethodName,targetPathId,saveFile)==null) break;
//        }
//    }
//    public String parseSimpleClassAndMethodName(String input) {
//        if (input == null || input.isEmpty()) {
//            return "";
//        }
//
//        try {
//            // 1. 查找类名标记
//            String classNameMarker = "_CLASSNAME_";
//            String functionNameMarker = "_FUNCTIONNAME_";
//            String returnNameMarker="_RETURNTYPE_";
//
//            // 2. 获取完整类名
//            int classNameStart = input.indexOf(classNameMarker) + classNameMarker.length();
//            int classNameEnd = input.indexOf("_FUNCTIONNAME_");
//            String fullClassName = input.substring(classNameStart, classNameEnd);
//
//            // 3. 提取简单类名（取最后一个点后面的部分）
//            String simpleClassName = fullClassName.substring(fullClassName.lastIndexOf('.') + 1);
//
//            // 4. 获取方法名
//            int functionNameStart = classNameEnd + functionNameMarker.length();
//            int functionNameEnd = input.indexOf("_RETURNTYPE_");
//            String methodName = input.substring(functionNameStart, functionNameEnd);
//
//            //获取返回值类型
//            int returnNameStart=functionNameEnd+returnNameMarker.length();
//            int returnNameEnd=input.indexOf("_Parameters_");
//            String returnName=input.substring(returnNameStart,returnNameEnd);
//
//            // 5. 返回组合后的结果
//            return simpleClassName + "+" + methodName+"+"+returnName;
//        } catch (Exception e) {
//            return "";
//        }
//    }
//    public static String[] getUniqueFirstColumnValues(String csvFilePath) {
//        Set<String> uniqueValues = new HashSet<>();
//        List<String> originalValues = new ArrayList<>();
//
//        try (CSVReader reader = new CSVReader(new FileReader(csvFilePath))) {
//            // 跳过标题行
//            reader.readNext();
//            String[] nextLine;
//            while ((nextLine = reader.readNext()) != null) {
//                if (nextLine.length > 0) {
//                    String firstColumnValue = nextLine[0].trim();
//                    originalValues.add(firstColumnValue);
//                    uniqueValues.add(firstColumnValue);
//                }
//            }
//            return uniqueValues.toArray(new String[0]);
//
//        } catch (IOException | CsvValidationException e) {
//            System.err.println("读取文件时发生错误: " + e.getMessage());
//            e.printStackTrace();
//            return new String[0];
//        }
//    }
//
//
//    public static void main(String[] args) {
//
//        //stage1:
//        String csvFilePath = "AllCFGPath.csv";
//        String [] targetMethodInfs= stage1.getUniqueFirstColumnValues(csvFilePath);
//        for(String targetMethodInf:targetMethodInfs){
//            System.out.println("targetMethodInf:"+targetMethodInf);
//            javaMethodFind processor = new javaMethodFind();
////          String methodContent = processor.getMethodContent(targetMethodInf);
//            if (!processor.ExistMethod(targetMethodInf)) {//判断条件：存在且为public，且返回值一样
//                continue;
//            }
//            String methodContent = processor.getClassContent(targetMethodInf);
//            String classname = processor.extractClassName(targetMethodInf);
//            if(!methodContent.isEmpty())
//            {
//                System.out.println(targetMethodInf);
//                System.out.println(methodContent);//构建prompt存放dir
//                stage1 promprBuilder = new stage1();
//                promprBuilder.method_java=methodContent;
//                promprBuilder.Class_java=classname;
//                String saveDir="./Prompt/stage1/"+promprBuilder.parseSimpleClassAndMethodName(targetMethodInf);
//                boolean result = PathUtils.ensureDirectoryExists(saveDir);
//                if (result) {
//                    System.out.println("目录存在或已成功创建。"+saveDir);
//                } else {
//                    System.out.println("目录创建失败或路径被占用。");
//                }
//                //prompt产生
//                promprBuilder.AllPromptBuildAndSave2TXT(csvFilePath,targetMethodInf,saveDir);
//                //构建LLM输出dir
//                String outDir="./Output/stage1/"+promprBuilder.parseSimpleClassAndMethodName(targetMethodInf);
//                result = PathUtils.ensureDirectoryExists(outDir);
//                if (result) {
//                    System.out.println("目录存在或已成功创建。"+outDir);
//                } else {
//                    System.out.println("目录创建失败或路径被占用。");
//                }
//            }
//        }
//        Starter.cleanupDirectories("./Prompt/stage1");
//    }
//}
//

package com.alibaba.ad.code.promptProduce;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.val;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
public class Stage1 {
    public String method_java;
    public String Class_java;
    public String taskCreateTime;

    public String Role() {
        StringBuilder role = new StringBuilder();
        role.append("# Role:\n" +
            "You are a Java method test case input data generator. Your task is:\n" +
            "You need to understand the Java method I provide, and based on the specified execution path (represented"
            + " in Jimple intermediate code) and related branch information, please output in 'descriptive language' "
            + "how to construct input data to effectively cover this path, which variables or properties need to be "
            + "initialized, which methods need to be mocked, and how to construct test method verification points. "
            + "Finally, summarize the test intention of this data set.\n"
            );
        return role.toString();
    }

    public String method_java() {
        return "\n## 2. Target Java Method Source Code:\n" + "```java\n" + this.method_java + "\n```\n";
    }

    public String JimpleDependencyBranch_for1Path(String[] line) {
        StringBuilder result = new StringBuilder();
        result.append(
            "\n## 3. Execution path your generated data needs to cover, represented in intermediate code"
                + " (Jimple):\n");
        result.append("```jimple\n");
        result.append(line[2].trim()).append("\n");
        result.append("\n");
        result.append("```\n");
        result.append("Below is supplementary branch information for this path, please make full use of it\n");
        result.append("\n");
        result.append("## 4. Branch information in the path:\n");
        result.append("```\n");
        for (int i = 4; i < line.length; i++) {
            if (line[i].trim().equals("NAN")) {
                break;
            } else {
                result.append(line[i].trim()).append("\n");
            }
        }
        result.append("\n");
        result.append("```\n");
        return result.toString();
    }

    public String COT() {
        StringBuilder result = new StringBuilder();
        result.append("\n# Work Steps:\n" +
            "1. Parse method logic, read and understand Java method functionality\n" +
            "2. Map path to source code, convert Jimple path to corresponding execution path in Java source code, "
            + "clarify branch selection results on this path\n"
            +
            "3. Analyze dependencies and constraints, combine branch conditions to determine constraints input "
            + "variables should satisfy\n"
            +
            "4. Use 'descriptive language' to construct input data so I can construct input data according to your "
            + "description that will make the program execute along the specified path at runtime\n"
            +
            "5. Use 'descriptive language' to construct test method verification points\n" +
            "6. Summarize the test intention of this data set\n" +
            "7. You need to output 'path analysis', 'input data construction', 'verification points', 'test "
            + "intention' in JSON format using descriptive language. I will store your output directly in a .json "
            + "file, so please do not output any irrelevant content. Your output should start with '{' not '```json'\n"
        );
        return result.toString();
    }

    public String constraint() {
        StringBuilder result = new StringBuilder();
        return result.toString();
    }

    public String good_example() {
        StringBuilder result = new StringBuilder();
        result.append("# # Please refer to the following task example\n" +
            "## 1、Target Java class:\n" +
            "com.taobao.ad.brand.bp.domain.account.atomability.DefaultAccountAdcRoleGetAbility\n" +
            "## 2、Target method:\n" +
            "```java\n" +
            "    private void fillAgencyXRole(HashSet<String> adcRoleSet, Long memberId) {\n" +
            "        if (!memberRepository.isAgencyX(memberId)) {\n" +
            "            return;\n" +
            "        }\n" +
            "        Long agencyMemberId = memberRepository.queryAgencyMemberId(memberId);\n" +
            "        if (agencyMemberId == null) {\n" +
            "            return;\n" +
            "        }\n" +
            "        Set<String> mainUicRoleCodeSet = memberRepository.findRoleCodeByMemberId(agencyMemberId);\n" +
            "        if (CollectionUtils.isNotEmpty(mainUicRoleCodeSet) && mainUicRoleCodeSet.contains"
            + "(AdcRoleConstant.INTELLIGENT_STRATEGY_PROXY_WHITE)) {\n"
            +
            "            adcRoleSet.add(AdcRoleConstant.INTELLIGENT_STRATEGY_PROXY_WHITE);\n" +
            "        }\n" +
            "    }\n" +
            "\n" +
            "```\n" +
            "## 3、Execution path in Jimple intermediate code:\n" +
            "```\n" +
            "### 1 : this := @this: com.taobao.ad.brand.bp.domain.account.atomability"
            + ".DefaultAccountAdcRoleGetAbility### 2 : adcRoleSet := @parameter0: java.util.HashSet### 3 : memberId "
            + ":= @parameter1: java.lang.Long### 4 : $stack5 = this.<com.taobao.ad.brand.bp.domain.account"
            + ".atomability.DefaultAccountAdcRoleGetAbility: com.taobao.ad.brand.bp.domain.memeber.MemberRepository "
            + "memberRepository>### 5 : $stack6 = interfaceinvoke $stack5.<com.taobao.ad.brand.bp.domain.memeber"
            + ".MemberRepository: java.lang.Boolean isAgencyX(java.lang.Long)>(memberId)### 6 : $stack7 = "
            + "virtualinvoke $stack6.<java.lang.Boolean: boolean booleanValue()>()### 7 : if $stack7 != 0### 9 : "
            + "$stack8 = this.<com.taobao.ad.brand.bp.domain.account.atomability.DefaultAccountAdcRoleGetAbility: com"
            + ".taobao.ad.brand.bp.domain.memeber.MemberRepository memberRepository>### 10 : agencyMemberId = "
            + "interfaceinvoke $stack8.<com.taobao.ad.brand.bp.domain.memeber.MemberRepository: java.lang.Long "
            + "queryAgencyMemberId(java.lang.Long)>(memberId)### 11 : if agencyMemberId != null### 13 : $stack9 = "
            + "this.<com.taobao.ad.brand.bp.domain.account.atomability.DefaultAccountAdcRoleGetAbility: com.taobao.ad"
            + ".brand.bp.domain.memeber.MemberRepository memberRepository>### 14 : mainUicRoleCodeSet = "
            + "interfaceinvoke $stack9.<com.taobao.ad.brand.bp.domain.memeber.MemberRepository: java.util.Set "
            + "findRoleCodeByMemberId(java.lang.Long)>(agencyMemberId)### 15 : $stack10 = staticinvoke <org.apache"
            + ".commons.collections.CollectionUtils: boolean isNotEmpty(java.util.Collection)>(mainUicRoleCodeSet)###"
            + " 16 : if $stack10 == 0### 17 : $stack11 = interfaceinvoke mainUicRoleCodeSet.<java.util.Set: boolean "
            + "contains(java.lang.Object)>(\"Intelligent_strategy_proxy_white\")### 18 : if $stack11 == 0### 19 : "
            + "virtualinvoke adcRoleSet.<java.util.HashSet: boolean add(java.lang.Object)>"
            + "(\"Intelligent_strategy_proxy_white\")### 20 : return\n"
            +
            "```" +
            "\n" +
            //                "4、路径中的数据依赖：\n" +
            //                "The variable \"$stack6\" in the statement numbered 6 was assigned: ###5 $stack6 =
            //                interfaceinvoke $stack5.<com.taobao.ad.brand.bp.domain.memeber.MemberRepository: java
            //                .lang.Boolean isAgencyX(java.lang.Long)>(memberId);\n" +
            //                "The variable \"$stack7\" in the statement numbered 7 was assigned: ###6 $stack7 =
            //                virtualinvoke $stack6.<java.lang.Boolean: boolean booleanValue()>();\n" +
            //                "The variable \"agencyMemberId\" in the statement numbered 11 was assigned: ###10
            //                agencyMemberId = interfaceinvoke $stack8.<com.taobao.ad.brand.bp.domain.memeber
            //                .MemberRepository: java.lang.Long queryAgencyMemberId(java.lang.Long)>(memberId);\n" +
            //                "The variable \"mainUicRoleCodeSet\" in the statement numbered 15 was assigned: ###14
            //                mainUicRoleCodeSet = interfaceinvoke $stack9.<com.taobao.ad.brand.bp.domain.memeber
            //                .MemberRepository: java.util.Set findRoleCodeByMemberId(java.lang.Long)>
            //                (agencyMemberId);\n" +
            //                "The variable \"$stack10\" in the statement numbered 16 was assigned: ###15 $stack10 =
            //                staticinvoke <org.apache.commons.collections.CollectionUtils: boolean isNotEmpty(java
            //                .util.Collection)>(mainUicRoleCodeSet);\n" +
            //                "The variable \"$stack11\" in the statement numbered 18 was assigned: ###17 $stack11 =
            //                interfaceinvoke mainUicRoleCodeSet.<java.util.Set: boolean contains(java.lang.Object)>
            //                (\"Intelligent_strategy_proxy_white\");\n" +
            //                "The variable \"adcRoleSet\" in the statement numbered 19 was assigned: ###2 adcRoleSet
            //                := @parameter0: java.util.HashSet;\n" +
            //                "\n" +
            "## 4、Branch information in the path：\n" +
            "```\n" +
            "节点编号7为if分支语句，判断条件为if $stack7 != 0。if分支语句的true分支为$stack8 = this.<com.taobao.ad.brand.bp.domain.account"
            + ".atomability.DefaultAccountAdcRoleGetAbility: com.taobao.ad.brand.bp.domain.memeber.MemberRepository "
            + "memberRepository>，false分支为return。其中的栈信息为：[$stack7 = virtualinvoke$stack6.<java.lang"
            + ".Boolean:booleanbooleanValue()>(), $stack8 = this.<com.taobao.ad.brand.bp.domain.account.atomability"
            + ".DefaultAccountAdcRoleGetAbility:com.taobao.ad.brand.bp.domain.memeber"
            + ".MemberRepositorymemberRepository>]。\n"
            +
            "节点编号11为if分支语句，判断条件为if agencyMemberId != null。if分支语句的true分支为$stack9 = this.<com.taobao.ad.brand.bp.domain"
            + ".account.atomability.DefaultAccountAdcRoleGetAbility: com.taobao.ad.brand.bp.domain.memeber"
            + ".MemberRepository memberRepository>，false分支为return。其中的栈信息为：[$stack9 = this.<com.taobao.ad.brand.bp"
            + ".domain.account.atomability.DefaultAccountAdcRoleGetAbility:com.taobao.ad.brand.bp.domain.memeber"
            + ".MemberRepositorymemberRepository>]。\n"
            +
            "节点编号16为if分支语句，判断条件为if $stack10 == 0。if分支语句的true分支为return，false分支为$stack11 = interfaceinvoke "
            + "mainUicRoleCodeSet.<java.util.Set: boolean contains(java.lang.Object)>"
            + "(\"Intelligent_strategy_proxy_white\")。其中的栈信息为：[$stack10 = staticinvoke<org.apache.commons.collections"
            + ".CollectionUtils:booleanisNotEmpty(java.util.Collection)>(mainUicRoleCodeSet), $stack11 = "
            + "interfaceinvokemainUicRoleCodeSet.<java.util.Set:booleancontains(java.lang.Object)>"
            + "(\"Intelligent_strategy_proxy_white\")]。\n"
            +
            "节点编号18为if分支语句，判断条件为if $stack11 == 0。if分支语句的true分支为return，false分支为virtualinvoke adcRoleSet.<java.util"
            + ".HashSet: boolean add(java.lang.Object)>(\"Intelligent_strategy_proxy_white\")。其中的栈信息为：[$stack11 = "
            + "interfaceinvokemainUicRoleCodeSet.<java.util.Set:booleancontains(java.lang.Object)>"
            + "(\"Intelligent_strategy_proxy_white\")]。\n"
            +
            "```\n" +
            "Based on the above input information (class name, method source code, path information, branch "
            + "information), you need to output the following JSON structure:\n"
            +
            "```json\n" +
            "{\n" +
            "  \"path analysis\": \"This execution path covers the complete success flow of the fillAgencyXRole "
            + "method: First, checks if the member is AgencyX type through memberRepository.isAgencyX(memberId), "
            + "returns true to enter main logic; Then gets the agency member ID via memberRepository"
            + ".queryAgencyMemberId(memberId), returns non-null value to continue; Next gets role code collection "
            + "through memberRepository.findRoleCodeByMemberId(agencyMemberId), returns non-empty set containing "
            + "'Intelligent_strategy_proxy_white' role; Finally adds this role to the input adcRoleSet. The path goes"
            + " through 4 key branch conditions: isAgencyX returns true, agencyMemberId is non-null, role set is "
            + "non-empty, role set contains target role - all conditions must be met to reach the final add operation"
            + ".\",\n"
            +
            "\n" +
            "  \"input data construction\": \"The following input data needs to be prepared: 1) Create an empty "
            + "HashSet<String> as adcRoleSet parameter; 2) Create a valid Long type memberId as member ID parameter; "
            + "3) Mock MemberRepository's three methods: isAgencyX(memberId) returns Boolean.TRUE, "
            + "queryAgencyMemberId(memberId) returns a non-null Long value (like 1001L) as agencyMemberId, "
            + "findRoleCodeByMemberId(agencyMemberId) returns a non-empty Set containing "
            + "'Intelligent_strategy_proxy_white' string (like Set.of('Intelligent_strategy_proxy_white', "
            + "'other_role')); 4) Need to initialize DefaultAccountAdcRoleGetAbility instance and inject the mocked "
            + "MemberRepository into its memberRepository field.\",\n"
            +
            "\n" +
            "  \"verification points\": \"Verify that adcRoleSet contains 'Intelligent_strategy_proxy_white' role "
            + "after execution, specifically: 1) Verify adcRoleSet.size() equals 1, confirming only one role was "
            + "added; 2) Verify adcRoleSet.contains('Intelligent_strategy_proxy_white') returns true, confirming the "
            + "target role was correctly added; 3) Verify all three memberRepository methods were correctly called: "
            + "isAgencyX(memberId) called once, queryAgencyMemberId(memberId) called once, findRoleCodeByMemberId"
            + "(agencyMemberId) called once, using mock verification to ensure correct parameters and call counts.\",\n"
            +
            "\n" +
            "  \"test intention\": \"This test case aims to verify that when a member is AgencyX type and their "
            + "corresponding agency member has the 'Intelligent_strategy_proxy_white' role, the fillAgencyXRole "
            + "method correctly identifies and adds this role to the result set. This is a positive success scenario "
            + "test, verifying the core business logic when all preconditions are met: the inheritance of agency "
            + "member roles and role permission transfer mechanism, ensuring AgencyX members can obtain their agency "
            + "member's intelligent strategy proxy whitelist role permissions.\"\n"
            +
            "}\n" +
            "```\n"
        );

        return result.toString();
    }

    public String Class_java() {
        return "\n# Task Information:\n"
            + "## The class containing the target Java method: `" + this.Class_java + "` \n";
    }

    public String Struct_Example() {
        StringBuilder result = new StringBuilder();
        result.append("\n# Example output structure：\n" +
            "```json\n" +
            "{\n" +
            "  \"path analysis\": \"...\",\n" +
            "  \n" +
            "  \"input data construction\": \"...\",\n" +
            "  \n" +
            "  \"verification points\": \"...\",\n" +
            "  \n" +
            "  \"test intention\": \"...\"\n" +
            "}\n" +
            "```");

        return result.toString();
    }

    public String promptBuildOpt(String csvFilePath, String targetMethodName, String targetPathId, String saveFile,
        Map<String, List<String>> cfgInfoMap) {
        String key = targetMethodName + "%%" + targetPathId;
        if (!cfgInfoMap.containsKey(key)) {
            return null;
        }
        StringBuilder result = new StringBuilder();
        result.append(this.Role());
        //result.append(this.good_example());
        result.append(this.Class_java());
        result.append(this.method_java());
        result.append("The method to be tested is：`" + targetMethodName + "` \n");
        result.append(this.JimpleDependencyBranch_for1Path(cfgInfoMap.get(key).toArray(new String[0])));
        result.append(this.COT());
        //result.append(this.constraint());
        result.append(this.Struct_Example());
        // 暂时不写本地
        //PromptSave2TXT(result.toString(), saveFile);
        return result.toString();
    }

    public String promptBuild(String csvFilePath, String targetMethodName, String targetPathId, String saveFile) {
        try (CSVReader reader = new CSVReader(new FileReader(csvFilePath))) {
            // 跳过标题行（如果有）
            reader.readNext();
            String[] nextLine;
            while ((nextLine = reader.readNext()) != null) {
                // 检查方法名和路径ID是否匹配
                if (nextLine.length >= 2 &&
                    nextLine[0].trim().equals(targetMethodName) &&
                    nextLine[1].trim().equals(targetPathId)) {
                    StringBuilder result = new StringBuilder();
                    result.append(this.Role());
                    //result.append(this.good_example());
                    result.append(this.Class_java());
                    result.append(this.method_java());
                    result.append("The method to be tested is：`" + targetMethodName + "` \n");
                    result.append(this.JimpleDependencyBranch_for1Path(nextLine));
                    result.append(this.COT());
                    //result.append(this.constraint());
                    result.append(this.Struct_Example());
                    // 暂时不写本地
                    //PromptSave2TXT(result.toString(), saveFile);
                    return result.toString();
                }
            }
            //System.out.println("未找到匹配的行");
            return null;
        } catch (IOException | CsvValidationException e) {
            //System.err.println("读取文件时发生错误: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }

    public void PromptSave2TXT(String prompt, String fileName) {
        try {
            // 创建File对象
            File file = new File(fileName);
            FileWriter fw = new FileWriter(file, false);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(prompt);
            bw.close();
            System.out.println("内容已成功写入 " + fileName);
        } catch (IOException e) {
            System.out.println("写入文件时发生错误：" + e.getMessage());
            e.printStackTrace();
        }
    }

    public Map<String, String> AllPromptBuildAndSave2TXT(String csvFilePath, String targetMethodName, String saveDir,
        Map<String, List<String>> cfgInfoMap) {
        Map<String, String> saveFileMap = new HashMap<>();
        for (int i = 1; ; i++) {
            if (i > 15) {
                break;
            }
            String targetPathId = String.valueOf(i);
            String saveFile = saveDir + "/" + targetPathId + ".txt";
            String result = promptBuildOpt(csvFilePath, targetMethodName, targetPathId, saveFile, cfgInfoMap);
            if (result == null) {
                break;
            } else {
                saveFileMap.put(saveFile, result);
            }
        }
        return saveFileMap;
    }

    public String parseSimpleClassAndMethodName(String input) {
        if (input == null || input.isEmpty()) {
            return "";
        }

        try {
            // 1. 查找类名标记
            String classNameMarker = "_CLASSNAME_";
            String functionNameMarker = "_FUNCTIONNAME_";
            String returnNameMarker = "_RETURNTYPE_";

            // 2. 获取完整类名
            int classNameStart = input.indexOf(classNameMarker) + classNameMarker.length();
            int classNameEnd = input.indexOf("_FUNCTIONNAME_");
            String fullClassName = input.substring(classNameStart, classNameEnd);

            // 3. 提取简单类名（取最后一个点后面的部分）
            String simpleClassName = fullClassName.substring(fullClassName.lastIndexOf('.') + 1);

            // 4. 获取方法名
            int functionNameStart = classNameEnd + functionNameMarker.length();
            int functionNameEnd = input.indexOf("_RETURNTYPE_");
            String methodName = input.substring(functionNameStart, functionNameEnd);

            //获取返回值类型
            int returnNameStart = functionNameEnd + returnNameMarker.length();
            int returnNameEnd = input.indexOf("_Parameters_");
            String returnName = input.substring(returnNameStart, returnNameEnd);

            // 5. 返回组合后的结果
            return simpleClassName + "+" + methodName + "+" + returnName;
        } catch (Exception e) {
            return "";
        }
    }

    public static ArrayList<ArrayList<String>> getAllColumnValues(String csvFilePath) {
        ArrayList<ArrayList<String>> allColumnValueList = new ArrayList<>();

        try (CSVReader reader = new CSVReader(new FileReader(csvFilePath))) {
            // 跳过标题行
            reader.readNext();
            String[] nextLine;
            while ((nextLine = reader.readNext()) != null) {
                if (nextLine.length > 0) {
                    ArrayList<String> addLine = new ArrayList<>(Arrays.asList(nextLine));
                    allColumnValueList.add(addLine);
                }
            }
            return allColumnValueList;
        } catch (IOException | CsvValidationException e) {
            System.err.println("读取文件时发生错误: " + e.getMessage());
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    public static String[] getUniqueFirstColumnValues(String csvFilePath) {
        Set<String> uniqueValues = new HashSet<>();
        List<String> originalValues = new ArrayList<>();
        try (FileReader fileReader = new FileReader(csvFilePath);
             CSVParser parser = new CSVParser(fileReader, CSVFormat.DEFAULT.withFirstRecordAsHeader())) {
            for (CSVRecord record : parser) {
                String firstColumnValue = record.get(0).trim();
                if (!firstColumnValue.isEmpty()) {
                    originalValues.add(firstColumnValue);
                    uniqueValues.add(firstColumnValue);
                }
            }
            return uniqueValues.toArray(new String[0]);

        } catch (IOException e) {
            System.err.println("读取文件时发生错误: " + e.getMessage());
            e.printStackTrace();
            return new String[0];
        }

        //        try (CSVReader reader = new CSVReader(new FileReader(csvFilePath))) {
        //            // 跳过标题行
        //            reader.readNext();
        //            String[] nextLine;
        //            while ((nextLine = reader.readNext()) != null) {
        //                if (nextLine.length > 0) {
        //                    String firstColumnValue = nextLine[0].trim();
        //                    originalValues.add(firstColumnValue);
        //                    uniqueValues.add(firstColumnValue);
        //                }
        //            }
        //            for(String s:originalValues){
        //                System.out.println(s);
        //            }
        //            return uniqueValues.toArray(new String[0]);
        //
        //        } catch (IOException | CsvValidationException e) {
        //            System.err.println("读取文件时发生错误: " + e.getMessage());
        //            e.printStackTrace();
        //            return new String[0];
        //        }
    }

    public Stage1(String taskCreateTime) {
        this.taskCreateTime = taskCreateTime;
    }

    public static void main(String[] args) {
    }
}
