package com.alibaba.ad.code.promptProduce;

import java.io.File;

public class PathUtils {

    /**
     * 检查指定路径的目录是否存在，若不存在则创建该目录及其所有必需父目录。
     *
     * @param path 要检查/创建的目录路径
     * @return 如果目录已存在或成功创建则返回true；如果路径已存在但为文件，或目录创建失败则返回false
     */
    public static boolean ensureDirectoryExists(String path) {
        File directory = new File(path);
        if (directory.exists()) {
            return directory.isDirectory(); // 路径存在且为目录时返回true
        }
        return directory.mkdirs(); // 尝试创建目录，返回操作结果
    }
}
