package com.alibaba.ad.code.oss;

import com.aliyun.oss.OSS;
import com.aliyun.oss.model.OSSObject;
import com.aliyun.oss.model.PutObjectRequest;
import lombok.extern.slf4j.Slf4j;

import java.io.*;

//*
// * @author: fudai.yf
// * @since: 2022/8/11
//
//
@Slf4j
public class OssTools {
//
//*
//     * Tools used to write content to OSS object.
//     * @param ossClient OSS client used to operate OSS resource.
//     * @param bucketName name of operated OSS bucket.
//     * @param objectName name of operated OSS object.
//     * @param data data needed to be written to OSS object.
//     * @return content of OSS object.
//
//
    public static String writeObjectContent(OSS ossClient, String bucketName, String objectName, String data) {
        try {
            PutObjectRequest req = new PutObjectRequest(bucketName, objectName, new ByteArrayInputStream(data.getBytes("UTF-8")));
            ossClient.putObject(req);
        } catch (Exception e) {
            log.error("OssTools::writeObjectContent error", e);
        }

        return data;
    }
//
//*
//     * Tools used to read object content from OSS object.
//     * @param ossObject OSS object which needed to be read.
//     * @return content of OSS object.
//     * @throws IOException throw this exception when failed to read content from object.
//
//
    public static String readObjectContent(OSSObject ossObject) throws IOException {
        try (
            // Opens an input stream object which is created from above OSS object.
            InputStream inputStream = ossObject.getObjectContent();
            InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
            BufferedReader reader = new BufferedReader(inputStreamReader)
        ) {
            // Loads all content of the OSS object.
            StringBuilder builder = new StringBuilder();
            for (String line = reader.readLine(); line != null; line = reader.readLine()) {
                if (builder.length() > 0) {
                    builder.append('\n');
                }
                builder.append(line);
            }
            return builder.toString();
        }
    }

    public static void copyFileToLocal(OSSObject ossObject, String localPath) {
        InputStream inputStream = ossObject.getObjectContent();
        try (FileOutputStream fos = new FileOutputStream(localPath)) {
            byte[] buffer = new byte[1024];
            int length;
            while ((length = inputStream.read(buffer)) > 0) {
                fos.write(buffer, 0, length);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                inputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
