package com.alibaba.ad.code.cfganalyser.code.util;

import com.alibaba.ad.code.cfganalyser.code.CFGGeneration;
import com.alibaba.ad.code.cfganalyser.code.DependencyGeneration;
import com.alibaba.ad.code.promptProduce.JavaMethodFind;
import com.github.javaparser.JavaParser;
import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.google.common.collect.Sets;
import com.opencsv.CSVReader;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import sootup.core.graph.StmtGraph;
import sootup.core.inputlocation.AnalysisInputLocation;
import sootup.core.jimple.basic.Value;
import sootup.core.jimple.common.stmt.Stmt;
import sootup.core.model.SootClass;
import sootup.core.model.SootMethod;
import sootup.core.model.SourceType;
import sootup.core.views.View;
import sootup.java.bytecode.frontend.inputlocation.PathBasedAnalysisInputLocation;
import sootup.java.core.views.JavaView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.CodeSource;
import java.security.ProtectionDomain;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class DependencyUtil {

    private static final String deepDependencyFilePath = "DeepClassDependency.csv";
    private Map<String,String[]> deepDependencyMap = null;

    private static final String souceCodePath = "FunctionToCode.csv";
    private Map<String,String[]> sourceCodeMap = null;

    private static final String routeDeepDependencyPath = "RouteDeepDependency.csv";
    private Map<String,String[]> routeDeepDependencyMap = null;

    private static final String classDeepDependencyPath = "ClassDeepDependency.csv";
    private Map<String,String[]> classDeepDependencyMap = null;

    private static final String routeCodeSourcePath = "RouteCodeDependency.csv";
    private Map<String,String[]> routeCodeSourceMap = null;

    private static final String cfgInformationCodePath = "AllCFGPath.csv";
    private Map<String,String[]> cfgInformationMap = null;

    private final Map<String,String> classEmbeddingToCodeMap = new HashMap<>();

    public String saveFileDir;

    public DependencyUtil(String saveDir){
        this.saveFileDir = saveDir;
    }

    public Map<String,String[]> getFunctionCodeMap(String saveDir){
        String savePath = (saveDir == null)?souceCodePath:Paths.get(saveDir,souceCodePath).toString();
        if(sourceCodeMap == null) sourceCodeMap = GetRouteCodeMapFromCSVFile(souceCodePath);
        return sourceCodeMap;
    }
    /**
     *
     * String csvFilePath = "DependenceSaveFiles/AllDependency.csv";
     * ArrayList<String> csvHeaders = new ArrayList<>();
     * csvHeaders.add("ClassName");csvHeaders.add("MethodEmbedding"); csvHeaders.add("MethodName");csvHeaders.add("MethodReturnType");csvHeaders.add("MethodParameters"); csvHeaders.add("FatherClassName");
     * csvHeaders.add("Import");csvHeaders.add("ClassComment");csvHeaders.add("MethodComment");csvHeaders.add("ClassFields");csvHeaders.add("ClassAnnotatinos");
     * for(int methodUseIndex = 1;methodUseIndex <= maxPathLenth;methodUseIndex ++ ){
     *     csvHeaders.add("MethodUseName_"+methodUseIndex);csvHeaders.add("UsedMethodComment_"+methodUseIndex);
     * }
     */
    public String DependencyPromptFetch(String FilePath,String targetMethodInf){

        StringBuilder dependencyPrompt = new StringBuilder("And Here is some dependency offered for helping you better understanding the Function:\n");
        dependencyPrompt.append("(1) ClassName: this tells where the function is \n(2) FaClassName : this tells the superclass of the class the method belongs to\n")
                .append("(3) Import: this tells which import statements are used \n(4) ClassComment: this tells the  class-level comments\n")
                .append("(5) MethodComment: this tells the comment about the method \n(6) ClassFields: this tells the attributes about the Class\n")
                .append("(7) ClassAnnotatinos: this tells the Annotations used by the class\n(8) MethodUseName: this tells which functions are called by this function\n")
                .append("(9) UsedMethodComment: this tells the comment about the called function just mentioned on the 'MethodUseName'\n");
        dependencyPrompt.append("Now Here is some dependency information about the function which you need to write test for:\n\n");
        try (CSVReader reader = new CSVReader(new FileReader(FilePath))) {
            String[] line;String[] titleLine = new String[0];
            int lineNum = 0;boolean isFindDependency = false;
            while ((line = reader.readNext()) != null) {
                if(lineNum == 0){
                    titleLine = line; ++ lineNum;continue;
                }
                try {
                    String methodEmbedding = line[1];
                    if (methodEmbedding.equals(targetMethodInf)) {
                        isFindDependency = true;
                        int embeddingLine = line.length;
                        for (int lineIndex = 0; lineIndex < embeddingLine; lineIndex++) {
                            String dependencyName = titleLine[lineIndex];
                            if(!(lineIndex >= 1 && lineIndex <= 4) && line[lineIndex] != null && !line[lineIndex].isEmpty()) dependencyPrompt.append(dependencyName).append(":  ").append(line[lineIndex]).append("\n");
                        }
                    }
                }catch (Exception e){e.printStackTrace();
                    System.err.println("[Warning]: No Dependency is Found");return "";}
            }

            if(!isFindDependency){
                System.err.println("[Warning]: No Dependency is Found");return "";
            }
            else return dependencyPrompt.toString();
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("[Warning]: No Dependency is Found");return "";
        }
    }

    @Deprecated
    public void getClassAndCodeUnderPackage(String rootPath){
        File rootDir = new File(rootPath); // 替换为你的项目源码目录
        JavaParser parser = new JavaParser();
        List<File> javaFiles = findJavaFiles(rootDir);


        for (File file : javaFiles) {
            try (FileInputStream in = new FileInputStream(file)) {
                // 解析 Java 文件为 CompilationUnit（AST）
                if(parser.parse(in).getResult().isPresent()){
                    CompilationUnit cu = StaticJavaParser.parse(file);
                    Optional<ClassOrInterfaceDeclaration> classRef = cu.getClassByName(file.getName().substring(0,file.getName().lastIndexOf(".")));
                    //System.out.println(file.getName().substring(0,file.getName().lastIndexOf(".")));
                    if(classRef.isPresent()){
                        System.out.println(classRef.get().getNameAsString());
                        System.out.println("ClassName: " + rootPath + "/" + file.getName());
                        System.out.println("Class: " + classRef.get().getNameAsString());
                        for(MethodDeclaration methodDeclaration:classRef.get().getMethods()){
                            System.out.println("Method: " + methodDeclaration.getName());
                            System.out.println("Code: " + methodDeclaration.getBody());
                        }
                    }
                }

                //System.out.println("解析文件: " + file.getAbsolutePath());
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }

    /**
     * 该方法用于获取依赖记录项的标题
     * @param filePath
     * @return
     */
    public static String[] getDependencyTitle(String filePath){
        try{
            CSVReader reader = new CSVReader(new FileReader(filePath));
            return reader.readNext();
        }  catch (Exception e) {
            System.err.println("[Warning]: DeepDependency Fetch Error!");return null;
        }
    }

    /**
     * 该方法用于从csv文件中获取得到每一条记录
     * 记录以Map<String,String[]>
     *     key: targetMethod 方法编码
     *     value: 依赖信息列表数组
     * </String,String[]>的方式进行存储
     * @param filePath 代表csv文件所在的未知
     * @return 返回保存依赖信息的Map
     */
    public static Map<String,String[]> GetMapFromCSVFile(String filePath){
        Map<String,String[]> sumDependencyList = new HashMap<>();
        try (CSVReader reader = new CSVReader(new FileReader(filePath))) {
            String[] line;
            int lineNum = 0;
            while ((line = reader.readNext()) != null) {
                if(lineNum == 0){++ lineNum;}
                else sumDependencyList.put(line[0],line);
            }
        } catch (Exception e) {
            System.err.println("[Warning]: CSV File Read Error!");
        }
        return sumDependencyList;
    }

    /**
     * 该方法用于从csv文件中读取得到路径依赖信息，存储方式同上
     * @param filePath csv文件所在的未知
     * @return 返回存有依赖信息的Map
     */
    public static Map<String,String[]> GetRouteMapFromCSVFile(String filePath){
        Map<String,String[]> sumDependencyList = new HashMap<>();
        try (CSVReader reader = new CSVReader(new FileReader(filePath))) {
            String[] line;
            int lineNum = 0;
            while ((line = reader.readNext()) != null) {
                if(lineNum == 0){++ lineNum;}
                else{
                    sumDependencyList.put(line[0] + line[1] + line[2],line);
                }
            }
        } catch (Exception e) {
            System.err.println("[Warning]: CSV File Read Error!");
        }
        return sumDependencyList;
    }

    /**
     * 该方法用于从csv文件中读取得到cfg路径信息，存储方式同上
     * @param filePath csv文件所在的未知
     * @return 返回存有依赖信息的Map
     */
    public static Map<String,String[]> GetCFGMapFromCSVFile(String filePath){
        Map<String,String[]> sumDependencyList = new HashMap<>();
        try (CSVReader reader = new CSVReader(new FileReader(filePath))) {
            String[] line;
            int lineNum = 0;
            while ((line = reader.readNext()) != null) {
                if(lineNum == 0){++ lineNum;}
                else{
                    sumDependencyList.put(line[0] + line[1],line);
                }
            }
        } catch (Exception e) {
            System.err.println("[Warning]: CSV File Read Error!");
        }
        return sumDependencyList;
    }

    /**
     * 该方法用于从csv文件中读取得到路径编码信息，存储方式同上
     * @param filePath csv文件所在的未知
     * @return 返回存有依赖信息的Map
     */
    public static Map<String,String[]> GetRouteCodeMapFromCSVFile(String filePath){
        Map<String,String[]> sumDependencyList = new HashMap<>();
        try (CSVReader reader = new CSVReader(new FileReader(filePath))) {
            String[] line;
            int lineNum = 0;
            while ((line = reader.readNext()) != null) {
                if(lineNum == 0){++ lineNum;}
                else{
                    sumDependencyList.put(line[0] + line[1],line);
                }
            }
        } catch (Exception e) {
            System.err.println("[Warning]: CSV File Read Error!");
        }
        return sumDependencyList;
    }

    /**
     * 该方法用于获取某一层的深度依赖信息，并将其转化为提示词字符串
     * @param dependencyMap 代表存储了依赖信息的Map
     * @param titleLine 代表获取得到的依赖的名称(ClassName,SuperClass,etc)
     * @param dependencyUseIndex 代表需要使用到的依赖信息的索引
     * @param className 代表targetMethod所在类名
     * @param depth 当前深度
     * @param importInformation 可能用到的import信息
     * @return 提示词String
     */
    public static String getDeepInformation(Map<String,String[]> dependencyMap,String[] titleLine,Integer[] dependencyUseIndex,String className,Integer depth,Set<String> importInformation){
        if(className == null) return "";
        importInformation.add("import " + className);
        StringBuilder classDependencyInformation = new StringBuilder();String faClassName = "";
        if(depth > 1) classDependencyInformation.append("第 ").append(depth).append(" 层父类依赖信息如下：\n");
        for(Integer dependencyIndex:dependencyUseIndex){
            if(!dependencyMap.containsKey(className)){
                System.err.println("No className found in Map, className: " + className);
                return "";
            }
            classDependencyInformation.append(titleLine[dependencyIndex]).append(": ").append(dependencyMap.get(className)[dependencyIndex]).append("\n");
            if(titleLine[dependencyIndex].startsWith("SuperClass")) faClassName = dependencyMap.get(className)[dependencyIndex];
        }
        classDependencyInformation.append("\n");
        if(depth <= 2) classDependencyInformation.append(getDeepInformation(dependencyMap,titleLine,dependencyUseIndex,faClassName,depth + 1,importInformation));
        return classDependencyInformation.toString();
    }

    /**
     *
     * @param filePath  获取到的dependency.csv文件路径
     * @param classNameList 需要查询依赖的列明列表
     * @param prefix 需要查询依赖的类名前缀
     * @return 三层依赖的提示词
     */
    public static String getUseAndDefDeepDependency(String filePath,Set<String> classNameList,String prefix){
        StringBuilder sumDependencyPrompt = new StringBuilder("""
                下面将为你提供这条程序路径上设计到的一些业务代码类的关键信息，这些信息包括\
                (1)业务代码类的所有属性、所有方法的签名以及该业务代码类的父类：
                (2)业务代码类的3层以内的父类的属性，方法签名信息
                
                """);

        Map<String,String[]> sumDependencyList = GetMapFromCSVFile(filePath);
        String[] title = getDependencyTitle(filePath);
        Integer[] index = new Integer[]{0,1,2,4,5,6};
        Set<String> importInformation = new TreeSet<>();

        for(String className:classNameList){
            if(!className.startsWith(prefix)) continue;
            sumDependencyPrompt.append("---------------------------------------\n");
            sumDependencyPrompt.append("以下是有关").append(className).append("这个类的依赖信息以及这个类的深层父类的信息：\n").append(getDeepInformation(sumDependencyList, title, index, className, 1,importInformation));
        }

        if(!importInformation.isEmpty()){
            sumDependencyPrompt.append("以下是你可能需要用到的import依赖：\n");
            StringBuilder importString = new StringBuilder();
            for(String importUse:importInformation) importString.append(importUse).append("\n");
            sumDependencyPrompt.append(importString);
        }
        return sumDependencyPrompt.toString();
    }

    /**
     * 该方法用于获取一个函数的深层依赖信息
     * @param filePath 深层依赖csv所在的文件位置
     * @param className 类名
     * @param prefix 需要查找的类名前缀
     * @return 函数类依赖的字符串
     */
    public String getClassDefDeepDependency(String saveDir,String filePath,String className,String prefix){
        StringBuilder sumDependencyPrompt = new StringBuilder();

        if(deepDependencyMap == null) deepDependencyMap = GetMapFromCSVFile(filePath);
        Map<String,String[]> sumDependencyList = deepDependencyMap;
        String[] title = getDependencyTitle(filePath);
        Integer[] index = new Integer[]{0,1,2,4,5,6};
        Set<String> importInformation = new TreeSet<>();

        if(prefix.length() > 1 && !className.startsWith(prefix)) return "";
        sumDependencyPrompt.append("---------------------------------------\n");
        sumDependencyPrompt.append("类  ").append(className).append("  依赖信息如下：\n").append(getDeepInformation(sumDependencyList, title, index, className, 1,importInformation));

        return sumDependencyPrompt.toString();
    }

    /**
     * 该方法用于获取一个函数的所有定义
     * @param classPath 代表类路径
     * @param className 代表类名
     * @return 返回函数的所有定义集合
     */
    @Deprecated
    public static Set<String> getClassDefSet(String classPath,String className){
        Path pathToBinary = Paths.get(classPath);
        AnalysisInputLocation inputLocation =
                PathBasedAnalysisInputLocation.create(pathToBinary, SourceType.Application);

        View view = new JavaView(inputLocation);

        Set<String> defSet = new HashSet<>();
        List<SootClass> sootClassList = view.getClasses().collect(Collectors.toList());
        for(SootClass sootClass:sootClassList){
            Set<? extends SootMethod> sootMethodSet = sootClass.getMethods();
            if(!sootClass.getName().equals(className)) continue;
            for(SootMethod sootMethod: sootMethodSet){
                try {

                    StmtGraph<?> graph = sootMethod.getBody().getStmtGraph();
                    List<Stmt> stmtList = graph.getStmts();

                    for (Stmt functionStmt : stmtList) {
                        for(Value value:functionStmt.getUsesAndDefs().toList()){
                            if(!value.getType().toString().equals("unknown")){
                                defSet.add(value.getType().toString());
                            }
                        }
                    }
                }catch (Exception ignored){}
            }
        }
        return defSet;
    }

    /**
     * 该方法用于获取某个targetMethod的方法源码
     * @param methodEmbedding 方法编码
     * @param routeIndex 路径编号
     * @return 返回targetMethod方法源码
     */
    public String getRouteCodeSourceDependency(String saveDir,String methodEmbedding,Integer routeIndex){
        String filePath = (saveDir == null)?routeCodeSourcePath:Paths.get(saveDir,routeCodeSourcePath).toString();
        if(routeCodeSourceMap == null) routeCodeSourceMap = GetRouteMapFromCSVFile(routeCodeSourcePath);
        for(String methodName:routeCodeSourceMap.keySet()){
            if(methodName.startsWith(methodEmbedding + routeIndex.toString())){
                return routeCodeSourceMap.get(methodName)[2];
            }
        }
        return "";
    }

    /**
     * 该方法用于获取某个targetMethod的cfg路径信息
     * @param methodEmbedding 方法编码
     * @param routeIndex 路径编号
     * @return 返回cfg路径信息
     */
    public String getCFGRouteInformation(String saveDir,String methodEmbedding,Integer routeIndex){
        String filePath = (saveDir == null)?cfgInformationCodePath:Paths.get(saveDir,cfgInformationCodePath).toString();
        if(cfgInformationMap == null) cfgInformationMap = GetCFGMapFromCSVFile(filePath);
        for(String methodName:cfgInformationMap.keySet()){
            if(methodName.startsWith(methodEmbedding + routeIndex.toString())){
                return cfgInformationMap.get(methodName)[2];
            }
        }
        return "";
    }

    public String getOriginCodeInformation(String methodEmbedding){
        if(classEmbeddingToCodeMap.containsKey(methodEmbedding)) return classEmbeddingToCodeMap.get(methodEmbedding);
        String methodCode = new JavaMethodFind().getMethodContent(saveFileDir,methodEmbedding);
        classEmbeddingToCodeMap.put(methodEmbedding,methodCode);return methodCode;
    }

    /**
     * 该方法用于获取一个class的三层依赖字符串
     * @param methodEmbedding 方法编码
     * @param routeIndex 路径编号
     * @return 返回与依赖有关的字符串
     */
    public String getRouteDeepClassDependency(String saveDir,String methodEmbedding,Integer routeIndex){

        String routeSavePath = (saveDir == null)?routeDeepDependencyPath:Paths.get(saveDir,routeDeepDependencyPath).toString();
        String dependencySavePath = (saveDir == null)?classDeepDependencyPath:Paths.get(saveDir,classDeepDependencyPath).toString();
        if(routeDeepDependencyMap == null) routeDeepDependencyMap = GetRouteMapFromCSVFile(routeSavePath);
        if(classDeepDependencyMap == null) classDeepDependencyMap = GetMapFromCSVFile(dependencySavePath);
        Map<String,Set<String>> classToVariableMap = new HashMap<>();
        for(String methodEmbeddingName:routeDeepDependencyMap.keySet()){
            if(methodEmbeddingName.startsWith(methodEmbedding+routeIndex.toString())){
                String[] line = routeDeepDependencyMap.get(methodEmbeddingName);
                //System.out.println(Arrays.toString(line));
                if(Integer.parseInt(line[1]) == routeIndex){
                    String dependencyClassName = line[3];
                    String newVariableMap = line[2];
                    if(classToVariableMap.containsKey(dependencyClassName)) classToVariableMap.get(dependencyClassName).add(newVariableMap);
                    else{
                        Set<String> newVariableNameset = new HashSet<>(); newVariableNameset.add(newVariableMap);
                        classToVariableMap.put(dependencyClassName,newVariableNameset);
                    }
                }
            }
        }

        StringBuilder finalDependencyString = new StringBuilder();
        for(String className:classToVariableMap.keySet()){
            String classDependencyString = classDeepDependencyMap.containsKey(className)?classDeepDependencyMap.get(className)[1]:"";
            StringBuilder variableDescribeString = new StringBuilder("Variable Or Function Name: ");
            for(String variableName: classToVariableMap.get(className)){
                variableDescribeString.append(variableName).append(" ");
            }
            String classNameString = "\n ClassName: " + className + "\n";
            finalDependencyString.append(variableDescribeString.toString()).append(classNameString).append(classDependencyString).append("\n\n");
        }
        return finalDependencyString.toString();
    }

    public String getClassDeepDependencyForAllCfgPath(String saveDir,String methodEmbedding){
        String routePath = Paths.get(saveDir,routeDeepDependencyPath).toString();
        String classPath = Paths.get(saveDir,classDeepDependencyPath).toString();
        if(routeDeepDependencyMap == null) routeDeepDependencyMap = GetRouteMapFromCSVFile(routePath);
        if(classDeepDependencyMap == null) classDeepDependencyMap = GetMapFromCSVFile(classPath);
        Map<String,Set<String>> classToVariableMap = new HashMap<>();
        for(String methodEmbeddingName:routeDeepDependencyMap.keySet()){
            if(methodEmbeddingName.startsWith(methodEmbedding)){
                String[] line = routeDeepDependencyMap.get(methodEmbeddingName);
                String dependencyClassName = line[3];
                String newVariableMap = line[2];
                if(classToVariableMap.containsKey(dependencyClassName)) classToVariableMap.get(dependencyClassName).add(newVariableMap);
                else{
                    Set<String> newVariableNameset = new HashSet<>(); newVariableNameset.add(newVariableMap);
                    classToVariableMap.put(dependencyClassName,newVariableNameset);
                }
            }
        }

        StringBuilder finalDependencyString = new StringBuilder();
        for(String className:classToVariableMap.keySet()){
            String classDependencyString = classDeepDependencyMap.containsKey(className)?classDeepDependencyMap.get(className)[1]:"";
            StringBuilder variableDescribeString = new StringBuilder("Variable Or Function Name: ");
            for(String variableName: classToVariableMap.get(className)){
                variableDescribeString.append(variableName).append(" ");
            }
            String classNameString = "\n ClassName: " + className + "\n";
            finalDependencyString.append(variableDescribeString.toString()).append(classNameString).append(classDependencyString).append("\n\n");
        }
        return finalDependencyString.toString();
    }

    public String getClassDeepDependencyForAllCfgPath(String methodEmbedding){
        if(routeDeepDependencyMap == null) routeDeepDependencyMap = GetRouteMapFromCSVFile(routeDeepDependencyPath);
        if(classDeepDependencyMap == null) classDeepDependencyMap = GetMapFromCSVFile(classDeepDependencyPath);
        Map<String,Set<String>> classToVariableMap = new HashMap<>();
        for(String methodEmbeddingName:routeDeepDependencyMap.keySet()){
            if(methodEmbeddingName.startsWith(methodEmbedding)){
                String[] line = routeDeepDependencyMap.get(methodEmbeddingName);
                String dependencyClassName = line[3];
                String newVariableMap = line[2];
                if(classToVariableMap.containsKey(dependencyClassName)) classToVariableMap.get(dependencyClassName).add(newVariableMap);
                else{
                    Set<String> newVariableNameset = new HashSet<>(); newVariableNameset.add(newVariableMap);
                    classToVariableMap.put(dependencyClassName,newVariableNameset);
                }
            }
        }

        StringBuilder finalDependencyString = new StringBuilder();
        for(String className:classToVariableMap.keySet()){
            String classDependencyString = classDeepDependencyMap.containsKey(className)?classDeepDependencyMap.get(className)[1]:"";
            StringBuilder variableDescribeString = new StringBuilder("Variable Or Function Name: ");
            for(String variableName: classToVariableMap.get(className)){
                variableDescribeString.append(variableName).append(" ");
            }
            String classNameString = "\n ClassName: " + className + "\n";
            finalDependencyString.append(variableDescribeString.toString()).append(classNameString).append(classDependencyString).append("\n\n");
        }
        return finalDependencyString.toString();
    }

    /** 用于获取得到类名，方法名以及方法返回值对应的唯一的函数的标识*/
    public static String MethodEmbedding(String className,String functionName,String returnType,List<String> paramTypes){
        return "_CLASSNAME_" + className.replace('<', '_').replace('[', '+').replace(']', '+').replace('>', '_').replace(", ", "+")
                + "_FUNCTIONNAME_" + functionName.replace('<', '_').replace('>', '_').replace('[', '+').replace(']', '+').replace(", ", "+")
                + "_RETURNTYPE_" + returnType.replace('<', '_').replace('>', '_').replace('[', '+').replace(']', '+').replace(", ", "+")
                + "_Parameters_" + paramTypes.toString().replace('<', '_').replace('>', '_').replace('[', '+').replace(']', '+').replace(", ", "+");
    }

    public static List<File> findJavaFiles(File directory){
        List<File> result = new ArrayList<>();
        if (!directory.isDirectory()) {
            return result;
        }
        File[] files = directory.listFiles();

        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    result.addAll(findJavaFiles(file));
                } else if (file.getName().endsWith(".java")) {
                    result.add(file);
                }
            }
        }
        return result;
    }

    public static void SearchImportMavenRoute() {
        // 替换为你需要查询的类名（例如某个 import 的类）
        Class<?> clazz = ArrayList.class;

        // 获取类的 ProtectionDomain
        ProtectionDomain protectionDomain = clazz.getProtectionDomain();
        if (protectionDomain != null) {
            CodeSource codeSource = protectionDomain.getCodeSource();
            if (codeSource != null) {
                // 获取类所在的 JAR 文件路径
                URL location = codeSource.getLocation();
                System.out.println("类路径: " + location.getPath());
            } else {
                System.out.println("无法获取 CodeSource 信息（可能是本地类或容器限制）");
            }
        } else {
            System.out.println("无法获取 ProtectionDomain 信息（可能是本地类或容器限制）");
        }
    }

    public static void GetAllCfgAndDependency(){
        DependencyGeneration dependencyGeneration = new DependencyGeneration("C:/Users/li'zhuo'heng/.m2/repository/com/alibaba","D:/Java/brand-onebp-new/brand-onebp","D:/Java/brand-onebp-new/brand-onebp");
        dependencyGeneration.FetchAllDependency("target/classes");
        CFGGeneration cfgGeneration = new CFGGeneration(false,false);
        cfgGeneration.AllCfgGenerate("target/classes");
        cfgGeneration.CfgToRouteClassDependency(cfgGeneration);
    }

    public static void testGetAllCfgAndDependency(){
        DependencyGeneration dependencyGeneration = new DependencyGeneration("/Users/guoliang/.m2/repository/com/alibaba","/Users/guoliang/IdeaProjects/AdPlatform/brand-onebp","/Users/guoliang/IdeaProjects/AdPlatform/brand-onebp");
        //dependencyGeneration.FetchAllDependency("/Users/guoliang/IdeaProjects/AdPlatform/brand-onebp/brand-onebp-domain/target/classes", Sets.newHashSet("com.alibaba.abf.spec.business.annotation.BusinessAbility"), Collections.emptySet());
        dependencyGeneration.FetchAllDependency("/Users/guoliang/IdeaProjects/AdPlatform/brand-onebp/brand-onebp-domain/target/classes", Collections.emptySet(), Sets.newHashSet("com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter"), Collections.emptySet());
        CFGGeneration cfgGeneration = new CFGGeneration(false,false);
        cfgGeneration.AllCfgGenerate("target/classes", Sets.newHashSet("com.alibaba.abf.spec.business.annotation.BusinessAbility"), Collections.emptySet(), Collections.emptySet());
        cfgGeneration.CfgToRouteClassDependency(cfgGeneration);
    }

    public static void main(String[] args){
        //System.out.println(DependencyPromptFetch("DependenceSaveFiles/AllDependency.csv","FetchAllDependency***void***[java.lang.String]"));
        //getClassAndCodeUnderPackage("src/main/java/org/example/code_of_good_Test_example");
        //SearchImportMavenRoute();
        //System.out.println(getUseAndDefDeepDependency("DependenceSaveFiles/DeepClassDependency.csv",getClassDefSet("target/classes","com.taobao.ad.brand.bp.domain.account.atomability.DefaultAccountAdcRoleGetAbility"),"com.taobao"));
        //System.out.println(new DependencyUtil("111").getRouteDeepClassDependency("111","_CLASSNAME_com.taobao.ad.brand.bp.domain.adgroup.workflow.BrandAdgroupMonitorWorkflowExtImpl_FUNCTIONNAME_lambda$compareDiff$3_RETURNTYPE_java.lang.String_Parameters_+java.lang.String+com.taobao.ad.brand.bp.client.dto.adgroup.ExportMonitorCodeViewDTO+",1));
        //System.out.println(getClassDefDeepDependency("DependenceSaveFiles/DeepClassDependency.csv","com.taobao.ad.brand.bp.domain.account.atomability.DefaultAccountAdcRoleGetAbility",""));
        testGetAllCfgAndDependency();
    }
}

