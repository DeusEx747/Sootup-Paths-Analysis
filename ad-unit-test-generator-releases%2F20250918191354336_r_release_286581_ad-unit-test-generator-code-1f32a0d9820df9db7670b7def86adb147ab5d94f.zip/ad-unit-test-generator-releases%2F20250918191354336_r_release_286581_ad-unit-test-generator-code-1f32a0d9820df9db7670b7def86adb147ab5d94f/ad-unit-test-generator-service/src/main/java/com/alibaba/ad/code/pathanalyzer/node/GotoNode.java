package com.alibaba.ad.code.pathanalyzer.node;

import com.alibaba.ad.code.pathanalyzer.node.type.AllType;
import com.alibaba.ad.code.pathanalyzer.node.type.Type;

import java.util.ArrayList;
import java.util.List;

public class GotoNode extends Node {
    private String from;
    private String where;
    private List<String> stackInfo;

    public GotoNode() {
        super(new Type(AllType.GOTO));
        stackInfo = new ArrayList<>();
    }

    public void setWhere(String where) {
        this.where = where;
    }

    public String getWhere() {
        return this.where;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getFrom() {
        return from;
    }

    @Override
    public String toString() {
        String res = "节点编号" + index + "为";
        res += "goto语句，将从" + from +"跳转到：" + where;
        if(stackInfo.size() > 0) res += "其中的栈信息为：" + stackInfo.toString() + "。";
        res += "\n";
        return res;
    }

    public void addStackInfo(String string) {
        this.stackInfo.add(string);
    }
}