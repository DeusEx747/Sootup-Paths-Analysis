package com.alibaba.ad.code.cfganalyser.code.util;

import com.alibaba.ad.code.cfganalyser.code.CFGGeneration;
import com.alibaba.ad.code.logger.Logger;
import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.exceptions.CsvValidationException;
import org.json.JSONObject;

import javax.annotation.Nonnull;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PathRouteUtil {

    private static final Map<String, AbstractMap.SimpleEntry<String,Integer>> fileNameToPathMap = new HashMap<>();

    private Map<String, Set<Integer>> routeUseInFile = new HashMap<>();

    public  Map<AbstractMap.SimpleEntry<String,Integer>,Boolean> routeRunSuccessMap = new HashMap<>();

    private String saveDir = null;

    public PathRouteUtil(String saveDir){
        this.saveDir = saveDir;
    }

    private static boolean DEBUG_MODE = true;
    private static final Logger logger = Logger.getInstance();

    static {
        Path globalJsonPath = Paths.get("./src/main/java/com/alibaba/config/global.json");
        JSONObject globalJson;

        if (Files.exists(globalJsonPath)) {
            // 如果文件存在，读取它
            String globalContent = null;
            try {
                globalContent = new String(Files.readAllBytes(globalJsonPath));
                globalJson = new JSONObject(globalContent);
                DEBUG_MODE = globalJson.getBoolean("debug_mode");
            } catch (Exception ignored) {}
        }
    }

    public static void addFileNameToPathMap(String fileName,String methodEmbedding,Integer routeIndex){
        fileNameToPathMap.put(fileName,new AbstractMap.SimpleEntry<String,Integer>(methodEmbedding,routeIndex));
    }

    public void getFailedRouteInformation (){
        try {
            Path readFileDir = Paths.get("D:/Java/WorkProject/python/test-inputs-outputs-set-generation");
            Path globalJsonPath = Paths.get(saveDir,"target.json");
            JSONObject globalJson;

            if (Files.exists(globalJsonPath)) {
                String globalContent = new String(Files.readAllBytes(globalJsonPath));
                globalJson = new JSONObject(globalContent);
                String pythonWordDir = globalJson.getString("python_project_directory");
                readFileDir = Paths.get(pythonWordDir,"/Wrong");
            }

            Map<String,String> wrongNameToContentMap = collectFiles(readFileDir.toFile(),new HashMap<String,String>());

            String[] line;boolean isNowFailClass = false,isNowSuccessClass = false;
            Map<String,AbstractMap.SimpleEntry<String,Integer>> classNameToInformationMap = getClassNameInDirectory(wrongNameToContentMap.keySet());
            ArrayList<ArrayList<String>> failRouteInformationList = new ArrayList<>();

            for(String className:wrongNameToContentMap.keySet()){
                String testCaseInformation = wrongNameToContentMap.get(className);
                if(!classNameToInformationMap.containsKey(className)) continue;
                String dirName = classNameToInformationMap.get(className).getKey();

                if(!fileNameToPathMap.containsKey(dirName)) continue;
                Integer routeIndex = classNameToInformationMap.get(className).getValue();
                String methodEmbeddingName = fileNameToPathMap.get(dirName).getKey();

                Path inputInformationPath = Paths.get("./Output/stage1/" + dirName + "/" + routeIndex + ".json");
                String inputContent = Files.readString(inputInformationPath);

                Path codeInformationPath = Paths.get("./Output/stage2/" + dirName + "/" + routeIndex + ".txt");
                String codeContent = Files.readString(codeInformationPath);
                DependencyUtil dependencyUtil = new DependencyUtil(saveDir);
                String originCode = dependencyUtil.getOriginCodeInformation(methodEmbeddingName);
                String cfgInformation = dependencyUtil.getCFGRouteInformation(saveDir,methodEmbeddingName,routeIndex);
                String deepRouteInformation = dependencyUtil.getRouteDeepClassDependency(saveDir,methodEmbeddingName,routeIndex);
                String deepRouteCodeInformation = dependencyUtil.getRouteCodeSourceDependency(saveDir,methodEmbeddingName,routeIndex);

                //if(DEBUG_MODE){
                //    System.out.println("testCaseInformation: " + testCaseInformation);
                //    System.out.println("inputContent: " + inputContent);
                //    System.out.println("codeContent: " + codeContent);
                //    System.out.println("cfgInformation: " + cfgInformation);
                //    System.out.println("deepRouteInformation: " + deepRouteInformation);
                //    System.out.println("deepRouteCodeInformation: " + deepRouteCodeInformation);
                //    System.out.println("originCode: " + originCode);
                //}
                ArrayList<String> caseInformationList = new ArrayList<>();
                caseInformationList.add(className);caseInformationList.add(dirName);caseInformationList.add(routeIndex.toString());caseInformationList.add(inputContent);
                caseInformationList.add(codeContent);caseInformationList.add(originCode);caseInformationList.add(cfgInformation);caseInformationList.add(deepRouteInformation);
                caseInformationList.add(deepRouteCodeInformation);caseInformationList.add(testCaseInformation);
                failRouteInformationList.add(caseInformationList);
            }

            Files.delete(Path.of("errorTestCaseInformation.csv"));
            String testInformationSavePath = "errorTestCaseInformation.csv";
            ArrayList<String> csvHeaders = new ArrayList<>();
            csvHeaders.add("className");csvHeaders.add("dirName");csvHeaders.add("routeIndex");csvHeaders.add("inputContent");
            csvHeaders.add("codeContent");csvHeaders.add("originCode"); csvHeaders.add("cfgInformation");csvHeaders.add("RouteInformation");
            csvHeaders.add("CodeInformation");csvHeaders.add("errorMessage");

            try (CSVWriter writer = new CSVWriter(new FileWriter(testInformationSavePath))) {
                writer.writeNext(csvHeaders.toArray(new String[0]));
                for (ArrayList<String> rowList : failRouteInformationList) {
                    writer.writeNext(rowList.toArray(new String[0]));
                }
            } catch (IOException e) {
                logger.logWarning("CSV Save Fail:" + e.getMessage());
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Cause" + e.getCause() + " Message " + e.getMessage());
        }
    }

    private static Map<String,String> collectFiles(File dir,Map<String, String> fileMap) throws IOException {
        File[] files = dir.listFiles();
        if (files == null) return new HashMap<>();

        for (File file : files) {
            if (file.isFile()) {
                String className = file.getName().replace(".java", "");
                fileMap.put(className, Files.readString(file.toPath()));
            } else if (file.isDirectory()) {
                collectFiles(file,fileMap); // 递归处理子目录
            }
        }
        return fileMap;
    }

    public Map<String,Map<Integer,Map<Integer,Integer>>> findShotMapFromCsvFile(String filePath){
        Map<String,Map<Integer,Map<Integer,Integer>>> sumDependencyList = new HashMap<>();
        try (CSVReader reader = new CSVReader(new FileReader(filePath))) {
            String[] line;
            reader.readNext();
            String lastFileName = null;
            Map<Integer,Map<Integer,Integer>> routeCoverMap = new HashMap<>();
            while ((line = reader.readNext()) != null) {
                String fileName = line[0];
                if(!fileName.equals(lastFileName)){
                    if(lastFileName != null){
                        sumDependencyList.put(lastFileName,routeCoverMap);
                        Map<Integer, Map<Integer, Integer>> recordMap = new HashMap<>(routeCoverMap);
                        routeCoverMap = new HashMap<>();
                        sumDependencyList.put(lastFileName,recordMap);
                    }
                    lastFileName = fileName;
                }

                int pathIndex = Integer.parseInt(line[1]);
                int lineNumber = Integer.parseInt(line[2]);
                Map<Integer,Integer> lineShotMap = new HashMap<>();

                for(int index = 0;index < lineNumber;index ++ ){
                    Integer lineIndex = Integer.parseInt(line[3 + 2 * index]),shotTimes = Integer.parseInt(line[4 + 2 * index]);
                    lineShotMap.put(lineIndex,shotTimes);
                }
                routeCoverMap.put(pathIndex,lineShotMap);
            }

            if(lastFileName != null){
                sumDependencyList.put(lastFileName,routeCoverMap);
                Map<Integer, Map<Integer, Integer>> recordMap = new HashMap<>(routeCoverMap);
                routeCoverMap = new HashMap<>();
                sumDependencyList.put(lastFileName,recordMap);
            }
            return sumDependencyList;
        } catch (Exception e) {
            System.err.println("[Warning]: CSV File Read Error!");return null;
        }
    }


    public static Map<String,Map<Integer,Boolean>> reportListToCoverMap(List<String[]> reportList){
        Map<String,Map<Integer,Boolean>> reportMap = new HashMap<>();
        for(String[] reportString: reportList){
            String className = reportString[0],methodName = reportString[1];
            String coverageReportString = reportString[8];

            List<String> resultList = Arrays.asList(coverageReportString.split(";"));
            resultList.removeIf(String::isEmpty);
            Map<Integer,Boolean> coverLineMap = new HashMap<>();
            for(String coverLine : resultList){
                String lineString = coverLine.substring(1,coverLine.indexOf(':'));
                String isCoverString = coverLine.substring(coverLine.indexOf(':') + 1);
                Integer lineNumber = Integer.parseInt(lineString);
                Boolean isCovered = !isCoverString.equals("NULL");
                coverLineMap.put(lineNumber,isCovered);
            }
            reportMap.put(className + "+" + methodName,coverLineMap);
        }
        return reportMap;
    }

    public static List<String[]> readCsvFile(Path path){
        List<String[]> readFileList = new ArrayList<>();
        try (CSVReader reader = new CSVReader(new FileReader(String.valueOf(path)))) {
            // 跳过标题行
            reader.readNext();
            String[] nextLine;
            while ((nextLine = reader.readNext()) != null) {
                if (nextLine.length > 0) {
                    readFileList.add(nextLine);
                }
            }
            return readFileList;
        } catch (IOException | CsvValidationException e) {
            System.err.println("读取文件时发生错误: " + e.getMessage());return null;
        }
    }

    /**
     * 遍历指定目录下的所有文件（包括子目录）
     *
     * @return 所有文件路径列表
     * @throws IOException 如果读取失败
     */
    public static Map<String,AbstractMap.SimpleEntry<String,Integer>> getClassNameInDirectory(Set<String> testRunInformationList) throws IOException {
        Path rootDir = Paths.get("./Output/stage2");
        if (!Files.exists(rootDir)) {
            throw new IllegalArgumentException("目录不存在: " + rootDir);
        }

        Map<String,AbstractMap.SimpleEntry<String,Integer>> classNameToFileMap = new HashMap<>();
        Map<String,Boolean> isFileNameFoundMap = new HashMap<>();
        for(String informationList : testRunInformationList) isFileNameFoundMap.put(informationList,false);

        // 使用 Files.walkFileTree 遍历目录
        Files.walkFileTree(rootDir, new SimpleFileVisitor<Path>() {

            @Override
            @Nonnull
            public FileVisitResult visitFile(Path file,@Nonnull BasicFileAttributes attrs) throws IOException {
                // 只添加文件（忽略目录）
                if (Files.isRegularFile(file)) {
                    String fileContent = Files.readString(file.toAbsolutePath());
                    String testCaseFileName = extractJavaClassName(fileContent);
                    if(testCaseFileName != null){
                        Integer routeIndex = Integer.parseInt(file.getFileName().toString().substring(0,file.getFileName().toString().indexOf('.')));
                        String nowDir = file.getParent().getFileName().toString();
                        if(isFileNameFoundMap.containsKey(testCaseFileName) && !isFileNameFoundMap.get(testCaseFileName)){
                            classNameToFileMap.put(testCaseFileName,new AbstractMap.SimpleEntry<>(nowDir,routeIndex));
                            isFileNameFoundMap.replace(testCaseFileName,true);
                        }
                    }
                }
                return FileVisitResult.CONTINUE;
            }

            @Override
            @Nonnull
            public FileVisitResult visitFileFailed(Path file,@Nonnull IOException exc) {
                System.err.println("无法访问文件: " + file + " 原因: " + exc.getMessage());
                return FileVisitResult.CONTINUE;
            }
        });
        return classNameToFileMap;
    }

    /**
     * 从 Java 源码字符串中提取类名
     * @param fileContent Java 文件内容字符串
     * @return 提取到的类名，未找到则返回 null
     */
    public static String extractJavaClassName(String fileContent) {
        // 定义正则表达式数组
        String[] classPatterns = {
                "public/s+class/s+(/w+)",   // 匹配 public class Name
                "class/s+(/w+)"              // 匹配 class Name
        };
        for (String pattern : classPatterns) {
            Pattern regex = Pattern.compile(pattern);
            Matcher matcher = regex.matcher(fileContent);

            if (matcher.find()) {
                return matcher.group(1); // 返回第一个捕获组中的类名
            }
        }
        return null;
    }

    public static void main(String[] args){
        //fileNameToPathMap.put("LittleTest+TestCollection+int",new AbstractMap.SimpleEntry<String,Integer>("_CLASSNAME_org.example.LittleTest_FUNCTIONNAME_TestCollection_RETURNTYPE_int_Parameters_+int+",2));
        //fileNameToPathMap.put("SelfServiceSaleGroupEstimateJudgeHandleNonSlimOrderPath7Test",new AbstractMap.SimpleEntry<String,Integer>("test",7));
        //fileNameToPathMap.put("SelfServiceSaleGroupEstimateJudgeHandleNonSlimOrderPath8Test",new AbstractMap.SimpleEntry<String,Integer>("test",8));
        //fileNameToPathMap.put("SelfServiceSaleGroupEstimateJudgeHandleNonSlimOrderPath9Test",new AbstractMap.SimpleEntry<String,Integer>("test",9));
        //getFailedRouteInformation();
        String saveDir = "Time_11_14_19_403564";
        CFGGeneration cfgGeneration = new CFGGeneration(saveDir,false,true);
        cfgGeneration.AllCfgGenerate("C:/Users/li'zhuo'heng/Desktop/brand-onebp-domain/target/classes/");
        //Starter.reMadeNewStage1(saveDir,new PathRouteUtil(saveDir).fetchUncoveredRouteFromReport());
    }
}