package com.alibaba.ad.code.diamond;

import com.alibaba.boot.diamond.annotation.DiamondListener;
import com.alibaba.boot.diamond.listener.DiamondDataCallback;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.Map;

import static com.alibaba.fastjson.JSON.parseObject;

@DiamondListener(dataId = "ad.unit.test.generator.appName.repository.mapping")
@Slf4j
public class AppNameRepositoryDiamond implements DiamondDataCallback {

    @Getter
    private Map<String, String> appNameRepositoryMapping;

    @Override
    public void received(String data) {
        if (StringUtils.isEmpty(data)) {
            log.warn("ad.unit.test.generator.appName.repository.mapping is empty");
            return;
        }

        Map<String, String> appNameRepositoryTmpMapping = new HashMap<>();

        parseObject(data).forEach(
                (appName, repository) -> {
                    appNameRepositoryTmpMapping.put(appName, repository.toString());
                }
        );

        appNameRepositoryMapping = appNameRepositoryTmpMapping;
    }
}

