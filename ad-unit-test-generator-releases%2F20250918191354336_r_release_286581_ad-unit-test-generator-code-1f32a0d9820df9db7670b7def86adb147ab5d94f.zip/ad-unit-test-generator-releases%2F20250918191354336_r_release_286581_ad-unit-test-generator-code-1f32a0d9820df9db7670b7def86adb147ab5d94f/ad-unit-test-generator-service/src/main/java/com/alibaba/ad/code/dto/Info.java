package com.alibaba.ad.code.dto;

import lombok.Data;

/**
 * 各类信息
 *
 * @author zhangheng
 */
@Data
public class Info {
    private boolean ok;

    private String message;

    private boolean isDisableTime;

    private boolean isLockSla;

    private String unlockUrl;

    private String errorCode;

    public Info(boolean isOk) {
        this.ok = isOk;
    }

}
