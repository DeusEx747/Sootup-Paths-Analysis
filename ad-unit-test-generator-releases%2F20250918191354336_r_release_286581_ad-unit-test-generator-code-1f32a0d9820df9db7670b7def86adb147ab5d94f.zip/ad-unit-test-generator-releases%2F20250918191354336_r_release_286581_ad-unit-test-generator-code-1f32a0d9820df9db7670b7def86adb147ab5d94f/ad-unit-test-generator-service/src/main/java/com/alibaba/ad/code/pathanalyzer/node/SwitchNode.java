package com.alibaba.ad.code.pathanalyzer.node;

import com.alibaba.ad.code.pathanalyzer.node.type.AllType;
import com.alibaba.ad.code.pathanalyzer.node.type.Type;

import java.util.ArrayList;
import java.util.List;

public class SwitchNode extends Node {
    private String condition;
    private List<String> branches;
    private List<String> cases;
    private String defaultBranch;
    private List<String> stackInfo;

    public SwitchNode() {
        super(new Type(AllType.SWITCH));
        stackInfo = new ArrayList<>();
        branches = new ArrayList<>();
        cases = new ArrayList<>();
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public void addBranch(String branch) {
        branches.add(branch);
    }

    public void addCase(String tCase) {
        cases.add(tCase);
    }

    public String getCondition() {
        return condition;
    }

    public void setDefaultBranch(String defaultBranch) {
        this.defaultBranch = defaultBranch;
    }

    public String getDefaultBranch() {
        return defaultBranch;
    }

    public void addStackInfo(String info) {
        stackInfo.add(info);
    }

    public List<String> getStackInfo() {
        return stackInfo;
    }

    @Override
    public String toString() {
        String res = "节点编号" + index + "为";
        res += "switch分支语句，";
        int size = cases.size();
        for(int i = 0; i < size; i++) {
            res += "case" + i + "条件为：" + condition + " = " + cases.get(i).toString() + "，" + "将执行的语句为：" + branches.get(i) + "；";
        }
        if(defaultBranch != null) res += "default分支为" + defaultBranch + "。";
        if(stackInfo.size() > 0) res += "其中的栈信息为：" + stackInfo.toString() + "。";
        res += "\n";
        return res;
    }

    public List<String> getCases() {
        return cases;
    }
}
