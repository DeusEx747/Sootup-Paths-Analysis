package com.alibaba.ad.code.pathanalyzer.node;


import com.alibaba.ad.code.pathanalyzer.node.type.AllType;
import com.alibaba.ad.code.pathanalyzer.node.type.Type;

/**
 * 表示一个节点，包含节点类型信息。
 * <p>
 * 该类用于表示分支结构中的节点，通过 {@link Type} 类来定义节点的类型。
 */
public class Node {

    /** 节点的类型信息。 */
    protected Type type;
    protected int index;

    /**
     * 初始化节点，并设置其类型。
     *
     * @param type 节点的类型（不能为空）
     */
    public Node(Type type) {
        this.type = type;
    }

    /** 初始化节点，并设置其类型为 {@link AllType#DEFULT}。 */
    public Node() {
        this.type = new Type(AllType.DEFULT);
    }

    /**
     * 初始化节点，并设置其类型和编号。
     *
     * @param type 节点的类型（不能为空）
     * @param index 节点的编号
     */
    public Node(Type type, int index) {
        this.type = type;
        this.index = index;
    }

    /**
     * 获取节点的类型。
     *
     * @return 节点的类型（可能为 {@code null} 如果未设置）
     */
    public Type getType() {
        return type;
    }

    /**
     * 设置节点的类型。
     *
     * @param type 新的节点类型（不能为空）
     */
    public void setType(Type type) {
        this.type = type;
    }

    /**
     * 获取节点的编号。
     *
     * @return 节点的编号
     */
    public int getIndex() {
        return index;
    }

    /**
     * 设置节点的编号。
     *
     * @param index 新的节点编号
     */
    public void setIndex(int index) {
        this.index = index;
    }
}
