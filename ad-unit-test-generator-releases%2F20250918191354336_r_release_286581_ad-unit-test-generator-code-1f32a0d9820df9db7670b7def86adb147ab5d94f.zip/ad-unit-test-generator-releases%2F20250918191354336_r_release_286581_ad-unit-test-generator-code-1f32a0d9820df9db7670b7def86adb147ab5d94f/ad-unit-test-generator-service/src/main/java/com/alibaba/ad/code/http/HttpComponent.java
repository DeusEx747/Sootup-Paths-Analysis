package com.alibaba.ad.code.http;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.alibaba.fastjson.JSON;

import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.ssl.SSLContextBuilder;
import org.springframework.stereotype.Component;

import javax.net.ssl.SSLContext;

/**
 * @author jys
 * @date 2025/08/07
 */
@Component
@Slf4j
public class HttpComponent {

    public void onCallbackAgent(String callbackUrl, String success, List<String> pathList, Set<String> classNameSet,
        String moduleName, String taskUuid) {

        try (CloseableHttpClient client = createHttpClient()) {

            Map<String, String> proxyData = Maps.newHashMap();
            proxyData.put("success", success);
            proxyData.put("path", JSON.toJSONString(pathList));
            proxyData.put("classNameSet", JSON.toJSONString(classNameSet));
            proxyData.put("moduleName", moduleName);
            proxyData.put("taskUuid", taskUuid);
            StringEntity postingString = new StringEntity(JSON.toJSONString(proxyData), "utf-8");
            HttpPost post = new HttpPost(callbackUrl);
            // 设置请求参数
            post.setEntity(postingString);
            post.setHeader("Content-Type", "application/json; charset=UTF-8");
            // 执行请求
            HttpResponse response = client.execute(post);
            String responseBody = EntityUtils.toString(response.getEntity(), "UTF-8");
            // 打印结果
            log.info("[FetherInvoker] sendPost responseBody:{}", responseBody);
        } catch (Exception e) {
            log.error("[FetherInvoker] sendPost url " + callbackUrl + "failed" , e);
            // throw new RuntimeException("[FetherInvoker] sendPost url " + url + "failed", e);
        }
    }

    private CloseableHttpClient createHttpClient()
        throws NoSuchAlgorithmException, KeyManagementException, KeyStoreException {
        // 创建信任所有证书的TrustStrategy
        TrustStrategy acceptingTrustStrategy = new TrustStrategy() {
            @Override
            public boolean isTrusted(X509Certificate[] certificate, String authType) {
                return true;
            }
        };

        // 创建SSL上下文
        SSLContext sslContext = SSLContextBuilder.create()
                .loadTrustMaterial(acceptingTrustStrategy)
                .build();

        // 创建SSL连接套接字工厂
        SSLConnectionSocketFactory csf = new SSLConnectionSocketFactory(
                sslContext,
                NoopHostnameVerifier.INSTANCE);

        // 创建可关闭的HTTP客户端
        return HttpClients.custom()
                .setSSLSocketFactory(csf)
                .build();
    }

}