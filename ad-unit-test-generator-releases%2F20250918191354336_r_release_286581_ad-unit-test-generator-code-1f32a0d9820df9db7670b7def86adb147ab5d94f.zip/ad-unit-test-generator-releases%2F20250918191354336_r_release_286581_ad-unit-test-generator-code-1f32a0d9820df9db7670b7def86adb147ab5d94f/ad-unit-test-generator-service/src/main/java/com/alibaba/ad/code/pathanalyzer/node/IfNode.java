package com.alibaba.ad.code.pathanalyzer.node;


import com.alibaba.ad.code.pathanalyzer.node.type.AllType;
import com.alibaba.ad.code.pathanalyzer.node.type.Type;

import java.util.ArrayList;
import java.util.List;

public class IfNode extends Node {
    private String condition;
    private List<String> stackInfo;
    private String trueBranch;
    private String falseBranch;

    public IfNode() {
        super(new Type(AllType.IF));
        stackInfo = new ArrayList<>();
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public String getCondition() {
        return condition;
    }

    public void addStackInfo(String info) {
        stackInfo.add(info);
    }

    public List<String> getStackInfo() {
        return stackInfo;
    }

    public void setTrueBranch(String trueBranch) {
        this.trueBranch = trueBranch;
    }

    public String getTrueBranch() {
        return trueBranch;
    }

    public void setFalseBranch(String falseBranch) {
        this.falseBranch = falseBranch;
    }

    public String getFalseBranch() {
        return falseBranch;
    }

    @Override
    public String toString() {
        String res = "节点编号" + index + "为";
        res += "if分支语句，判断条件为" + condition + "。";
        res += "if分支语句的true分支为" + trueBranch + 
        "，false分支为" + falseBranch + "。";
        if(stackInfo.size() > 0) res += "其中的栈信息为：" + stackInfo.toString() + "。";
        res += "\n";
        return res;
    }
}
