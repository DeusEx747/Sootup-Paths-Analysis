package com.alibaba.ad.code.oss;

import java.io.IOException;

import com.alibaba.normandy.credential.Credential;
import com.alibaba.normandy.credential.CredentialProvider;
import com.alibaba.normandy.credential.ResourceNames;

import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClientBuilder;
import com.aliyun.oss.model.OSSObject;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author nanfeng.jys
 * @date 2025/8/6 17:22
 * @description*/

@Slf4j
@Component
public class OssComponent {

    @Value("${oss.bucket.name:ad-unit-test-pre}")
    private String ossBucketName;

    @Autowired
    private CredentialProvider credentialProvider;
    private OSS ossClient = null;

    public OssComponent() {

    }

    @PostConstruct
    public void init() {
        String rn = ResourceNames.ofAliyunOssBucketName(ossBucketName);
        Credential credential = credentialProvider.getCredential(rn);
        String endpoint = "oss-cn-zhangjiakou.aliyuncs.com";
        ossClient = new OSSClientBuilder()
            .build(
                endpoint,
                credential.getAccessKeyId(),
                credential.getAccessKeySecret()
            );
    }

    public String readData(String objectName) throws IOException {
        OSSObject ossObject = ossClient.getObject(ossBucketName, objectName);
        return OssTools.readObjectContent(ossObject);
    }

    public void copyDataToLocal(String path) {
        OSSObject ossObject = ossClient.getObject(ossBucketName, path.substring(1));
        try {
            OssTools.copyFileToLocal(ossObject, path);
        } catch (Exception e) {
            log.error("OssTools::copyDataToLocal error", e);
        }
    }

    public String writeData(String objectName, String data) {
        return OssTools.writeObjectContent(ossClient, ossBucketName, objectName, data);
    }



    public String readDataFromOssBucket(String objectName) {
        OSS client = null;
        try {
            // Loads OSS access key.
            String bucketName = "ad-unit-test-daily";
            String rn = ResourceNames.ofAliyunOssBucketName(bucketName);
            Credential credential = credentialProvider.getCredential(rn);

            // Creates an OSS client object.
            //默认的endpoint为外网访问endPoint,如需使用内网访问endPoint,请自行替换
            String endpoint = "oss-cn-zhangjiakou.aliyuncs.com";
            client = new OSSClientBuilder()
                .build(
                    endpoint,
                    credential.getAccessKeyId(),
                    credential.getAccessKeySecret()
                );

            OSSObject ossObject = client.getObject(bucketName, objectName);
            return OssTools.readObjectContent(ossObject);
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        } finally {
            if (client != null) {
                client.shutdown();
            }
        }
    }

    public String writeDataToOssBucket(String objectName, String data) {
        OSS client = null;
        try {
            // Loads OSS access key.
            String bucketName = "ad-unit-test-daily";
            String rn = ResourceNames.ofAliyunOssBucketName(bucketName);
            Credential credential = credentialProvider.getCredential(rn);

            // Creates an OSS client object.
            //默认的endpoint为外网访问endPoint,如需使用内网访问endPoint,请自行替换
            String endpoint = "oss-cn-zhangjiakou.aliyuncs.com";
            client = new OSSClientBuilder()
                .build(
                    endpoint,
                    credential.getAccessKeyId(),
                    credential.getAccessKeySecret()
                );

            return OssTools.writeObjectContent(client, bucketName, objectName, data);
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        } finally {
            if (client != null) {
                client.shutdown();
            }
        }
    }

}
