package com.alibaba.ad.code.cfganalyser.code;

import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.ImportDeclaration;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.body.Parameter;
import com.github.javaparser.ast.comments.Comment;
import com.github.javaparser.ast.expr.AnnotationExpr;
import com.opencsv.CSVWriter;
import lombok.Getter;
import sootup.core.graph.StmtGraph;
import sootup.core.inputlocation.AnalysisInputLocation;
import sootup.core.jimple.basic.Value;
import sootup.core.jimple.common.expr.AbstractInvokeExpr;
import sootup.core.jimple.common.stmt.InvokableStmt;
import sootup.core.jimple.common.stmt.Stmt;
import sootup.core.model.SootClass;
import sootup.core.model.SootField;
import sootup.core.model.SootMethod;
import sootup.core.model.SourceType;
import sootup.core.signatures.MethodSignature;
import sootup.core.signatures.PackageName;
import sootup.core.types.ClassType;
import sootup.core.types.Type;
import sootup.core.views.View;
import sootup.java.bytecode.frontend.inputlocation.JavaClassPathAnalysisInputLocation;
import sootup.java.bytecode.frontend.inputlocation.PathBasedAnalysisInputLocation;
import sootup.java.core.JavaSootClass;
import sootup.java.core.types.JavaClassType;
import sootup.java.core.views.JavaView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import com.alibaba.ad.code.cfganalyser.code.util.ClassFilterUtil;

/**
 * 该类用于获取得到给定文件夹下面的所有的相关依赖
 * 在这里依赖指对之后的LLMs测试代码生成有帮助的信息，包括：
 * (1)方法的类所用到的全部import语句
 * (2)方法的类的直接父类以及应用的接口
 * (3)方法中所使用的全部函数调用以及被调用函数的注释信息
 * (4)方法的注释信息
 * (5)方法的类所包含的全部属性
 * (6)方法的类的注释与类注解
 *
 * 使用方法如下：
 * (1):调用 FuncMethodSignatureGenerate()函数精确获取得到某个具体方法的依赖，完成方法调用后，得到的结果存储于类实例中：
 * 1.methodSignatureArrayList： 存储所有的调用的函数信息
 * 2.importDependencyList: 存储所有的import语句
 * 3.sootFieldList： 存储全部的类属性
 * 4.superClass: 存储父类
 * 5.implementsClassTypeList 存储实现的接口列表
 * 6.methodCommentMap ：存储调用的函数的注释
 * 7.myClassComment: 方法的类的注释
 * 8.myClassAnnotations: 方法的类的注解
 * 直接在类实例中获取以上属性即可获得全部依赖
 *
 * (2)：调用FetchAllDependency()获取某个目录下的全部方法依赖，完成方法调用后，得到的结果存储于类实例中，并将结果存储至CSV文件
 * 对于结果的获取，将类依赖于方法依赖分别置于ClassDependency 和 MethodDependency 中，通过nameToClassDependencyMap 这个Map获取得到目录下的全部类与类依赖实例之间的关系：
 * 1.class： ClassDependency:
 * importDependencyList : 存储所有的import语句
 * superClass: 存储父类
 * implementsClassTypeList: 存储实现的接口列表
 * sootFieldList 存储全部的类属性
 * className: 存储对应的类名
 * classComment: 对应的类的注释
 * classAnnotations: 对应的类的注解
 * methodDependencyArrayList:Map ,存储类中的方法名(方法名编码)与方法依赖MethodDependency 之间的关系
 * 2.class: MethodDependency
 * methodSignatureArrayList 存储所有的调用的函数信息
 * methodCommentMap 存储调用的函数的注释
 * myClassDependency 存储对应的类依赖
 * myMethondComment 存储方法的注释
 * methodName 存储方法的名称
 * 相应的依赖信息需要从以上的类别中进行获取，首先通过对应的类名从Map中获取得到类依赖，之后再通过方法编码获取得到对应方法依赖
 * (3)依赖可视化示例：
 * Class :
 * target.classes.com.taobao.ad.bp.business.impl.tetrisv2.dailyad.ability.campaign.budget
 * .DailyAdXCampaignBudgetValidateForUpdateCampaignAbilityPolicy
 * Father Class:
 * Implements Uses: [ICampaignBudgetValidateForUpdateCampaignAbility]
 * Import Use: []
 * Class Comment:
 * Class Annotations Use:
 * Field Use:
 * Field Type: com.alibaba.ad.external.sdk.config.CommonPropertiesSAO     Field Name: commonPropertiesSAO
 * Field Type: java.lang.String     Field Name: ABILITY_POLICY_CODE
 * Field Type: org.slf4j.Logger     Field Name: log
 * Field Type: com.alibaba.solar.common.validate.ValidateBox     Field Name: VALIDATE_BOX
 * Field Type: com.taobao.ad.bp.business.impl.tetrisv2.basead.ability.campaign.budget.BudgetValidateHelper     Field
 * Name: budgetValidateHelper
 * Field Type: com.alibaba.ad.external.sdk.account.AccountSAO     Field Name: accountSAO
 * MethodName : handle***java.lang.Void***[com.alibaba.abf.governance.context.ServiceContext,
 * com.alibaba.ad.universal.sdk.view.dto.campaign.budget.CampaignBudgetViewDTO,
 * com.alibaba.ad.universal.sdk.wdo.tetrisv2.dailyad.DailyAdCampaignComponentWDO]  MethodComment:
 * MethodName : handle***java.lang.Void***[com.alibaba.abf.governance.context.ServiceContext,
 * com.alibaba.ad.universal.sdk.view.dto.campaign.budget.CampaignBudgetViewDTO, com.alibaba.ad.universal.sdk.wdo.WDO]
 * MethodComment:
 * MethodName : <clinit>***void***[]  MethodComment:
 * MethodName : <init>***void***[]  MethodComment:
 **/

/**
 * 更新说明：
 * (1) Dependency 的构造函数
 *  三个参数：String libPath, String localSourcePath, String localTargetPath的含义如下：
 *  libPath:    代表本地仓库的路径   localSourcePath:    代表java源文件根目录    localTargetPath: 代表class源文件根目录
 *  在一般情况下 localSourcePath 和 localTargetPath 可以被视为相同
 *
 * (2) Dependency使用
 * 使用方法 FetchAllDependency(String targetPath:指向期望生成依赖的target/classes目录) 获取对应目录下的依赖
 */
public class DependencyGeneration {

    /**
     *  class： ClassDependency:
     *  importDependencyList : 存储所有的import语句
     *  superClass: 存储父类
     *  implementsClassTypeList: 存储实现的接口列表
     *  sootFieldList 存储全部的类属性
     *  className: 存储对应的类名
     *  classComment: 对应的类的注释
     *  classAnnotations: 对应的类的注解
     *  methodDependencyArrayList:Map ,存储类中的方法名(方法名编码)与方法依赖MethodDependency 之间的关系*/
    @Getter
    class ClassDependency {
        private ArrayList<String> importDependencyList = new ArrayList<>();
        private SootClass superClass;
        private DeepClassDependency superClassDependency;
        private ArrayList<String> implementsClassTypeList = new ArrayList<>();
        private Map<String, MethodDependency> methodDependencyArrayList = new HashMap<>();
        private ArrayList<SootField> sootFieldList = new ArrayList<>();
        private Map<String, DeepClassDependency> fieldClassList = new HashMap<>();
        private ArrayList<String> annotationList = new ArrayList<>();
        private String className;
        private String classComment;

    }

    /**
     * 该类代表了某个类的深层依赖
     * importDependencyList : 存储所有的import语句
     * superClass: 存储父类
     * superClassDependency: 指向该类的父类深层依赖信息
     * implementsClassTypeList: 存储实现的接口列表
     * sootFieldList 存储全部的类属性
     * sootMethodList 存储类的全部方法签名
     * className: 存储对应的类名
     * classComment: 对应的类的注释
     */
    class DeepClassDependency {
        private ArrayList<String> importDependencyList = new ArrayList<>();
        private SootClass superClass;
        private DeepClassDependency superClassDependency;
        private ArrayList<String> implementsClassTypeList = new ArrayList<>();
        private ArrayList<SootField> sootFieldList = new ArrayList<>();
        private ArrayList<String> annotationList = new ArrayList<>();
        private Set<? extends SootMethod> sootMethodSet = null;
        private Map<SootMethod, ArrayList<String>> methodToParameterMap = new HashMap<>();
        private String className;
        private String classComment;
    }

    /**
     * class: MethodDependency
     * methodSignatureArrayList 存储所有的调用的函数信息
     * methodCommentMap 存储调用的函数的注释
     * myClassDependency 存储对应的类依赖
     * myMethondComment 存储方法的注释
     * methodName 存储方法的名称
     * returnTypeDependency:记录返回值类型的深层依赖信息
     * paramTypeDependency: 记录函数参数的深层依赖信息
     * stmtTypeDependency: 记录记录stmt路径上的深层依赖信息*/
    @Getter
    class MethodDependency {
        private ArrayList<MethodSignature> methodSignatureArrayList = new ArrayList<>();
        private Map<MethodSignature, String> methodCommentMap = new HashMap<>();
        private ClassDependency myClassDenpendency = null;
        private String myMethondComment = null;
        private String methodName;
        private MethodSignature methodSignature = null;
        private DeepClassDependency returnTypeDependency = null;
        private Map<String, DeepClassDependency> paramTypeDependency = new HashMap<>();
        private Map<String, DeepClassDependency> stmtTypeDependency = new HashMap<>();
    }

    //代表本地maven仓库的核心路径
    private String libRootPath = "";
    //代表需要使用的本地java项目的路径
    private String LocalSourcePath = "";
    //代表需要使用的本地.class项目的路径，与前者保持一直即可
    private String LocalTargetPath = "";
    //代表需要将文件保存至的新地址
    private String csvSaveDir = null;
    //记录类名和类依赖之间的存储关系
    private Map<String, ClassDependency> nameToClassDependencyMap = new HashMap<>();
    //记录所有的方法签名
    private ArrayList<MethodSignature> methodSignatureArrayList = new ArrayList<>();
    //记录import列表
    private ArrayList<String> importDependencyList = new ArrayList<>();
    //记录属性列表
    private ArrayList<SootField> sootFieldList = new ArrayList<>();
    //记录父类
    private SootClass superClass;
    //记录方法注释
    private String myMethodComment;
    //记录类注释
    private String myClassComment;
    //记录类注解
    private final ArrayList<String> myClassAnotationList = new ArrayList<>();
    //记录类继承方法状况
    private ArrayList<String> implementsClassTypeList = new ArrayList<>();
    //记录方法签名与方法注释的对应关系
    private Map<MethodSignature, String> methodCommentMap = new HashMap<>();
    //存储类名与本地maven仓库的路径对应关系，减少source文件的查找时间
    private final Map<String, String> classSavePlacePath = new HashMap<>();
    //记录本地类名与.java文件的路径对应关系，避免二次查找
    private final Map<String, String> localClassSourcePath = new HashMap<>();
    //记录类名与本地的Target文件的路径对应关系，避免可能的二次查找
    private final Map<String, String> localTargetClassPath = new HashMap<>();
    //记录某个类是否能被找到，避免类在lib中的类路径查找
    private final Map<String, Boolean> targetClassFoundSuccessMap = new HashMap<>();
    //记录某个类名与SootClass的对应关系，之后可以直接获取类的sootClass信息进行解析
    private final Map<String, SootClass> classPathToSootClassMap = new HashMap<>();
    //记录类名与Source文件的对应关系，之后可以直接从CompliationUnit中加载获取到cu进行源码解析
    private final Map<String, CompilationUnit> sourcePathToCompilationUnitMap = new HashMap<>();
    //记录所有的本地源文件
    private List<String> allLocalFileList = null;
    //记录所有的本地class文件
    private final List<String> allLocalTargetList = null;

    public DependencyGeneration() {}

    public DependencyGeneration(String taskCreateTime, String maven_repository, String localSourcePath,
        String localTargetPath) {
        this.csvSaveDir = taskCreateTime;
        this.libRootPath = maven_repository;
        this.LocalSourcePath = localSourcePath;
        this.LocalTargetPath = localTargetPath;
        try {
            if (!Files.exists(Path.of(csvSaveDir))) {Files.createDirectory(Path.of(csvSaveDir));}
        } catch (Exception ignored) {}
    }

    /** 该方法用于初始化实例，请使用该构造函数！！！
     libPath:    代表本地仓库的路径   localSourcePath:    代表java源文件根目录    localTargetPath: 代表class源文件根目录*/
    public DependencyGeneration(String libPath, String localSourcePath, String localTargetPath) {
        libRootPath = libPath;
        LocalSourcePath = localSourcePath;
        LocalTargetPath = localTargetPath;
    }

    public void Init() {
        nameToClassDependencyMap = new HashMap<>();
        methodCommentMap = new HashMap<>();
        methodSignatureArrayList = new ArrayList<>();
        importDependencyList = new ArrayList<>();
        implementsClassTypeList = new ArrayList<>();
        superClass = null;
    }

    /** *.
     * 调用 FuncMethodSignatureGenerate()函数精确获取得到某个具体方法的依赖，完成方法调用后，得到的结果存储于类实例中：
     * 1.methodSignatureArrayList： 存储所有的调用的函数信息
     * 2.importDependencyList: 存储所有的import语句
     * 3.sootFieldList： 存储全部的类属性
     * 4.superClass: 存储父类
     * 5.implementsClassTypeList 存储实现的接口列表
     * 6.methodCommentMap ：存储调用的函数的注释
     * 直接在类实例中获取以上属性即可获得全部依赖
     * @param classPath: 类的路径
     * @param className: 类名
     * @param functionName： 函数名
     * @param returnType： 返回值类型
     * @param parameters： 参数列表
     */
    public void FuncMethodSignatureGenerate(String classPath, String className, String functionName, String returnType,
        List<String> parameters) {
        Path pathToBinary = Paths.get(classPath);
        AnalysisInputLocation inputLocation =
            PathBasedAnalysisInputLocation.create(pathToBinary, SourceType.Application);

        View view = new JavaView(inputLocation);
        ClassType classType = view.getIdentifierFactory().getClassType(className);

        MethodSignature methodSignature =
            view.getIdentifierFactory()
                .getMethodSignature(
                    classType, functionName, returnType, parameters);

        if (view.getClass(classType).isEmpty()) {
            System.out.println("Class Not Found!");
        }
        SootClass sootClass = view.getClass(classType).get();
        view.getMethod(methodSignature);

        Init();
        importDependencyList.addAll(FetchImport(sootClass));
        superClass = FetchExtendsMessage(sootClass);
        implementsClassTypeList.addAll(FetchImplementsMessage(sootClass));
        sootFieldList.addAll(sootClass.getFields());

        try {
            myClassComment = searchClassComment(sootClass.getName());
            myClassAnotationList.addAll(searchClassAnnotations(sootClass.getName()));
            if (sootClass.getMethod(methodSignature.getSubSignature()).isPresent()) {
                SootMethod sootMethod = sootClass.getMethod(methodSignature.getSubSignature()).get();
                StmtGraph<?> graph = sootMethod.getBody().getStmtGraph();
                List<Stmt> stmtList = graph.getStmts();

                List<String> paramList = new ArrayList<>();
                for (Type type : methodSignature.getParameterTypes()) {paramList.add(type.toString());}
                myMethodComment = searchFuncComment(methodSignature.getDeclClassType().toString(),
                    methodSignature.getName(), methodSignature.getType().toString(), paramList);

                MethodDependency methodDependency = new MethodDependency();
                for (Stmt functionStmt : stmtList) {
                    if (functionStmt.isInvokableStmt()) {
                        InvokableStmt invokableStmt = functionStmt.asInvokableStmt();
                        if (invokableStmt.containsInvokeExpr()) {
                            Optional<AbstractInvokeExpr> funcCallStmt = invokableStmt.getInvokeExpr();
                            if (funcCallStmt.isPresent()) {
                                AbstractInvokeExpr abstractInvokeExpr = funcCallStmt.get();
                                FuncCommentFetch(abstractInvokeExpr.getMethodSignature(), methodDependency);
                            }
                        }
                    }
                }
                methodCommentMap.putAll(methodDependency.methodCommentMap);
                methodSignatureArrayList.addAll(methodDependency.methodSignatureArrayList);
            }
        } catch (Exception e) {
            System.out.println("CFG build fail!");
        }
    }

    public void FetchAllDependency(String classPath) {
        FetchAllDependency(classPath, new HashSet<>(), new HashSet<>(), new HashSet<>());
    }

    /**
     * 调用FetchAllDependency()获取某个目录下的全部方法依赖，完成方法调用后，得到的结果存储于类实例中，并将结果存储至CSV文件
     * 对于结果的获取，将类依赖于方法依赖分别置于ClassDependency 和 MethodDependency 中，通过nameToClassDependencyMap 这个Map获取得到目录下的全部类与类依赖实例之间的关系：
     * 1.class： ClassDependency:
     * importDependencyList : 存储所有的import语句
     * superClass: 存储父类
     * implementsClassTypeList: 存储实现的接口列表
     * sootFieldList 存储全部的类属性
     * className: 存储对应的类名
     * methodDependencyArrayList:Map ,存储类中的方法名(方法名编码)与方法依赖MethodDependency 之间的关系
     * 2.class: MethodDependency
     * methodSignatureArrayList 存储所有的调用的函数信息
     * methodCommentMap 存储调用的函数的注释
     * myClassDependency 存储对应的类依赖
     * myMethondComment 存储方法的注释
     * methodName 存储方法的名称
     * 相应的依赖信息需要从以上的类别中进行获取，首先通过对应的类名从Map中获取得到类依赖，之后再通过方法编码获取得到对应方法依赖
     * @param classPath： 代表需要处理的根目录
     */
    public Set<String> FetchAllDependency(String classPath, Set<String> hasAnnotations, Set<String> implementInterfaces, Set<String> classNames) {
        Init();
        Path pathToBinary = Paths.get(classPath);
        AnalysisInputLocation inputLocation =
            PathBasedAnalysisInputLocation.create(pathToBinary, SourceType.Application);

        JavaView view = new JavaView(inputLocation);

        List<JavaSootClass> sootClassList = view.getClasses().toList();
        Set<String> classNameSet = new HashSet<>();
        for (JavaSootClass sootClass : sootClassList) {

            // 根据注解过滤
            if (!ClassFilterUtil.hasAnnotation(sootClass, hasAnnotations)) {
                continue;
            }
            // 根据接口过滤类
            if (!ClassFilterUtil.implementInterfaces(sootClass, implementInterfaces)) {
                continue;
            }
            // 根据类名过滤类
            if (!ClassFilterUtil.isTargetClass(sootClass, classNames)) {
                continue;
            }

            Set<? extends SootMethod> sootMethodSet = sootClass.getMethods();
            ClassDependency classDependency = FetchClassDependency(sootClass);
            System.out.println("Start Analyze Class: " + sootClass.getName());
            classNameSet.add(sootClass.getName());
            for (SootMethod sootMethod : sootMethodSet) {
                try {

                    StmtGraph<?> graph = sootMethod.getBody().getStmtGraph();
                    List<Stmt> stmtList = graph.getStmts();

                    List<String> paramList = new ArrayList<>();
                    for (Type type : sootMethod.getParameterTypes()) {
                        paramList.add(type.toString());
                    }
                    MethodDependency methodDependency = new MethodDependency();
                    methodDependency.myClassDenpendency = classDependency;
                    methodDependency.methodName = sootMethod.getName();
                    methodDependency.methodSignature = sootMethod.getSignature();
                    methodDependency.returnTypeDependency = FetchDepthClassDependency(
                        FetchUnknownClass(sootMethod.getReturnType().toString()), 3);
                    for (Type paramType : sootMethod.getParameterTypes()) {
                        String paramTypeName = paramType.toString();
                        if (!methodDependency.paramTypeDependency.containsKey(paramTypeName)) {
                            methodDependency.paramTypeDependency.put(paramTypeName,
                                FetchDepthClassDependency(FetchUnknownClass(paramTypeName), 3));
                        }
                    }

                    try {
                        methodDependency.myMethondComment = searchFuncComment(sootMethod.getDeclClassType().toString(),
                            sootMethod.getName(), sootMethod.getReturnType().toString(), paramList);
                    } catch (Exception e) {
                        methodDependency.myMethondComment = "";
                    }

                    for (Stmt functionStmt : stmtList) {
                        if (functionStmt.isInvokableStmt()) {
                            InvokableStmt invokableStmt = functionStmt.asInvokableStmt();
                            if (invokableStmt.containsInvokeExpr()) {
                                Optional<AbstractInvokeExpr> funcCallStmt = invokableStmt.getInvokeExpr();
                                if (funcCallStmt.isPresent()) {
                                    //if(sootMethod.getName().equals("AllCfgGenerate")) System.out.println
                                    // (funcCallStmt.get().getMethodSignature().getName());
                                    AbstractInvokeExpr abstractInvokeExpr = funcCallStmt.get();
                                    //System.out.println(abstractInvokeExpr.getMethodSignature().getName());
                                    FuncCommentFetch(abstractInvokeExpr.getMethodSignature(), methodDependency);
                                    if (!methodDependency.stmtTypeDependency.containsKey(
                                        abstractInvokeExpr.getMethodSignature().getType().toString())) {
                                        methodDependency.stmtTypeDependency.put(
                                            abstractInvokeExpr.getMethodSignature().getType().toString(),
                                            FetchDepthClassDependency(FetchUnknownClass(
                                                abstractInvokeExpr.getMethodSignature().getType().toString()), 3));
                                    }
                                }
                            }
                        }

                        for (Value value : functionStmt.getUsesAndDefs().toList()) {
                            if (!value.getType().toString().equals("unknown")) {
                                if (!methodDependency.stmtTypeDependency.containsKey(value.getType().toString())) {
                                    methodDependency.stmtTypeDependency.put(value.getType().toString(),
                                        FetchDepthClassDependency(FetchUnknownClass(value.getType().toString()), 3));
                                }
                            }
                        }
                    }

                    String methodName = sootMethod.getName(), returnType = sootMethod.getReturnType().toString();
                    classDependency.methodDependencyArrayList.put(
                        MethodEmbedding(sootClass.getName(), methodName, returnType, sootMethod.getParameterTypes()),
                        methodDependency);
                } catch (Exception ignored) {}
            }
            String className = sootClass.getName();
            nameToClassDependencyMap.put(embeddingClassString(classPath, className), classDependency);
        }
        AllMethodDependencyToCSV(this);
        FetchAllFunctionCode(classPath);
        return classNameSet;
    }

    /**
     * 该方法用于搜索本地的类注解
     * @param classType 类名
     * @return 注解列表
     */
    private ArrayList<String> searchClassAnnotations(String classType) {
        if (allLocalFileList == null) {
            allLocalFileList = getAllFilePaths(LocalSourcePath);
        }
        String methodPath = classType.replace(".", "/") + ".java";

        String filePath = "";
        if (localClassSourcePath.containsKey(methodPath)) {filePath = localClassSourcePath.get(methodPath);} else {
            filePath = findSourceFilePath(methodPath);
            localClassSourcePath.put(methodPath, filePath);
        }
        if (filePath == null) {return new ArrayList<>();}

        try {
            CompilationUnit cu = StaticJavaParser.parse(new File(filePath));
            Optional<ClassOrInterfaceDeclaration> classRef = cu.getClassByName(
                classType.substring(classType.lastIndexOf('.') + 1));
            if (classRef.isPresent()) {
                ArrayList<String> anotationList = new ArrayList<>();
                for (AnnotationExpr annotationExpr : classRef.get().getAnnotations()) {
                    anotationList.add(annotationExpr.getNameAsString());
                }
                return anotationList;
            }
            return new ArrayList<>();
        } catch (Exception e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    /** 该函数用于获取函数的注释，无需被外部使用*/
    private String searchFuncComment(String classType, String methodName, String returnType, List<String> myParamList)
        throws FileNotFoundException {

        if (allLocalFileList == null) {allLocalFileList = getAllFilePaths(LocalSourcePath);}
        String methodPath = classType.replace(".", "/") + ".java";

        String filePath = "";
        if (localClassSourcePath.containsKey(methodPath)) {filePath = localClassSourcePath.get(methodPath);} else {
            filePath = findSourceFilePath(methodPath);
            localClassSourcePath.put(methodPath, filePath);
        }
        if (filePath == null) {return "";}

        try {
            CompilationUnit cu = StaticJavaParser.parse(new File(filePath));
            Optional<ClassOrInterfaceDeclaration> classRef = cu.getClassByName(
                classType.substring(classType.lastIndexOf('.') + 1));
            if (classRef.isPresent()) {
                //if(classRef.get().getComment().isPresent()) System.out.println(classRef.get().getComment().get()
                // .getContent());
                for (MethodDeclaration method : classRef.get().getMethodsByName(methodName)) {
                    String methodType = method.getTypeAsString(), checkReturnType = returnType.substring(
                        returnType.lastIndexOf('.') + 1);
                    if (methodType.contains(checkReturnType)) {

                        List<Parameter> parameList = method.getParameters();
                        if (parameList.size() != myParamList.size()) {continue;}
                        int paramsMatchNumber = 0;

                        for (int paramIndex = 0; paramIndex < parameList.size(); paramIndex++) {
                            String parameterTypeString = parameList.get(paramIndex).getTypeAsString(),
                                methodSignatureTypeString = myParamList.get(paramIndex).substring(
                                    myParamList.get(paramIndex).lastIndexOf('.') + 1);
                            if (parameterTypeString.contains(methodSignatureTypeString)) {paramsMatchNumber++;}
                        }

                        if (paramsMatchNumber == parameList.size()) {
                            Optional<Comment> comment = method.getComment();
                            if (comment.isEmpty()) {return "";} else {return comment.get().getContent();}
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
        return "";
    }

    /**
     * 获取类的深层Import依赖
     * @param className 类名
     * @return 深层依赖的Import语句
     */
    private ArrayList<String> FetchDeepImport(String className) {
        String sourceRootPath = libRootPath;
        if (classSavePlacePath.containsKey(className)) {
            sourceRootPath = classSavePlacePath.get(className);
        }
        if (sourceRootPath == null) {return new ArrayList<>();}

        if (targetClassFoundSuccessMap.containsKey(className) && !targetClassFoundSuccessMap.get(className)) {
            return new ArrayList<>();
        }

        List<Path> jarPathList = findJarFiles(Paths.get(sourceRootPath));
        if (jarPathList != null) {
            for (Path nowJarPath : jarPathList) {
                try (ZipFile zipFile = new ZipFile(String.valueOf(nowJarPath))) {
                    Enumeration<? extends ZipEntry> entries = zipFile.entries();

                    while (entries.hasMoreElements()) {
                        ZipEntry entry = entries.nextElement();
                        if (entry.getName().equals(className.replace('.', '/') + ".java")) {
                            try (InputStream is = zipFile.getInputStream(entry);
                                 BufferedReader reader = new BufferedReader(new InputStreamReader(is))) {

                                StringBuilder sourceCode = new StringBuilder();
                                String line;
                                while ((line = reader.readLine()) != null) {
                                    sourceCode.append(line).append("\n");
                                }

                                CompilationUnit cu = StaticJavaParser.parse(sourceCode.toString());
                                ArrayList<String> importList = new ArrayList<>();
                                for (ImportDeclaration importDeclaration : cu.getImports()) {
                                    importList.add(importDeclaration.getNameAsString());
                                }

                                targetClassFoundSuccessMap.put(className, true);
                                sourcePathToCompilationUnitMap.put(className, cu);
                                return importList;
                            } catch (Exception e) {
                                System.err.println("解析文件失败: " + entry.getName() + " - " + e.getMessage());
                                targetClassFoundSuccessMap.put(className, false);
                                return new ArrayList<>();
                            }
                        }
                    }
                } catch (IOException e) {
                    System.err.println("读取 JAR 文件失败: " + e.getMessage());
                }
            }
        }
        targetClassFoundSuccessMap.put(className, false);
        return new ArrayList<>();
    }

    /**
     * 该方法用于获取类的深层依赖的类注释
     * @param className 用于获取类名
     * @return 类注释
     */
    private String SearchDeepClassComment(String className) {
        //System.out.println("Now I try to get an remote java class comments");
        String sourceRootPath = libRootPath;
        //if (classSavePlacePath.containsKey(className)) {
        //    sourceRootPath = classSavePlacePath.get(className);
        //}
        if (sourceRootPath == null) {return "";}

        if (targetClassFoundSuccessMap.containsKey(className) && !targetClassFoundSuccessMap.get(className)) {
            return "";
        }

        List<Path> jarPathList = findJarFiles(Paths.get(sourceRootPath));
        if (jarPathList != null) {
            for (Path nowJarPath : jarPathList) {
                try (ZipFile zipFile = new ZipFile(String.valueOf(nowJarPath))) {
                    Enumeration<? extends ZipEntry> entries = zipFile.entries();

                    while (entries.hasMoreElements()) {
                        ZipEntry entry = entries.nextElement();
                        if (entry.getName().equals(className.replace('.', '/') + ".java")) {
                            try (InputStream is = zipFile.getInputStream(entry);
                                 BufferedReader reader = new BufferedReader(new InputStreamReader(is))) {

                                StringBuilder sourceCode = new StringBuilder();
                                String line;
                                while ((line = reader.readLine()) != null) {
                                    sourceCode.append(line).append("\n");
                                }
                                CompilationUnit cu = StaticJavaParser.parse(sourceCode.toString());
                                Optional<ClassOrInterfaceDeclaration> classRef = cu.getClassByName(
                                    className.substring(className.lastIndexOf('.') + 1));
                                if (classRef.isPresent()) {
                                    if (classRef.get().getComment().isPresent()) {
                                        //System.out.println(classRef.get().getComment().get().getContent());
                                        targetClassFoundSuccessMap.put(className, true);
                                        sourcePathToCompilationUnitMap.put(className, cu);
                                        return classRef.get().getComment().get().getContent();
                                    }
                                }

                                sourcePathToCompilationUnitMap.put(className, cu);
                                targetClassFoundSuccessMap.put(className, true);
                                return cu.getAllComments().toString();
                            } catch (Exception e) {
                                System.err.println("解析文件失败: " + entry.getName() + " - " + e.getMessage());
                                targetClassFoundSuccessMap.put(className, false);
                                return "";
                            }
                        }
                    }
                } catch (IOException e) {
                    System.err.println("读取 JAR 文件失败: " + e.getMessage());
                }
            }
        }
        targetClassFoundSuccessMap.put(className, false);
        return "";
    }

    /**
     * 该方法用于获取得到类的深度路径
     * @param sootMethod  代表传入的需要分析参数的sootMethod
     * @return 代表获取到的参数名称
     */
    private ArrayList<String> SearchDeepClassParameter(SootMethod sootMethod) {
        String className = sootMethod.getDeclClassType().toString();
        String sourceRootPath = libRootPath;
        if (classSavePlacePath.containsKey(className)) {
            sourceRootPath = classSavePlacePath.get(className);
        }
        if (sourceRootPath == null) {return new ArrayList<>();}

        if (targetClassFoundSuccessMap.containsKey(className) && !targetClassFoundSuccessMap.get(className)) {
            return new ArrayList<>();
        }

        List<Path> jarPathList = findJarFiles(Paths.get(sourceRootPath));
        if (jarPathList != null) {
            for (Path nowJarPath : jarPathList) {
                try (ZipFile zipFile = new ZipFile(String.valueOf(nowJarPath))) {
                    Enumeration<? extends ZipEntry> entries = zipFile.entries();

                    while (entries.hasMoreElements()) {
                        ZipEntry entry = entries.nextElement();
                        if (entry.getName().equals(className.replace('.', '/') + ".java")) {
                            try (InputStream is = zipFile.getInputStream(entry);
                                 BufferedReader reader = new BufferedReader(new InputStreamReader(is))) {

                                StringBuilder sourceCode = new StringBuilder();
                                String line;
                                while ((line = reader.readLine()) != null) {
                                    sourceCode.append(line).append("\n");
                                }
                                CompilationUnit cu = StaticJavaParser.parse(sourceCode.toString());
                                Optional<ClassOrInterfaceDeclaration> classRef = cu.getClassByName(
                                    className.substring(className.lastIndexOf('.') + 1));
                                if (classRef.isPresent()) {
                                    sourcePathToCompilationUnitMap.put(className, cu);
                                    MethodDeclaration method = getMethodDeclaration(className, sootMethod, cu);
                                    if (method == null) {
                                        targetClassFoundSuccessMap.put(className, false);
                                        return new ArrayList<>();
                                    } else {
                                        ArrayList<String> paramNameList = new ArrayList<>();
                                        for (Parameter parameter : method.getParameters()) {
                                            paramNameList.add(parameter.getName().toString());
                                        }
                                        targetClassFoundSuccessMap.put(className, true);
                                        return paramNameList;
                                    }
                                }
                            } catch (Exception e) {
                                System.err.println("解析文件失败: " + entry.getName() + " - " + e.getMessage());
                                targetClassFoundSuccessMap.put(className, false);
                                return new ArrayList<>();
                            }
                        }
                    }
                } catch (IOException e) {
                    System.err.println("读取 JAR 文件失败: " + e.getMessage());
                    return new ArrayList<>();
                }
            }
        }
        targetClassFoundSuccessMap.put(className, false);
        return new ArrayList<>();
    }

    /** 获取到所有的java源文件*/
    private String findSourceFilePath(String methodPath){
        List<String> localFileList = allLocalFileList == null ?getAllFilePaths(LocalSourcePath):allLocalFileList;
        localFileList = localFileList.stream().map(s -> s.replace("\\","/")).toList();

        for(String path:localFileList){
            if(path.endsWith(methodPath)){
                return path;
            }
        }
        return null;
    }

    /** 获取到所有的Target源文件*/
    private String findTargetFilePath(String className){
        List<String> localFileList = allLocalTargetList.isEmpty()? getAllFilePaths(LocalTargetPath):allLocalTargetList;
        if(allLocalTargetList.isEmpty()) {
            allLocalTargetList.addAll(localFileList);
        }
        if(localTargetClassPath.containsKey(className)) {
            return localTargetClassPath.get(className);
        }
        for(String path:localFileList){
            if(path.contains(className.replace('.','/') + ".class")){
                String substring = path.substring(0, path.lastIndexOf(className.replace('.', '/') + ".class"));
                localTargetClassPath.put(className, substring);
                return substring;
            }
        }
        return "";
    }

    /**该方法用于检索函数的参数名信息
     * @param sootMethod 代笔需要检索的函数sootMethod
     * @return 返回所有的函数名信息
     */
    private ArrayList<String> SearchClassParameter(SootMethod sootMethod) {

        String className = sootMethod.getDeclClassType().toString();
        //System.out.println(className);
        String methodPath = className.replace(".", "/") + ".java";

        try {
            CompilationUnit cu;
            if (sourcePathToCompilationUnitMap.containsKey(className)) {
                cu = sourcePathToCompilationUnitMap.get(className);
            } else {
                String filePath;
                if (localClassSourcePath.containsKey(methodPath)) {
                    filePath = localClassSourcePath.get(methodPath);
                } else {
                    filePath = findSourceFilePath(methodPath);
                    localClassSourcePath.put(methodPath, filePath);
                }
                if (filePath == null) {return SearchDeepClassParameter(sootMethod);}
                cu = StaticJavaParser.parse(new File(filePath));
            }

            MethodDeclaration methodDeclaration = getMethodDeclaration(className, sootMethod, cu);
            if (methodDeclaration == null) {return SearchDeepClassParameter(sootMethod);} else {
                sourcePathToCompilationUnitMap.put(className, cu);
                ArrayList<String> paramNameList = new ArrayList<>();
                for (Parameter parameter : methodDeclaration.getParameters()) {
                    paramNameList.add(parameter.getName().toString());
                }
                return paramNameList;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    /** 该方法用于获取所有的文件信息路径 */
    public static List<String> getAllFilePaths(String directoryPath){
        Path rootPath = Paths.get(directoryPath);
        List<String> filePaths = new ArrayList<>();

        if (!Files.exists(rootPath)) {
            throw new IllegalArgumentException("指定的路径不存在: " + directoryPath);
        }
        try (Stream<Path> stream = Files.walk(rootPath)) {
            stream
                .filter(Files::isRegularFile)
                .map(path -> path.toAbsolutePath().toString().replace("\\", "/"))
                .forEach(filePaths::add);

            return List.copyOf(filePaths); // 返回不可变副本
        } catch (IOException e) {
            throw new UncheckedIOException("遍历目录时发生 I/O 错误: " + rootPath, e);
        }
    }

    /**
     * 该方法用于获取函数的类注释信息
     * @param classType 代表类名
     * @return 返回函数的类注释
     */
    private String searchClassComment(String classType) {
        if (allLocalFileList == null) {allLocalFileList = getAllFilePaths(LocalSourcePath);}
        String methodPath = classType.replace(".", "/") + ".java";

        try {
            CompilationUnit cu;
            if (sourcePathToCompilationUnitMap.containsKey(classType)) {
                cu = sourcePathToCompilationUnitMap.get(classType);
            } else {
                String filePath;
                if (localClassSourcePath.containsKey(methodPath)) {
                    filePath = localClassSourcePath.get(methodPath);
                } else {
                    filePath = findSourceFilePath(methodPath);
                    localClassSourcePath.put(methodPath, filePath);
                }
                if (filePath == null) {return "";}
                cu = StaticJavaParser.parse(new File(filePath));
            }

            Optional<ClassOrInterfaceDeclaration> classRef = cu.getClassByName(
                classType.substring(classType.lastIndexOf('.') + 1));
            if (classRef.isPresent()) {
                if (classRef.get().getComment().isPresent()) {
                    //System.out.println(classRef.get().getComment().get().getContent());
                    return classRef.get().getComment().get().getContent();
                }
            }
            return "";
        } catch (Exception e) {
            e.printStackTrace();
            return SearchDeepClassComment(classType);
        }
    }

    /**
     * 该方法用于获取classPath下的所有targetMethod的所有源代码
     * @param classPath：targetMethod所在的文件更目录
     * 最终的源码信息保存为.csv文件
     */
    private void FetchAllFunctionCode(String classPath) {
        Path pathToBinary = Paths.get(classPath);
        AnalysisInputLocation inputLocation =
            PathBasedAnalysisInputLocation.create(pathToBinary, SourceType.Application);

        View view = new JavaView(inputLocation);

        List<SootClass> sootClassList = view.getClasses().collect(Collectors.toList());
        Map<String, String> methodToSourceCodeMap = new HashMap<>();

        for (SootClass sootClass : sootClassList) {
            try {
                if (sootClass.getName().startsWith("org.example")) {
                    int ap = 1;
                }
                if (allLocalFileList == null) {allLocalFileList = getAllFilePaths(LocalSourcePath);}
                String methodPath = sootClass.getName().replace(".", "/") + ".java";
                CompilationUnit cu = null;
                if (sourcePathToCompilationUnitMap.containsKey(sootClass.getName())) {
                    cu = sourcePathToCompilationUnitMap.get(sootClass.getName());
                }
                if (cu == null) {
                    String filePath;
                    if (localClassSourcePath.containsKey(methodPath)) {
                        filePath = localClassSourcePath.get(methodPath);
                    } else {
                        filePath = findSourceFilePath(methodPath);
                        localClassSourcePath.put(methodPath, filePath);
                    }
                    if (filePath == null) {continue;}
                    cu = StaticJavaParser.parse(new File(filePath));
                }

                String className = sootClass.getName();
                Set<? extends SootMethod> sootMethodSet = sootClass.getMethods();
                for (SootMethod sootMethod : sootMethodSet) {
                    MethodDeclaration method = getMethodDeclaration(className, sootMethod, cu);
                    if (method == null) {continue;}

                    if (method.getBody().isPresent()) {
                        String sourceCode = " ClassName: " + className + "  FunctionName: " + sootMethod.getName()
                            + " ReturnType: " + sootMethod.getReturnType() + " parameterList: " + method.getParameters()
                            +
                            " methodCode: " + method.getBody().get();
                        String methodEmbeddingString = MethodEmbedding(className, sootMethod.getName(),
                            sootMethod.getReturnType().toString(), sootMethod.getParameterTypes());
                        methodToSourceCodeMap.put(methodEmbeddingString, sourceCode);
                        System.out.println(sourceCode);
                    }
                }
            } catch (Exception e) {e.printStackTrace();}
        }

        String csvFilePath = "FunctionToCode.csv";
        ArrayList<String> csvHeaders = new ArrayList<>();
        ArrayList<ArrayList<String>> rowList = new ArrayList<>();
        csvHeaders.add("methodEmbedding");
        csvHeaders.add("CodeInformation");
        for (String methodEmbedding : methodToSourceCodeMap.keySet()) {
            String methodCode = methodToSourceCodeMap.get(methodEmbedding);
            ArrayList<String> row = new ArrayList<>();
            row.add(methodEmbedding);
            row.add(methodCode);
            rowList.add(row);
        }

        try (CSVWriter writer = new CSVWriter(new FileWriter(csvFilePath))) {
            writer.writeNext(csvHeaders.toArray(new String[0]));
            for (ArrayList<String> row : rowList) {
                writer.writeNext(row.toArray(new String[0]));
            }
        } catch (IOException e) {
            System.out.println("Csv Save Fail!");
        }

        writeListToCsvFile(csvFilePath, rowList, csvHeaders);
        if (csvSaveDir != null) {
            writeListToCsvFile(Paths.get(csvSaveDir, csvFilePath).toString(), rowList, csvHeaders);
        }
    }

    /** 用于获取得到类名，方法名以及方法返回值对应的唯一的函数的标识*/
    public String MethodEmbedding(String className, String functionName, String returnType, List<Type> paramTypes) {
        return "_CLASSNAME_" + className.replace('<', '_').replace('[', '+').replace(']', '+').replace('>', '_')
            .replace(", ", "+")
            + "_FUNCTIONNAME_" + functionName.replace('<', '_').replace('>', '_').replace('[', '+').replace(']', '+')
            .replace(", ", "+")
            + "_RETURNTYPE_" + returnType.replace('<', '_').replace('>', '_').replace('[', '+').replace(']', '+')
            .replace(", ", "+")
            + "_Parameters_" + paramTypes.toString().replace('<', '_').replace('>', '_').replace('[', '+').replace(']',
            '+').replace(", ", "+");
    }

    /**
     * 该方法用于获取到一个方法的JavaParsal表示
     * @param className 代表类名
     * @param sootMethod 代表对应的方法
     * @param cu 代表javaParsal的编译单元
     * @return 返回对应的javaParsal干法单元
     */
    private MethodDeclaration getMethodDeclaration(String className, SootMethod sootMethod, CompilationUnit cu) {
        Optional<ClassOrInterfaceDeclaration> classRef = cu.getClassByName(
            className.substring(className.lastIndexOf('.') + 1));
        String methodName = sootMethod.getName();
        List<Type> myParamList = sootMethod.getParameterTypes();
        if (classRef.isPresent()) {
            for (MethodDeclaration method : classRef.get().getMethodsByName(methodName)) {
                if (method.getType().getClass().getClassLoader().equals(
                    sootMethod.getReturnType().getClass().getClassLoader())) {

                    List<Parameter> parameList = method.getParameters();
                    if (parameList.size() != myParamList.size()) {continue;}
                    int paramsMatchNumber = 0;

                    for (int paramIndex = 0; paramIndex < parameList.size(); paramIndex++) {
                        if (parameList.get(paramIndex).getType().getClass().getClassLoader().equals(
                            sootMethod.getParameterTypes().get(paramIndex).getClass().getClassLoader())) {
                            paramsMatchNumber++;
                        }
                    }

                    if (paramsMatchNumber == parameList.size()) {return method;}
                }
            }
        }
        return null;
    }

    /** 获取函数的Import信息
     * @param sootClass 代表需要分析的sootClass类
     * @return 返回所有的Import语句
     */
    private ArrayList<String> FetchImport(SootClass sootClass) {
        if (allLocalFileList == null) {allLocalFileList = getAllFilePaths(LocalSourcePath);}
        String methodPath = sootClass.getName().replace(".", "/") + ".java";

        try {
            CompilationUnit cu;
            if (sourcePathToCompilationUnitMap.containsKey(sootClass.getName())) {
                cu = sourcePathToCompilationUnitMap.get(sootClass.getName());
            } else {
                String filePath;
                if (localClassSourcePath.containsKey(methodPath)) {
                    filePath = localClassSourcePath.get(methodPath);
                } else {
                    filePath = findSourceFilePath(methodPath);
                    localClassSourcePath.put(methodPath, filePath);
                }
                if (filePath == null) {return FetchDeepImport(sootClass.getName());}
                cu = StaticJavaParser.parse(new File(filePath));
            }

            ArrayList<String> importStmtList = new ArrayList<>();
            for (ImportDeclaration importStmt : cu.getImports()) {
                importStmtList.add("import " + importStmt.getNameAsString());
            }
            sourcePathToCompilationUnitMap.put(sootClass.getName(), cu);
            return importStmtList;
        } catch (Exception e) {
            return FetchDeepImport(sootClass.getName());
        }
    }

    /** 该函数用于获取函数的注释，无需被外部使用*/
    private void FuncCommentFetch(MethodSignature methodSignature, MethodDependency methodDependency) {
        try {
            List<String> paramList = new ArrayList<>();
            for (Type type : methodSignature.getParameterTypes()) {paramList.add(type.toString());}

            String comment = searchFuncComment(methodSignature.getDeclClassType().toString(), methodSignature.getName(),
                methodSignature.getType().toString(), paramList);
            if (comment != null) {methodDependency.methodCommentMap.put(methodSignature, comment);}
            methodDependency.methodSignatureArrayList.add(methodSignature);
        } catch (Exception ignored) {}
    }

    private SootClass FetchExtendsMessage(SootClass sootClass) {
        String faClassName = sootClass.getName();
        try {
            if (sootClass.hasSuperclass()) {
                Optional<? extends ClassType> superClassType = sootClass.getSuperclass();
                if (superClassType.isPresent()) {
                    //System.out.println(superClassType.get().toString());
                    String className = superClassType.get().toString();
                    faClassName = className;
                    if (classPathToSootClassMap.containsKey(className)) {return classPathToSootClassMap.get(className);}
                    AnalysisInputLocation inputLocation = PathBasedAnalysisInputLocation.create(
                        Paths.get(Objects.requireNonNull(findTargetFilePath(sootClass.getName()))),
                        SourceType.Application);

                    View view = new JavaView(inputLocation);
                    ClassType classType = view.getIdentifierFactory().getClassType(className);

                    if (view.getClass(classType).isEmpty()) {return FetchUnknownClass(className);}
                    classPathToSootClassMap.put(className, view.getClass(classType).get());
                    return view.getClass(classType).get();
                }
            }
            return null;
        } catch (Exception e) {return FetchUnknownClass(faClassName);}

    }

    /** 获取路径下的所有的jar文件*/
    public static List<Path> findJarFiles(Path startDir) {
        List<Path> result = new ArrayList<>();

        try {
            Files.walk(startDir)
                .filter(path -> !Files.isDirectory(path))
                .filter(path -> path.toString().toLowerCase().endsWith(".jar"))
                .forEach(result::add);

            return result;
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * 获取未知的非本地的SootClass类
     * @param className 需要解析的类名
     * @return 解析得到的sootClass
     */
    public SootClass FetchUnknownClass(String className) {
        className = className.replace("[", "").replace("]", "");
        if (classPathToSootClassMap.containsKey(className)) {return classPathToSootClassMap.get(className);}
        if (!className.startsWith("com.taobao") && !className.startsWith("com.alibaba") && !className.startsWith(
            "org.example")) {
            classSavePlacePath.put(className, null);
            return null;
        }
        if (classSavePlacePath.containsKey(className) && classSavePlacePath.get(className) == null) {return null;}

        try {
            AnalysisInputLocation inputLocation = new JavaClassPathAnalysisInputLocation(
                Objects.requireNonNull(findTargetFilePath(className)));

            View view = new JavaView(inputLocation);
            ClassType classType = view.getIdentifierFactory().getClassType(className);
            if (view.getClass(classType).isPresent()) {
                return view.getClass(classType).get();
            }
        } catch (Exception ignored) {}

        String rootPath = classSavePlacePath.containsKey(className) ? classSavePlacePath.get(className) : libRootPath;
        List<Path> jarList = findJarFiles(Paths.get(rootPath));
        if (jarList != null) {
            for (Path jarPath : jarList) {
                try {
                    Optional<? extends SootClass> paramSootClass = getSootClass(className, jarPath);
                    if (paramSootClass.isPresent()) {
                        classSavePlacePath.put(className,jarPath.toString().replace('\\','/').substring(0,jarPath.toString().replace("\\","/").lastIndexOf('/')));
                        classPathToSootClassMap.put(className, paramSootClass.get());
                        //System.out.println(classSavePlacePath.get(className));
                        return paramSootClass.get();
                    }
                } catch (Exception e) {return null;}
            }
            classSavePlacePath.put(className, null);
            System.err.println("No Class Found!! :: " + className);
            return null;
        }
        return null;
    }

    private static Optional<? extends SootClass> getSootClass(String className, Path jarPath) {
        AnalysisInputLocation inputLocation =
            new JavaClassPathAnalysisInputLocation(jarPath.toString());
        View view = new JavaView(inputLocation);

        try {
            String findClassName = className.substring(className.lastIndexOf('.') + 1).replaceAll(
                Pattern.quote(Character.toString('$')), "");
            String packageName = className.substring(0, className.lastIndexOf('.'));
            ClassType classType = new JavaClassType(findClassName, new PackageName(packageName));
            return view.getClass(classType);
        } catch (Exception e) {
            System.out.println(className);
            return Optional.empty();
        }
    }

    /**
     * 该方法用于获取一个sootClass的全部类依赖
     * @param sootClass 代表需要解析的sootClass内容
     * @return 解析完成的classDependency
     */
    private ClassDependency FetchClassDependency(SootClass sootClass) {
        ClassDependency classDependency = new ClassDependency();
        classDependency.superClass = FetchExtendsMessage(sootClass);
        if (sootClass.hasSuperclass()) {classDependency.superClassDependency = FetchDepthClassDependency(sootClass, 3);}
        classDependency.implementsClassTypeList.addAll(FetchImplementsMessage(sootClass));
        classDependency.className = sootClass.getName();
        classDependency.sootFieldList.addAll(sootClass.getFields());
        for (SootField sootField : classDependency.sootFieldList) {
            String filedName = sootField.getName();
            if (!classDependency.fieldClassList.containsKey(filedName)) {
                classDependency.fieldClassList.put(filedName,
                    FetchDepthClassDependency(FetchUnknownClass(filedName), 3));
            }
        }

        classDependency.importDependencyList.addAll(FetchImport(sootClass));
        classDependency.classComment = searchClassComment(sootClass.getName());
        classDependency.annotationList.addAll(searchClassAnnotations(sootClass.getName()));
        return classDependency;
    }

    /**
     * 该方法用于获取一个sootClass的深层依赖
     * @param sootClass 需要解析 sootClass
     * @param depth 代表依赖的深度
     * @return 返回深层依赖项
     */
    private DeepClassDependency FetchDepthClassDependency(SootClass sootClass, Integer depth) {
        if (sootClass == null) {return null;}
        if (depth == 0) {return null;}
        DeepClassDependency deepClassDependency = new DeepClassDependency();
        deepClassDependency.superClass = FetchExtendsMessage(sootClass);
        if (sootClass.hasSuperclass()) {
            deepClassDependency.superClassDependency = FetchDepthClassDependency(FetchExtendsMessage(sootClass),
                depth - 1);
        }
        deepClassDependency.implementsClassTypeList.addAll(FetchImplementsMessage(sootClass));
        deepClassDependency.className = sootClass.getName();
        deepClassDependency.sootFieldList.addAll(sootClass.getFields());
        deepClassDependency.importDependencyList.addAll(FetchImport(sootClass));
        deepClassDependency.classComment = searchClassComment(sootClass.getName());
        deepClassDependency.annotationList.addAll(searchClassAnnotations(sootClass.getName()));
        deepClassDependency.sootMethodSet = sootClass.getMethods();
        for (SootMethod sootMethod : sootClass.getMethods()) {
            ArrayList<String> parameterList = SearchClassParameter(sootMethod);
            deepClassDependency.methodToParameterMap.put(sootMethod, parameterList);
        }
        return deepClassDependency;
    }

    private ArrayList<String> FetchImplementsMessage(SootClass sootClass) {
        ArrayList<String> implementsList = new ArrayList<>();
        for (ClassType implementsUsage : sootClass.getInterfaces()) {
            implementsList.add(implementsUsage.getClassName());
        }
        return implementsList;
    }

    /**
     * 获取所有依赖的控制台可视化输出
     */
    public void MethodSignatureOutput() {
        for (MethodSignature methodSignature : methodSignatureArrayList) {
            System.out.println(methodSignature.getDeclClassType() + " " +
                methodSignature.getName() + " " + methodSignature.getParameterTypes() + "   Comment: "
                + methodCommentMap.get(methodSignature));
        }
    }

    /**
     * 获取所有依赖的控制台可视化输出
     */
    public void AllMethodDependencyOutput() {
        for (String classEmbedding : nameToClassDependencyMap.keySet()) {
            System.out.println("Class : " + classEmbedding);
            ClassDependency classDependency = nameToClassDependencyMap.get(classEmbedding);
            System.out.println("    Father Class: " + (classDependency.superClass == null ? " "
                : classDependency.superClass.getName()));
            System.out.println("    Implements Uses: " + classDependency.implementsClassTypeList);
            System.out.println("    Import Use: " + classDependency.importDependencyList);
            System.out.println("    Class Comment: " + classDependency.classComment);
            System.out.print("    Class Annotations Use: ");
            for (String annotation : classDependency.annotationList) {System.out.print(" " + annotation);}
            System.out.println();
            System.out.println("    Field Use: ");
            for (SootField sootField : classDependency.sootFieldList) {
                System.out.println(
                    "        Field Type: " + sootField.getType() + "     Field Name: " + sootField.getName());
            }
            for (String methodEmbedding : classDependency.methodDependencyArrayList.keySet()) {
                MethodDependency methodDependency = classDependency.methodDependencyArrayList.get(methodEmbedding);
                System.out.println(
                    "    MethodName : " + methodEmbedding + "  MethodComment: " + methodDependency.myMethondComment);
                for (MethodSignature methodSignature : methodDependency.methodSignatureArrayList) {
                    System.out.println("        MethodUse: " + methodSignature.getName() + "    Comment: "
                        + methodDependency.methodCommentMap.get(methodSignature));
                }
            }
        }
    }

    /**
     * 获取得到类名的编码，用于获取类依赖
     * @param classPath：类路径
     * @param className：类名
     * &#064;return：  得到的编码
     */
    public String embeddingClassString(String classPath, String className) {
        return classPath.replace("/", ".") + (classPath.endsWith("/") || classPath.endsWith(".") ? className
            : "." + className);
    }

    /**
     * 获取得到方法编码，用于获取方法依赖
     * @param methodName： 方法名
     * @param returnType：返回值类型
     * @param paramType：参数列表
     * &#064;return：得到的编码
     */
    public String embeddingFuncString(String methodName, String returnType, List<String> paramType) {
        return methodName + "***" + returnType + "***" + paramType.toString();
    }

    public String getReturnTypeFromFunctionEmbedding(String functionEmbedding) {
        String startDelimiter = "\\*\\*\\*";
        String endDelimiter = "\\*\\*\\*";

        Pattern pattern = Pattern.compile(startDelimiter + "(.*?)" + endDelimiter);
        Matcher matcher = pattern.matcher(functionEmbedding);

        if (matcher.find()) {
            return matcher.group(1);
        } else {return " ";}
    }

    public String getParametersFromFunctionEmbedding(String functionEmbedding) {
        String delimiter = "***";

        int lastIndex = functionEmbedding.lastIndexOf(delimiter);
        if (lastIndex != -1) {
            return functionEmbedding.substring(lastIndex + delimiter.length());
        } else {return " ";}
    }

    /**
     * 该方法用于深度检索类依赖
     * @param deepClassDependency 需要深度检索的依赖
     * @param dependencyMap 类名与依赖的对应关系
     */
    private void WalkDeepClassDependency(DeepClassDependency deepClassDependency,
        Map<String, DeepClassDependency> dependencyMap) {
        if (deepClassDependency == null) {return;}
        String className = deepClassDependency.className;
        if (!dependencyMap.containsKey(className)) {
            dependencyMap.put(className, deepClassDependency);
            if (deepClassDependency.superClassDependency != null) {
                WalkDeepClassDependency(deepClassDependency.superClassDependency, dependencyMap);
            }
        }
    }

    /**该方法用于将路径依赖写入文件中*/
    public void AllMethodDependencyToCSV(DependencyGeneration dependencyGeneration) {
        int maxPathLenth = 0;
        for (ClassDependency classDependency : dependencyGeneration.nameToClassDependencyMap.values()) {
            for (MethodDependency methodDependency : classDependency.methodDependencyArrayList.values()) {
                maxPathLenth = Math.max(maxPathLenth, methodDependency.methodSignatureArrayList.size());
            }
        }

        String csvFilePath = "AllDependency.csv";
        ArrayList<String> csvHeaders = new ArrayList<>();
        csvHeaders.add("ClassName");
        csvHeaders.add("MethodEmbedding");
        csvHeaders.add("MethodName");
        csvHeaders.add("MethodReturnType");
        csvHeaders.add("MethodParameters");
        csvHeaders.add("FatherClassName");
        csvHeaders.add("Import");
        csvHeaders.add("ClassComment");
        csvHeaders.add("MethodComment");
        csvHeaders.add("ClassFields");
        csvHeaders.add("ClassAnnotations");
        for (int methodUseIndex = 1; methodUseIndex <= maxPathLenth; methodUseIndex++) {
            csvHeaders.add("MethodUseName_" + methodUseIndex);
            csvHeaders.add("UsedMethodComment_" + methodUseIndex);
        }

        String classDependencySaveFilePath = "DeepClassDependency.csv";
        ArrayList<String> classDependencyCsvHeader = new ArrayList<>();
        classDependencyCsvHeader.add("ClassName");
        classDependencyCsvHeader.add("Import");
        classDependencyCsvHeader.add("ClassComment");
        classDependencyCsvHeader.add("ClassAnnotations");
        classDependencyCsvHeader.add("ClassFields");
        classDependencyCsvHeader.add("MethodsSignature");
        classDependencyCsvHeader.add("SuperClass");
        Map<String, DeepClassDependency> allDeepClassDependencyMap = new HashMap<>();

        ArrayList<ArrayList<String>> csvRowList = new ArrayList<>();
        ArrayList<ArrayList<String>> dependencyRowList = new ArrayList<>();
        for (String className : dependencyGeneration.nameToClassDependencyMap.keySet()) {

            ClassDependency classDependency = dependencyGeneration.nameToClassDependencyMap.get(className);
            if (classDependency.superClassDependency != null) {
                WalkDeepClassDependency(classDependency.superClassDependency, allDeepClassDependencyMap);
            }
            for (DeepClassDependency deepClassDependency : classDependency.fieldClassList.values()) {
                if (deepClassDependency != null) {
                    WalkDeepClassDependency(deepClassDependency, allDeepClassDependencyMap);
                }
            }

            for (String MethodName : classDependency.methodDependencyArrayList.keySet()) {
                MethodDependency methodDependency = classDependency.methodDependencyArrayList.get(MethodName);
                ArrayList<String> rowList = new ArrayList<>();
                rowList.add(className);
                rowList.add(MethodName);
                rowList.add(methodDependency.methodName);
                rowList.add(getReturnTypeFromFunctionEmbedding(MethodName));
                rowList.add(getParametersFromFunctionEmbedding(MethodName));
                rowList.add((classDependency.superClass == null) ? " " : classDependency.superClass.getName());
                rowList.add(classDependency.importDependencyList.toString());
                rowList.add(
                    classDependency.classComment == null ? " " : classDependency.classComment.replace("\n", "  "));
                rowList.add(methodDependency.myMethondComment == null ? " "
                    : methodDependency.myMethondComment.replace("\n", "  "));

                StringBuilder classFieldString = new StringBuilder();
                for (int fieldIndex = 0; fieldIndex < classDependency.sootFieldList.size(); fieldIndex++) {
                    classFieldString.append("  (").append(fieldIndex).append(") ").append(
                        classDependency.sootFieldList.get(fieldIndex).getType()).append("  ").append(
                        classDependency.sootFieldList.get(fieldIndex).getName());
                }
                rowList.add(String.valueOf(classFieldString));

                StringBuilder classAnnotationsString = new StringBuilder();
                for (int annotationIndex = 0; annotationIndex < classDependency.annotationList.size();
                     annotationIndex++) {
                    classAnnotationsString.append("  (").append(annotationIndex).append(") ").append(
                        classDependency.annotationList.get(annotationIndex)).append("  ");
                }
                rowList.add(String.valueOf(classAnnotationsString));

                for (MethodSignature methodSignature : methodDependency.methodSignatureArrayList) {
                    rowList.add(methodSignature.getName());
                    rowList.add(methodDependency.methodCommentMap.get(methodSignature) == null ? " "
                        : methodDependency.methodCommentMap.get(methodSignature).replace("\n", "  "));
                }
                csvRowList.add(rowList);

                if (methodDependency.returnTypeDependency != null) {
                    WalkDeepClassDependency(methodDependency.returnTypeDependency, allDeepClassDependencyMap);
                }
                for (DeepClassDependency deepClassDependency : methodDependency.paramTypeDependency.values()) {
                    if (deepClassDependency != null) {
                        WalkDeepClassDependency(deepClassDependency, allDeepClassDependencyMap);
                    }
                }
                for (DeepClassDependency deepClassDependency : methodDependency.stmtTypeDependency.values()) {
                    if (deepClassDependency != null) {
                        WalkDeepClassDependency(deepClassDependency, allDeepClassDependencyMap);
                    }
                }
            }
        }

        for (DeepClassDependency deepClassDependency : allDeepClassDependencyMap.values()) {
            ArrayList<String> rowList = new ArrayList<>();
            rowList.add(deepClassDependency.className);
            rowList.add(deepClassDependency.importDependencyList.toString());
            rowList.add(deepClassDependency.classComment);
            rowList.add(deepClassDependency.annotationList.toString());

            StringBuilder classFieldString = new StringBuilder();
            for (int fieldIndex = 0; fieldIndex < deepClassDependency.sootFieldList.size(); fieldIndex++) {
                classFieldString.append("  (").append(fieldIndex).append(") ").append(
                    deepClassDependency.sootFieldList.get(fieldIndex).getType()).append("  ").append(
                    deepClassDependency.sootFieldList.get(fieldIndex).getName());
            }
            rowList.add(String.valueOf(classFieldString));

            StringBuilder methodString = new StringBuilder();
            int methodIndex = 0;
            for (SootMethod sootMethod : deepClassDependency.sootMethodSet) {

                String methodType = "default";
                String methodStatic = "";
                if (sootMethod.isStatic()) {methodStatic = "  static";}
                if (sootMethod.isPrivate()) {methodType = "private";} else if (sootMethod.isProtected()) {
                    methodType = "protected";
                } else if (sootMethod.isPublic()) {
                    methodType = "public";
                }
                String methodTypeString = methodType + methodStatic;

                String sootParameterString = sootMethod.getParameterTypes().toString();
                if (!(deepClassDependency.methodToParameterMap.get(sootMethod) == null)) {
                    List<String> parameterDependencyList = new ArrayList<>();
                    int parameterNumber = sootMethod.getParameterCount();
                    int actualGetParameterNumber = deepClassDependency.methodToParameterMap.get(sootMethod).size();
                    if (parameterNumber == actualGetParameterNumber) {
                        for (int parameterIndex = 0; parameterIndex < parameterNumber; parameterIndex++) {
                            parameterDependencyList.add(
                                "Type: " + sootMethod.getParameterTypes().get(parameterIndex) + "  Name: "
                                    + deepClassDependency.methodToParameterMap.get(sootMethod).get(parameterIndex));
                        }
                        sootParameterString = parameterDependencyList.toString();
                    }
                }

                String methodSignature = "(" + methodIndex + ")  :  MethodType: " + methodTypeString + "  Name: "
                    + sootMethod.getName() + "  ReturnType:  " + sootMethod.getReturnType() + "  parameterList:  "
                    + sootParameterString;
                methodString.append(methodSignature).append("\n");
                methodIndex++;
            }
            rowList.add(String.valueOf(methodString));
            rowList.add(deepClassDependency.superClass == null ? "" : deepClassDependency.superClass.getName());
            dependencyRowList.add(rowList);
        }

        writeListToCsvFile(csvFilePath, csvRowList, csvHeaders);
        if (csvSaveDir != null) {
            writeListToCsvFile(Paths.get(csvSaveDir, csvFilePath).toString(), csvRowList, csvHeaders);
        }

        writeListToCsvFile(classDependencySaveFilePath, dependencyRowList, classDependencyCsvHeader);
        if (csvSaveDir != null) {
            writeListToCsvFile(Paths.get(csvSaveDir, classDependencySaveFilePath).toString(), dependencyRowList,
                classDependencyCsvHeader);
        }
    }

    public static void writeListToCsvFile(String savePath, ArrayList<ArrayList<String>> rowList,
        ArrayList<String> csvHeader) {
        try (CSVWriter writer = new CSVWriter(new FileWriter(savePath))) {
            writer.writeNext(csvHeader.toArray(new String[0]));
            for (ArrayList<String> row : rowList) {
                writer.writeNext(row.toArray(new String[0]));
            }
        } catch (IOException e) {
            System.out.println("Csv Save Fail!");
        }
    }

    public static void main(String[] args) {

    }
}
