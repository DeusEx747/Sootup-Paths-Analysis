package com.alibaba.ad.code.pathanalyzer;

import com.alibaba.ad.code.pathanalyzer.node.Node;
import sootup.core.jimple.common.stmt.Stmt;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PathAnalyzer {
    /**
    * 分析图中所有路径，找到产生分支的节点编号，从stmt中提取分支信息，并储存到node中。
    * 这是分支分析的入口函数。
    *
    * @param paths 所有可能的路径，每个路径是一个 List<Integer>，表示节点编号
    * @param stmts index 与 stmt 的映射关系
    * @param saveToFile 是否保存节点到csv文件
    * @param methodName 方法名，只有saveToFile为true时才需要，否则可以为null
    * @return 产生分支的节点列表
    */
    public List<Node> analyse(ArrayList<ArrayList<Integer>> paths, Map<Integer, Stmt> index, boolean saveToFile, String methodName) throws Exception {
        List<Node> nodes = new ArrayList<>();
        List<Index> branchNodes = new ArrayList<>();
        Map<Integer, String> stack = new HashMap<>();
        branchNodes = new IndexAnalyzer().analyse(paths, index);
        if(branchNodes.isEmpty()) {
            return nodes;
        }
        stack = new StackAnalyzer().analyse(index);
        nodes = new NodeAnalyzer().analyse(branchNodes, index, stack);
        if(saveToFile) {
            if(methodName == null) {
                throw new Exception("Method name is null.");
            }
            saveNode(nodes, methodName);
        }
        return nodes;
    }

    /**
    * 保存节点到文件
    * @param nodes 节点列表
    * @param methodName 方法名，用作文件名
    * @throws IOException 如果写入文件时发生 I/O 错误
    * @deprecated 已不再适用，被新的储存方式替代
    */
    @Deprecated
    private void saveNode(List<Node> nodes, String methodName) throws IOException {
        String fileName = methodName + ".csv";
        
        try (FileWriter writer = new FileWriter(fileName)) {
            // 写入CSV头部
           writer.append("Index,Type,PartialContent,FullContent\n");
            
            // 写入每个节点
            for (Node node : nodes) {
                String fullContent = node.toString();
                String partialContent = fullContent.contains(",") ? 
                    fullContent.substring(fullContent.indexOf(",") + 1) : fullContent;
                
                writer.append(String.valueOf(node.getIndex())).append(",")
                      .append(node.getType().toString()).append("，")
                      .append(escapeCSV(partialContent)).append("，")
                      .append(escapeCSV(fullContent)).append("\n");
            }
            
            writer.flush();
        }
    }

    // 辅助方法：转义 CSV 字段中的特殊字符
    @Deprecated
    private String escapeCSV(String field) {
        if (field.contains("\"") || field.contains(",") || field.contains("\n")) {
            return "\"" + field.replace("\"", "\"\"") + "\"";
        }
        return field;
    }
}
