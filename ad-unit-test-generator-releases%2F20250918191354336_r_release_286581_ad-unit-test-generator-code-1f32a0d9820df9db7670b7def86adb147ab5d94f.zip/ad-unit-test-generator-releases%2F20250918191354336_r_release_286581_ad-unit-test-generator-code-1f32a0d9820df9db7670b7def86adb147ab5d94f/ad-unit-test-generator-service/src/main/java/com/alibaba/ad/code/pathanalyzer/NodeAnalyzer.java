package com.alibaba.ad.code.pathanalyzer;

import com.alibaba.ad.code.pathanalyzer.node.GotoNode;
import com.alibaba.ad.code.pathanalyzer.node.IfNode;
import com.alibaba.ad.code.pathanalyzer.node.Node;
import com.alibaba.ad.code.pathanalyzer.node.SwitchNode;
import sootup.core.jimple.common.stmt.Stmt;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class NodeAnalyzer {


    /**
     * 分析产生分支的节点，从stmt中提取分支信息，并储存到node中。
     * @param branchNodes 产生分支的节点编号
     * @param index index 与 stmt 的映射关系
     * @param stack 栈信息
     * @return 产生分支的节点, 数据结构为List<Node>
     * @throws Exception 如果产生分支的节点编号或index为空，则抛出异常
     */
    public List<Node> analyse(List<Index> branchNodes, Map<Integer, Stmt> index, Map<Integer, String> stack) throws Exception {
        if(branchNodes.isEmpty()) {
            throw new Exception("No branch nodes found.");
        }
        if(index.isEmpty()) {
            throw new Exception("No index found.");
        }
        List<Node> nodes = new ArrayList<>();
        for(Index branchNode:branchNodes) {
            String stmt = index.get(branchNode.getIndex()).toString();
            // 使用空格分割字符串
            String[] stmtArray = stmt.split(" ");
            if(stmtArray.length < 1) {
                throw new Exception("Stmt is not valid.");
            }
            if(stmtArray[0].equals("if")) {
                IfNode node = new IfNode();
                node.setIndex(branchNode.getIndex());
                node.setCondition(stmt);
                nodes.add(node);
                // 继续添加true分支和false分支，其中第1个是true分支，第0个是false分支
                node.setTrueBranch(index.get(branchNode.getNextIndex().get(1)).toString());
                node.setFalseBranch(index.get(branchNode.getNextIndex().get(0)).toString());
                // 判断是否有栈信息需要添加
                if (stmt.contains("$stack") || node.getTrueBranch().contains("$stack") || node.getFalseBranch().contains("$stack")) {
                    List<String> stringsToCheck = new ArrayList<>();
                    stringsToCheck.add(stmt);
                    stringsToCheck.add(node.getTrueBranch());
                    stringsToCheck.add(node.getFalseBranch());
                    Pattern pattern = Pattern.compile("\\$stack(\\d+)");
                    for (String str : stringsToCheck) {
                        Matcher matcher = pattern.matcher(str);
                        while (matcher.find()) {
                            int stackNumber = Integer.parseInt(matcher.group(1));
                            String stackInfo = stack.get(stackNumber);
                            if (stackInfo != null) {
                                ((IfNode) node).addStackInfo("$stack" + stackNumber+ " = " + stackInfo);
                            }
                        }
                    }
                }
                continue;
            }
            if(stmtArray[0].equals("goto")) {
                if(branchNode.getIndex() - 1 < 1) {
                    throw new Exception("goto stmt error");
                }
                GotoNode node = new GotoNode();
                node.setIndex(branchNode.getIndex());
                node.setFrom(index.get(branchNode.getIndex() - 1).toString());
                node.setWhere(index.get(branchNode.getNextIndex().get(0)).toString());
                // 判断是否有栈信息需要添加
                if (stmt.contains("$stack") || node.getFrom().contains("$stack") || node.getWhere().contains("$stack")) {
                    List<String> stringsToCheck = new ArrayList<>();
                    stringsToCheck.add(stmt);
                    stringsToCheck.add(node.getFrom());
                    stringsToCheck.add(node.getWhere());
                    Pattern pattern = Pattern.compile("\\$stack(\\d+)");
                    for (String str : stringsToCheck) {
                        Matcher matcher = pattern.matcher(str);
                        while (matcher.find()) {
                            int stackNumber = Integer.parseInt(matcher.group(1));
                            String stackInfo = stack.get(stackNumber);
                            if (stackInfo != null) {
                                node.addStackInfo("$stack" + stackNumber+ " = " + stackInfo);
                            }
                        }
                    }
                }
                nodes.add(node);
                continue;
            }
            if(stmtArray[0].contains("switch")) {
                SwitchNode node = new SwitchNode();
                node.setIndex(branchNode.getIndex());
                String condition = stmtArray[0].substring(7, stmtArray[0].length() - 1);
                node.setCondition(condition);
                for(int i = 1; !stmtArray[i].equals("}"); i++) {
                    if(stmtArray[i].equals("case")) {
                        node.addCase(stmtArray[i + 1].substring(0, stmtArray[i + 1].length() - 1));
                    }
                }
                for(int i = 0; i < node.getCases().size(); i++) {
                    node.addBranch(index.get(branchNode.getNextIndex().get(i)).toString());
                }
                if(branchNode.getNextIndex().size() - node.getCases().size() > 0) {
                    node.setDefaultBranch(index.get(branchNode.getNextIndex().get(node.getCases().size())).toString());
                }
                // 判断是否有栈信息需要添加
                if (stmt.contains("$stack") || node.getCondition().contains("$stack") || node.getDefaultBranch().contains("$stack")) {
                    List<String> stringsToCheck = new ArrayList<>();
                    stringsToCheck.add(stmt);
                    stringsToCheck.add(node.getCondition());
                    stringsToCheck.add(node.getDefaultBranch());
                    Pattern pattern = Pattern.compile("\\$stack(\\d+)");
                    for (String str : stringsToCheck) {
                        Matcher matcher = pattern.matcher(str);
                        while (matcher.find()) {
                            int stackNumber = Integer.parseInt(matcher.group(1));
                            String stackInfo = stack.get(stackNumber);
                            if (stackInfo != null) {
                                node.addStackInfo("$stack" + stackNumber+ " = " + stackInfo);
                            }
                        }
                    }
                }
                nodes.add(node);
                continue;
            }
        }
        // sort nodes
        nodes.sort(Comparator.comparingInt(Node::getIndex));
        return nodes;
    }

    
    
}
