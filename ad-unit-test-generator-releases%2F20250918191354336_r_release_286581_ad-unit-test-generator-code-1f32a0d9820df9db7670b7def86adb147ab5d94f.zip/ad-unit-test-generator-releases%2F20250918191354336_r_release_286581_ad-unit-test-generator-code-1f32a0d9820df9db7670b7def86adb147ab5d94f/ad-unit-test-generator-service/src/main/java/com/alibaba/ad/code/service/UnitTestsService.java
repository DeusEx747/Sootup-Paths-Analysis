package com.alibaba.ad.code.service;


import java.io.IOException;
import java.util.Set;

import com.alibaba.ad.code.dto.ResultDTO;

public interface UnitTestsService {

    ResultDTO gitCloneRepository(String appName, String uuid);

    ResultDTO compileModule(String appName, String uuid);

    ResultDTO dependencyAndCfgGeneration(String uuid, String moduleName, String appName);

    ResultDTO dependencyGeneration(String uuid, String moduleName, String appName, String subPath);

    ResultDTO cfgGeneration(String uuid, String moduleName, String appName, String subPath);

    ResultDTO stag1PromptGeneration(String uuid, String moduleName, String appName);

    ResultDTO stag2PromptGeneration(String uuid, String moduleName, String appName);

    ResultDTO stage1PromptGeneration(String uuid, String moduleName, String appName, String subPath, Set<String> hasAnnotations, Set<String> implementInterfaces, Set<String> classNames, String callbackUrl);

    ResultDTO stage2PromptGeneration(String workDir, String callbackUrl);

    ResultDTO testOssUpload(String localFilePath, String ossFilePath) throws IOException;
    ResultDTO testOssDownload();
}
