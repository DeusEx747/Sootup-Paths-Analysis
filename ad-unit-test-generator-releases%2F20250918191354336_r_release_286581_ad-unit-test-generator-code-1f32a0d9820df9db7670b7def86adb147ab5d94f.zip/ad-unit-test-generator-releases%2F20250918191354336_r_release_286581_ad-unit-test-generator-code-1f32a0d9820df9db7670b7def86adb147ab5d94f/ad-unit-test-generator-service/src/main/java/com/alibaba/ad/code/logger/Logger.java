package com.alibaba.ad.code.logger;

public class Logger {

    private static Logger logger = new Logger();

    private long startTime;
    private int totalOperations;
    private int errorOperations;

    // ANSI颜色代码
    private static final String RESET = "\u001B[0m";
    private static final String RED = "\u001B[31m";
    private static final String GREEN = "\u001B[32m";
    private static final String YELLOW = "\u001B[33m";
    private static final String BOLD = "\u001B[1m";

    private Logger() {
        startTime = System.currentTimeMillis();
        totalOperations = 0;
        errorOperations = 0;
    }

    public static Logger getInstance() {
        return logger;
    }

    public void addOperation(int operation) {
        totalOperations+=operation;
    }

    public void logError(String error) {
        System.out.println(BOLD + RED + "[ERROR] " + RESET + RED + error + RESET);
        errorOperations++;
    }

    public void logWarning(String warning) {
        System.out.println(BOLD + YELLOW + "[WARNING] " + RESET + YELLOW + warning + RESET);
    }

    public void generateSummary() {
        long endTime = System.currentTimeMillis();
        long timeTaken = endTime - startTime;
        double errorRate = (double) errorOperations / totalOperations;
        System.out.println("========================================");
        System.out.println(BOLD + GREEN + "[SUMMARY] " + RESET);
        System.out.println("Total operations: " + totalOperations);
        System.out.println("Error operations: " + errorOperations);
        System.out.println("Error rate: " + errorRate);
        System.out.println("Time taken: " + timeTaken + "ms");
        System.out.println("========================================");
    }

}
