package com.alibaba.ad.code.pathanalyzer;

import sootup.core.jimple.common.stmt.Stmt;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class IndexAnalyzer {

    /**
     * 分析图中所有路径，找到产生分支的节点编号。
     * 永远不应该调用该方法，调用接口被封装在 PathAnalyzer 中。
     *
     * @param paths 所有可能的路径，每个路径是一个 List<Integer>，表示节点编号。
     * @param stmts index 与 stmt 的映射关系
     * @return 产生分支的节点编号列表。
     * @throws Exception 输入或输出为空。
     */
    protected List<Index> analyse(ArrayList<ArrayList<Integer>> paths, Map<Integer, Stmt> stmts) throws Exception {
        if(paths == null || paths.isEmpty()) {
            throw new Exception("Paths is null or empty.");
        }
        // 用于记录每个节点在多少条路径中出现
        Map<Integer, Integer> nodeCountMap = new HashMap<>();
        
        // 遍历所有路径，统计每个节点出现的次数
        for (List<Integer> path : paths) {
            for (int node : path) {
                nodeCountMap.put(node, nodeCountMap.getOrDefault(node, 0) + 1);
            }
        }

        // 用于存储产生分支的节点编号
        List<Index> branchNodes = new ArrayList<>();

        // 再次遍历所有路径，找到分支节点
        for (List<Integer> path : paths) {
            for (int i = 0; i < path.size(); i++) {
                int node = path.get(i);
                // 如果当前节点在多条路径中出现，则可能是分支节点
                if (nodeCountMap.get(node) > 1) {
                    // 检查当前节点是否连接到不同的后续节点
                    Set<Integer> nextNodes = isBranchNode(paths, node);
                    if (nextNodes.size() > 1) {
                        // 重复的index不会被加入branchNodes
                        boolean isDuplicate = false;
                        for(Index index : branchNodes) {
                            if(index.getIndex() == node) {
                                isDuplicate = true;
                                break;
                            }
                        }
                        List<Integer> nextIndex = new ArrayList<>(nextNodes);
                        if(!isDuplicate) {
                            branchNodes.add(new Index(node, nextIndex));
                        }
                    }
                }
                if(stmts.get(i + 1).toString().equals("goto")) {
                    Set<Integer> nextNodes = isBranchNode(paths, node);
                    boolean isDuplicate = false;
                    for(Index index : branchNodes) {
                        if(index.getIndex() == node) {
                            isDuplicate = true;
                            break;
                        }
                    }
                    List<Integer> nextIndex = new ArrayList<>(nextNodes);
                    if(!isDuplicate) {
                        branchNodes.add(new Index(node, nextIndex));
                    }
                }
            }
        }

        // if(branchNodes.isEmpty()) {
        //     throw new Exception("No branch nodes found.");
        // }

        // for(Index index : branchNodes) {
        //     System.out.println(index.getIndex());
        // }

        return branchNodes;
    }

    /**
     * 判断某个节点是否是分支节点。
     *
     * @param paths 所有可能的路径。
     * @param node  要判断的节点编号。
     * @return 如果该节点是分支节点，返回其所有后继。
     */
    private Set<Integer> isBranchNode(ArrayList<ArrayList<Integer>> paths, int node) {
        Set<Integer> nextNodes = new HashSet<>();

        for (ArrayList<Integer> path : paths) {
            for (int i = 0; i < path.size() - 1; i++) {
                if (path.get(i) == node) {
                    // 记录当前节点的下一个节点
                    nextNodes.add(path.get(i + 1));
                }
            }
        }

        // 如果当前节点有多个不同的后续节点，则它是分支节点
        return nextNodes;
    }
}

class Index {
    private int index;
    private List<Integer> nextIndex;

    public Index(int index, List<Integer> nextIndex) {
        this.index = index;
        this.nextIndex = nextIndex;
        sortNextIndex();
    }

    private void sortNextIndex() {
        nextIndex.sort(Comparator.naturalOrder());
    }

    public int getIndex() {
        return index;
    }

    public List<Integer> getNextIndex() {
        return nextIndex;
    }
    
}