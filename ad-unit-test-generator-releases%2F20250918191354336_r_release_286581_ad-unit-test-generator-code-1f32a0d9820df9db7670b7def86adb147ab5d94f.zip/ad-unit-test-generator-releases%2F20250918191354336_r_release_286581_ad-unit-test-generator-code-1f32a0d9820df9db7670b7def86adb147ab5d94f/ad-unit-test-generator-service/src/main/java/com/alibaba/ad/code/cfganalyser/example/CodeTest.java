package com.alibaba.ad.code.cfganalyser.example;

public class CodeTest {


    public CodeTest() {

    }

    public static void main(String[] args) {
        CodeTest hw = new CodeTest();
        hw.hello(1,'b',"a",new CodeTest());
        for(int i = 1;i < (1 << 10);i ++ ){
            for(int j = i;j != 0;j = i&(j-1)){
                if(i == 11) System.out.println(j);
            }
        }
    }

    public void hello(int a,char b,String c,CodeTest helloTest) {
        if(a == 1) return;
        if(b == 'a') return;
        if(c.equals("c")) return;
        helloTest.routeTest(c);


        for(int i = 1;i < (1 << 10);i ++ ){
            for(int j = i;j != 0;j = i&(j-1)){
                //1011,1010,1001,1000,11,10,01
                if(i == 11) System.out.println(j);
            }
        }
    }

    public void routeTest(String s){
        int a = 0;
        if(a == 0) System.out.println(1);
        for(int i = 0;i < 10;i ++ ) System.out.println(i);
        return;
    }
}
