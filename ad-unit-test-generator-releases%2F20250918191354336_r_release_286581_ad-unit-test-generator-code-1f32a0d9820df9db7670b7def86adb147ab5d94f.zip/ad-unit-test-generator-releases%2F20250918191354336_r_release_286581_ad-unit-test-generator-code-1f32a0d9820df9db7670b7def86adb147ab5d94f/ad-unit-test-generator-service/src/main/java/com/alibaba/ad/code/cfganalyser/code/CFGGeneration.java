package com.alibaba.ad.code.cfganalyser.code;

import com.alibaba.ad.code.cfganalyser.code.util.ClassFilterUtil;
import com.alibaba.ad.code.cfganalyser.code.util.DependencyUtil;
import com.alibaba.ad.code.dependencyAnalyzer.CFGWithDependency;
import com.alibaba.ad.code.logger.Logger;
import com.alibaba.ad.code.pathanalyzer.PathAnalyzer;
import com.alibaba.ad.code.pathanalyzer.node.Node;

import com.google.common.collect.Sets;
import com.opencsv.CSVWriter;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.collections4.CollectionUtils;
import sootup.core.graph.BasicBlock;
import sootup.core.graph.StmtGraph;
import sootup.core.inputlocation.AnalysisInputLocation;
import sootup.core.jimple.basic.Value;
import sootup.core.jimple.common.expr.AbstractInvokeExpr;
import sootup.core.jimple.common.stmt.InvokableStmt;
import sootup.core.jimple.common.stmt.Stmt;
import sootup.core.model.SootClass;
import sootup.core.model.SootMethod;
import sootup.core.model.SourceType;
import sootup.core.signatures.MethodSignature;
import sootup.core.types.ClassType;
import sootup.core.types.Type;
import sootup.core.util.DotExporter;
import sootup.core.views.View;
import sootup.java.bytecode.frontend.inputlocation.PathBasedAnalysisInputLocation;
import sootup.java.core.AnnotationUsage;
import sootup.java.core.JavaSootClass;
import sootup.java.core.views.JavaView;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * CFGGeneration类：用于生成方法的CFG图以及图中的各种路径
 * 路径获取方法：cfgGeneration.CenerateCfgPath(parameters)
 * */
@Getter
@Setter
public class CFGGeneration implements Serializable{

    static class Edge implements Serializable{
        protected Integer edgeTo;
        protected Integer edgeNext;

        public Integer GetTo(){return edgeTo;}
        public Integer GetNext(){return edgeNext;}
        public Edge(int to,int next){
            edgeTo = to;edgeNext = next;
        }
    }

    private static Logger logger = Logger.getInstance();

    private static final long serialVersionUID = 1L;

    private transient Map<Stmt,Integer> Stmt2LineMap;

    private transient Map<Integer,Stmt> Line2StmtMap;

    private Map<Integer,String> Line2StmtStringMap;

    private Map<String,Integer> StmtString2LineMap;

    private ArrayList<ArrayList<Integer>> adjList;

    private ArrayList<ArrayList<Integer>> routeList;

    private ArrayList<Integer> headList;

    private ArrayList<Edge> edgeList;

    public transient Map<String,CFGGeneration> allFuncMethodMap;

    private String className;

    private String methodName;

    private SootMethod sootMethod;

    private boolean debugMode = false;

    private boolean pathAnalyse = false;

    private String csvSavePath = null;

    private DependencyUtil dependencyUtil;

    public Map<String,Map<Integer,Map<Integer,Integer>>> classMethodRouteLineMap = new HashMap<>();

    public CFGGeneration(boolean debugMode,boolean pathAnalyse){
        this.debugMode = debugMode;this.pathAnalyse = pathAnalyse;
        Stmt2LineMap = new HashMap<>(); Line2StmtMap = new HashMap<>();allFuncMethodMap = new HashMap<>();
        adjList = new ArrayList<>();routeList = new ArrayList<>();
        headList = new ArrayList<>();edgeList = new ArrayList<>();
    }

    public CFGGeneration(String csvSaveDir,boolean debugMode,boolean pathAnalyse){
        this(debugMode,pathAnalyse);this.csvSavePath = csvSaveDir;this.dependencyUtil = new DependencyUtil(csvSaveDir);
        try{
            if(!Files.exists(Path.of(csvSaveDir))) Files.createDirectory(Path.of(csvSaveDir));
        }catch (Exception ignored){}
    }

    public void Init(){
        Stmt2LineMap = new HashMap<>(); Line2StmtMap = new HashMap<>();allFuncMethodMap = new HashMap<>();
        adjList = new ArrayList<>();routeList = new ArrayList<>();
        headList = new ArrayList<>();edgeList = new ArrayList<>();
    }

    /** 使用前向星添加路径边 */
    public void AddEdge(Integer from,Integer to){
        try{
            Edge edge = new Edge(to, headList.get(from));edgeList.add(edge);
            headList.set(from,edgeList.size() - 1);
            adjList.get(from).add(to);
        }catch (Exception e){
            logger.logError("AddEdge fail:" + e.getMessage());
        }
    }

    /** 通过遍历图的所有有向边从而获取得到路径 */
    public void BuildPath(Integer node,ArrayList<Integer> path,ArrayList<Integer> nodeFlagList){
        if(Thread.currentThread().isInterrupted()) return;
        //System.out.println(node);
        path.add(node);

        if(headList.get(node) == -1){
            ArrayList<Integer> findPath = new ArrayList<>(path);
            routeList.add(findPath);path.remove(path.size() - 1);
            return;
        }

        for(Integer edgeTo = headList.get(node);edgeTo != -1;edgeTo = edgeList.get(edgeTo).GetNext()){
            if(nodeFlagList.get(edgeTo) == 0){
                nodeFlagList.set(edgeTo,1);BuildPath(edgeList.get(edgeTo).GetTo(),path,nodeFlagList);nodeFlagList.set(edgeTo,0);
            }
        }

        path.remove(path.size() - 1);
    }

    /** CFG的生成与路径获取
     * Parameters:
     * classPath:String 类所在文件夹
     * className:String 类名
     * functionName:String 函数名
     * returnType:String 返回值类型
     * parameters:List<String> 代表返回值类型*/
    public void CFG_generate(String classPath,String className,String functionName,String returnType,List<String> parameters) {
        Init();
        Path pathToBinary = Paths.get(classPath);
        AnalysisInputLocation inputLocation =
                PathBasedAnalysisInputLocation.create(pathToBinary, SourceType.Application);

        View view = new JavaView(inputLocation);
        ClassType classType = view.getIdentifierFactory().getClassType(className);

        MethodSignature methodSignature =
                view.getIdentifierFactory()
                        .getMethodSignature(
                                classType, functionName, returnType, parameters);

        if(!view.getClass(classType).isPresent()){
            logger.logError("Class not found!");return ;
        }
        SootClass sootClass = view.getClass(classType).get();
        view.getMethod(methodSignature);

        try {
            SootMethod sootMethod = sootClass.getMethod(methodSignature.getSubSignature()).get();
            StmtGraph<?> graph = sootMethod.getBody().getStmtGraph();
            String urlToWebeditor = DotExporter.createUrlToWebeditor(graph);
            System.out.println(urlToWebeditor);
            BuildSootMethodPath(sootMethod);
        }catch (Exception e){
            logger.logError("CFG build fail:" + e.getMessage());
        }
    }

    /** 路径输出 */
    public void PathOutPut(){
        System.out.println();
        int PathLine = 1;
        for(ArrayList<Integer> route:routeList){
            System.out.println("Path :" + PathLine ++);
            for(Integer pathNode:route){
                if(Line2StmtMap != null) System.out.println(pathNode + " : " + Line2StmtMap.get(pathNode));
                else System.out.println(pathNode + " : " + Line2StmtStringMap.get(pathNode));
            }
            System.out.println();
        }
    }

    /** 用于构造一个方法对应的Cfg以及CFG中所有可能的路径
     * Parameter:sootMethod:代表一个方法的sootMethod*/
    public List<Node> BuildSootMethodPath(SootMethod sootMethod){
        Init();
        try {
            StmtGraph<?> graph = sootMethod.getBody().getStmtGraph();

            ArrayList<Integer> nodeFlagList = new ArrayList<>();
            nodeFlagList.add(0);headList.add(-1);adjList.add(new ArrayList<>());
            Integer LineNum = 1;
            for (Stmt stmt : graph.getStmts()) {
                Stmt2LineMap.put(stmt, LineNum);
                Line2StmtMap.put(LineNum++, stmt);
                adjList.add(new ArrayList<>());headList.add(-1);nodeFlagList.add(0);
            }

            List<BasicBlock<?>> blocks;
            try {
                blocks = (List<BasicBlock<?>>) graph.getBlocksSorted();
            } catch (Exception e) {
                blocks = (List<BasicBlock<?>>) graph.getBlocks();
            }

            for (BasicBlock<?> block : blocks) {
                for (Stmt stmt : block.getStmts()) {
                    List<Stmt> StmtList = graph.successors(stmt);
                    for (Stmt stmt1 : StmtList) {
                        //System.out.println(Stmt2LineMap.get(stmt1) + ": " + stmt1);
                        AddEdge(Stmt2LineMap.get(stmt), Stmt2LineMap.get(stmt1));nodeFlagList.add(0);
                    }
                }
            }
            BuildPath(1,new ArrayList<>(),nodeFlagList);

            if(debugMode) {
                PathOutPut();
            }

            if (pathAnalyse) {
                PathAnalyzer pathAnalyzer = new PathAnalyzer();
                try {
                    List<Node> nodes = pathAnalyzer.analyse(routeList,Line2StmtMap,false,"Deprecated");
                    if(debugMode) {
                        System.out.println(nodes);
                    }
                    return nodes;
                }catch (Exception e){
                    System.out.println(e.getMessage());
                }
            }
        }catch (Exception e){
            logger.logError("CFG build fail:" + e.getMessage());
        }

        if(pathAnalyse) {
            return new ArrayList<>();
        }

        return null;
    }

    public void AllCfgGenerate(String classPath) {
        AllCfgGenerate(classPath, new HashSet<>(), new HashSet<>(), new HashSet<>());
    }

    /** 用于获取一个文件夹路径下的所有的方法的Cfg，并对cfg进行存储
     * patameters:classPath:需要获取全部cfg的文件夹根目录*/
    public void AllCfgGenerate(String classPath, Set<String> hasAnnotations, Set<String> implementInterfaces, Set<String> classNames) {
        Init();
        Path pathToBinary = Paths.get(classPath);
        AnalysisInputLocation inputLocation =
                PathBasedAnalysisInputLocation.create(pathToBinary, SourceType.Application);

        JavaView view = new JavaView(inputLocation);

        List<JavaSootClass> sootClassList = view.getClasses().toList();

        ArrayList<String> cfgMethodNameList = new ArrayList<>();ArrayList<CFGGeneration> cfgGenerationsList = new ArrayList<>();

        List<List<Node>> allBranchList = new ArrayList<>();
        for(JavaSootClass sootClass:sootClassList){

            // 根据注解过滤
            if (!ClassFilterUtil.hasAnnotation(sootClass, hasAnnotations)) {
                continue;
            }
            // 根据接口过滤类
            if (!ClassFilterUtil.implementInterfaces(sootClass, implementInterfaces)) {
                continue;
            }
            // 根据类名过滤类
            if (!ClassFilterUtil.isTargetClass(sootClass, classNames)) {
                continue;
            }

            Set<? extends SootMethod> sootMethodSet = sootClass.getMethods();
            logger.addOperation(sootMethodSet.size());
            for(SootMethod sootMethod: sootMethodSet){

                CFGGeneration cfgGeneration = new CFGGeneration(debugMode,pathAnalyse);
                cfgGeneration.className = sootClass.getName();cfgGeneration.methodName = sootMethod.getName();
                ExecutorService executor = Executors.newSingleThreadExecutor();
                Future<String> future = executor.submit(() -> {
                    try {
                        List<Node> nodes = cfgGeneration.BuildSootMethodPath(sootMethod);
                        if (nodes != null) allBranchList.add(nodes);
                        return "True";
                    } catch (Exception e) {
                        return "False";
                    }
                });

                try {
                    future.get(1, TimeUnit.SECONDS);
                    List<Type> parameterType = sootMethod.getParameterTypes();
                    List<String> parameterString = new ArrayList<>();
                    for(Type type:parameterType) parameterString.add(type.toString());

                    String sootMethodName = MethodEmbedding(sootClass.getName(),sootMethod.getName(),
                            sootMethod.getReturnType().toString(),parameterString);
                    allFuncMethodMap.put(sootMethodName,cfgGeneration);
                    //SavaCFGGeneration(sootMethodName,cfgGeneration);
                    cfgMethodNameList.add(sootMethodName);cfgGenerationsList.add(cfgGeneration);
                } catch (Exception e) {
                    logger.logError("任务超时，强制终止！" + "FuncName: " + sootMethod.getName());
                    executor.shutdown();
                    future.cancel(true);
                }  finally {
                    executor.shutdownNow();
                }
            }
        }

        lineCoverageMapProduce(cfgGenerationsList);
        lineCoverMapToCsvFile();
        AllCFGToCSV(cfgMethodNameList,cfgGenerationsList, allBranchList);
    }

    public void lineCoverageMapProduce(ArrayList<CFGGeneration> cfgGenerationArrayList){
        for(CFGGeneration cfgGeneration : cfgGenerationArrayList){
            String className = cfgGeneration.className,methodName = cfgGeneration.methodName;
            System.out.println(cfgGeneration.className + " " + cfgGeneration.methodName);
            Map<Integer,Map<Integer,Integer>> lineMap = new HashMap<>();

            int nowIndex = 1;
            for(ArrayList<Integer> routeIndexList : cfgGeneration.routeList){
                Map<Integer,Integer> findLineMap = new HashMap<>();
                for(Integer lineIndex: routeIndexList){
                    Stmt stmt = cfgGeneration.Line2StmtMap.get(lineIndex);
                    int firstLine = stmt.getPositionInfo().getStmtPosition().getFirstLine();
                    int lastLine = stmt.getPositionInfo().getStmtPosition().getLastLine();
                    for(int line = firstLine; line <= lastLine; line ++ ){
                        if(findLineMap.containsKey(line)) findLineMap.replace(line,findLineMap.get(line));
                        else findLineMap.put(line,1);
                    }
                }
                lineMap.put(nowIndex,findLineMap);nowIndex ++;
            }
            classMethodRouteLineMap.put(className + "+" + methodName,lineMap);
        }
    }

    public void lineCoverMapToCsvFile(){
        String saveDir = csvSavePath;
        String fileName = "MethodLineReport.csv";
        ArrayList<String> csvHeaders = getCoverCsvHeaderList();

        ArrayList<ArrayList<String>> csvRowList = new ArrayList<>();
        for(String methodName : classMethodRouteLineMap.keySet()){
            Map<Integer,Map<Integer,Integer>> lineCoverMap = classMethodRouteLineMap.get(methodName);
            for(Integer routeIndex: lineCoverMap.keySet()){
                ArrayList<String> rowList = new ArrayList<>();
                Map<Integer,Integer> routeMap = lineCoverMap.get(routeIndex);
                rowList.add(methodName);rowList.add(routeIndex.toString());rowList.add(String.valueOf(routeMap.size()));
                for(Integer index : routeMap.keySet()){
                    rowList.add(index.toString());rowList.add(routeMap.get(index).toString());
                }
                csvRowList.add(rowList);
            }
        }

        writeListToCsvFile(fileName,csvRowList,csvHeaders);
        if(saveDir != null) writeListToCsvFile(Paths.get(saveDir,fileName).toString(),csvRowList,csvHeaders);
    }

    private ArrayList<String> getCoverCsvHeaderList() {
        ArrayList<String> csvHeaders = new ArrayList<>();
        csvHeaders.add("methodName");
        csvHeaders.add("Path");
        csvHeaders.add("LineNumber");

        int maxLineSize = 0;
        for(Map<Integer,Map<Integer,Integer>> map : classMethodRouteLineMap.values()){
            for(Map<Integer,Integer> sonMap : map.values())
             maxLineSize = Math.max(maxLineSize,sonMap.size());
        }

        for (int index = 0; index < maxLineSize; index++) {
            csvHeaders.add("line_" + (index + 1));csvHeaders.add("shot_times");
        }
        return csvHeaders;
    }

    /**
     * 该方法用于将cfg路径存储至csv文件中
     * Parameters:
     * methodEmbeddingList:存储cfgGeneration的序列化文件名称
     * cfgList:需要被存储的cfgGeneration的列表
     */
    public void AllCFGToCSV(ArrayList<String> methodEmbeddingList, ArrayList<CFGGeneration> cfgList, List<List<Node>> allBranchList) {
        if (methodEmbeddingList.size() != cfgList.size()) return;

        String csvFilePath = "AllCFGPath.csv";
        ArrayList<String> csvHeaders = new ArrayList<>();
        csvHeaders.add("MethodName");
        csvHeaders.add("Path");
        csvHeaders.add("PathContent");
        csvHeaders.add("Dependency");

        int maxBranchSize = allBranchList.stream()
                .mapToInt(List::size)
                .max()
                .orElse(1);

        for (int i = 0; i < maxBranchSize; i++) {
            csvHeaders.add("Branch_" + (i + 1));
        }

        ArrayList<ArrayList<String>> csvRowList = new ArrayList<>();

        for (int cfgIndex = 0; cfgIndex < cfgList.size(); cfgIndex++) {
            String cfgIndexMethodEmbedding = methodEmbeddingList.get(cfgIndex);
            List<Node> localBranchList = allBranchList.get(cfgIndex);
            CFGGeneration cfgIndexCfgGeneration = cfgList.get(cfgIndex);
            if (cfgIndexCfgGeneration.routeList.size() > 5000) continue;

            for (int pathIndex = 0; pathIndex < cfgIndexCfgGeneration.routeList.size(); pathIndex++) {
                ArrayList<String> rowList = new ArrayList<>();
                rowList.add(cfgIndexMethodEmbedding);
                rowList.add(String.valueOf(pathIndex + 1));

                ArrayList<Integer> route = cfgIndexCfgGeneration.routeList.get(pathIndex);
                StringBuilder pathString = new StringBuilder();
                for (Integer pathNode : route) {
                    if (cfgIndexCfgGeneration.Line2StmtMap != null) {
                        pathString.append("### ").append(pathNode).append(" : ")
                                .append(cfgIndexCfgGeneration.Line2StmtMap.get(pathNode));
                    } else {
                        pathString.append("### ").append(pathNode).append(" : ")
                                .append(cfgIndexCfgGeneration.Line2StmtStringMap.get(pathNode));
                    }
                }
                rowList.add(String.valueOf(pathString));
                CFGWithDependency cfgWithDependency= new CFGWithDependency(cfgIndexCfgGeneration.getStmt2LineMap(), cfgIndexCfgGeneration.getLine2StmtMap(), cfgIndexCfgGeneration.getRouteList());
                cfgWithDependency.analyse();
                rowList.add(cfgWithDependency.getDepInf(pathIndex));
                //

                for (int i = 0; i < maxBranchSize; i++) {
                    if (i < localBranchList.size()) {
                        rowList.add(localBranchList.get(i).toString());
                    } else {
                        rowList.add("NAN");
                    }
                }

                csvRowList.add(rowList);
            }
        }
        writeListToCsvFile(csvFilePath,csvRowList,csvHeaders);
        if(this.csvSavePath != null) writeListToCsvFile(Paths.get(csvSavePath,csvFilePath).toString(),csvRowList,csvHeaders);
    }

    public static void writeListToCsvFile(String savePath,ArrayList<ArrayList<String>> rowList,ArrayList<String> csvHeader){
        try (CSVWriter writer = new CSVWriter(new FileWriter(savePath))) {
            writer.writeNext(csvHeader.toArray(new String[0]));
            for(ArrayList<String> row:rowList){
                writer.writeNext(row.toArray(new String[0]));
            }
        } catch (IOException e) {
            logger.logWarning("CSV Save Fail:" + e.getMessage());
        }
    }

    /**
     * 该方法用于获取所有路径上的变量所对应的依赖
     * @param cfgGeneration 完成cfgGeneration路径分析的cfgGeneration 实例
     * 新增方法！！
     * 该方法的使用依赖于DependencyGeneration的完成：
     * 前置条件：成功执行DependencyGeneration的FetchALLDependency()方法
     *                      并成功生成AllDependency.csv DeepDependency.csv文件
     * 后置条件：成功生成RouteDeepDependency.csv:记录变量名与路径、类之间的对应关系的csv文件
     *         成功生成ClassDeepDependency.csv:记录类名与三层依赖之间的对应关系的csv文件
     */
    public Map<String, List<String>> CfgToRouteClassDependency(CFGGeneration cfgGeneration){

        System.out.println("CFG ROUTE DEPENDENCY FETCH START!!");
        Map<String,String> dependencyMap = new HashMap<>();
        Map<String,Map<String,String>> classFieldUseMap = new HashMap<>();
        Map<String,Map<Integer,Set<String>>> routeFiledAndFuntionMap = new HashMap<>();
        Map<String,Map<Integer,String>> cfgCodeSourceUseMap = new HashMap<>();
        String saveFileDir = cfgGeneration.csvSavePath;
        Map<String, List<String>> classDependencyMap = new ConcurrentHashMap<>();

        for(String cfgName:cfgGeneration.getAllFuncMethodMap().keySet()){
            System.out.println("start deal the Method: " + cfgName);
            CFGGeneration nowCfgGeneration = cfgGeneration.getAllFuncMethodMap().get(cfgName);
            ArrayList<ArrayList<Integer>> routeList = nowCfgGeneration.routeList;
            if(routeList.size() > 200) continue;

            Map<String,String> fieldAndFunctionNameToClassMap = new HashMap<>();
            Map<Integer,Set<String>> routeFiledAndFunctionNameUseMap = new HashMap<>();

            Map<Integer,String> routeSourceCodeUseMap = new HashMap<>();
            int routeNum = 1;
            for(ArrayList<Integer> route:routeList){

                Set<String> routeFiledAndFunctionNameSet = new HashSet<>();
                Set<String> classFunctionUse = new HashSet<>();

                for(Integer routeIndex:route){
                    Stmt nowStmt = nowCfgGeneration.Line2StmtMap.get(routeIndex);

                    if (nowStmt.isInvokableStmt()) {
                        InvokableStmt invokableStmt = nowStmt.asInvokableStmt();
                        if (invokableStmt.containsInvokeExpr()) {
                            Optional<AbstractInvokeExpr> funcCallStmt = invokableStmt.getInvokeExpr();
                            if (funcCallStmt.isPresent()) {
                                AbstractInvokeExpr abstractInvokeExpr = funcCallStmt.get();
                                fieldAndFunctionNameToClassMap.put(abstractInvokeExpr.getMethodSignature().getName(),abstractInvokeExpr.getMethodSignature().getDeclClassType().toString());
                                routeFiledAndFunctionNameSet.add(abstractInvokeExpr.getMethodSignature().getName());

                                if(!dependencyMap.containsKey(abstractInvokeExpr.getMethodSignature().getDeclClassType().getFullyQualifiedName())){
                                    String dependencyString = dependencyUtil.getClassDefDeepDependency(saveFileDir,"DeepClassDependency.csv",abstractInvokeExpr.getMethodSignature().getDeclClassType().getFullyQualifiedName(),"");
                                    dependencyMap.put(abstractInvokeExpr.getMethodSignature().getDeclClassType().toString(),dependencyString);
                                }

                                String className = abstractInvokeExpr.getMethodSignature().getDeclClassType().getFullyQualifiedName();
                                // System.out.println(className + "   " + cfgName);
                                if(cfgName.contains(className.replace('<', '_').replace('[', '+').replace(']', '+').replace('>', '_').replace(", ", "+"))){
                                    classFunctionUse.add(functionStmtToCodeString(abstractInvokeExpr));
                                }
                            }
                        }
                    }

                    for(Value value:nowStmt.getUsesAndDefs().toList()){
                        if(!value.getType().toString().equals("unknown")){
                            for(Value valueName: value.getUses().toList()){
                                String name = valueName.toString();
                                if(name.matches("^[a-zA-Z].*") && !name.equals("this")) {
                                    fieldAndFunctionNameToClassMap.put(name,valueName.getType().toString());
                                    routeFiledAndFunctionNameSet.add(name);
                                }
                            }
                            if(!dependencyMap.containsKey(value.getType().toString())){
                                String dependencyString = dependencyUtil.getClassDefDeepDependency(saveFileDir,"DeepClassDependency.csv",value.getType().toString(),"");
                                dependencyMap.put(value.getType().toString(),dependencyString);
                            }
                        }
                    }
                }

                StringBuilder cfgLineCodeString = new StringBuilder();
                for(String codeString:classFunctionUse) cfgLineCodeString.append(codeString);
                routeSourceCodeUseMap.put(routeNum,cfgLineCodeString.toString());

                routeFiledAndFunctionNameUseMap.put(routeNum,routeFiledAndFunctionNameSet);
                routeNum ++;
            }
            classFieldUseMap.put(cfgName,fieldAndFunctionNameToClassMap);
            routeFiledAndFuntionMap.put(cfgName,routeFiledAndFunctionNameUseMap);
            cfgCodeSourceUseMap.put(cfgName,routeSourceCodeUseMap);
        }


        String classDependencySaveFilePath = "RouteDeepDependency.csv";
        ArrayList<String> classDependencyCsvHeader = new ArrayList<>();
        classDependencyCsvHeader.add("MethodEmbeddingName");classDependencyCsvHeader.add("RouteIndex");
        classDependencyCsvHeader.add("VariableOrFunctionName");classDependencyCsvHeader.add("DeepDependencyClass");
        ArrayList<ArrayList<String>> dependencyRowList = new ArrayList<>();

        for(String cfgName:cfgGeneration.getAllFuncMethodMap().keySet()){
            Map<String,String> filedToClassMap = classFieldUseMap.get(cfgName);
            Map<Integer,Set<String>> routeFiledUseMap = routeFiledAndFuntionMap.get(cfgName);
            if(routeFiledUseMap == null || routeFiledUseMap.isEmpty()) continue;

            for(Integer routeIndex:routeFiledUseMap.keySet()){
                Set<String> varialbleOrFunctionSet = routeFiledUseMap.get(routeIndex);

                for(String variableOrFunctionName:varialbleOrFunctionSet){
                    ArrayList<String> rowList = new ArrayList<>();
                    rowList.add(cfgName);
                    rowList.add(routeIndex.toString());
                    rowList.add(variableOrFunctionName);
                    rowList.add(filedToClassMap.get(variableOrFunctionName));
                    dependencyRowList.add(rowList);
                }
            }
        }

        writeListToCsvFile(classDependencySaveFilePath,dependencyRowList,classDependencyCsvHeader);
        if(saveFileDir != null)
            writeListToCsvFile(Paths.get(saveFileDir,classDependencySaveFilePath).toString(),dependencyRowList,classDependencyCsvHeader);


        String dependencyUsePathPath = "ClassDeepDependency.csv";
        ArrayList<String> dependencyUseCsvHeader = new ArrayList<>();
        dependencyUseCsvHeader.add("className");dependencyUseCsvHeader.add("classDependency");
        ArrayList<ArrayList<String>> classUseRowList = new ArrayList<>();

        for(String className:dependencyMap.keySet()){
            String classDependencyString = dependencyMap.get(className);
            ArrayList<String> rowList = new ArrayList<>();
            rowList.add(className);rowList.add(classDependencyString);
            classUseRowList.add(rowList);
        }

        writeListToCsvFile(dependencyUsePathPath,classUseRowList,dependencyUseCsvHeader);
        if(saveFileDir != null)
            writeListToCsvFile(Paths.get(saveFileDir,dependencyUsePathPath).toString(),classUseRowList,dependencyUseCsvHeader);

        String codeSourceUsePath = "RouteCodeDependency.csv";
        ArrayList<String> codeSourceUseCsvHeader = new ArrayList<>();
        codeSourceUseCsvHeader.add("methodEmbedding");codeSourceUseCsvHeader.add("route");codeSourceUseCsvHeader.add("codeUse");
        ArrayList<ArrayList<String>> codeRowList = new ArrayList<>();
        for(String className:cfgCodeSourceUseMap.keySet()){
            Map<Integer,String> routeToCodeSourcMap = cfgCodeSourceUseMap.get(className);
            for(Integer routeIndex:routeToCodeSourcMap.keySet()){
                String codeSourceUse = routeToCodeSourcMap.get(routeIndex);
                ArrayList<String> row = new ArrayList<>();
                row.add(className);row.add(routeIndex.toString());row.add(codeSourceUse);
                codeRowList.add(row);
                classDependencyMap.put(row.get(0) + "%%" + row.get(1), row);
            }
        }

        writeListToCsvFile(codeSourceUsePath,codeRowList,codeSourceUseCsvHeader);
        if(saveFileDir != null) {
            writeListToCsvFile(Paths.get(saveFileDir,codeSourceUsePath).toString(),codeRowList,codeSourceUseCsvHeader);
        }
        return classDependencyMap;
    }

    private String functionStmtToCodeString(AbstractInvokeExpr abstractInvokeExpr){
        String className = abstractInvokeExpr.getMethodSignature().getDeclClassType().getFullyQualifiedName();
        String functionName = abstractInvokeExpr.getMethodSignature().getName();
        String returnType = abstractInvokeExpr.getMethodSignature().getType().toString();
        String saveFileDir = csvSavePath;
        List<Type> paramTypeList = abstractInvokeExpr.getMethodSignature().getParameterTypes();

        List<String> paramList = new ArrayList<>();for(Type type:paramTypeList) paramList.add(type.toString());
        String functionEmbedding = MethodEmbedding(className,functionName,returnType,paramList);
        System.out.println(functionEmbedding);
        Map<String,String[]> codeSourceMap = dependencyUtil.getFunctionCodeMap(saveFileDir);
        for(String codeIndex:codeSourceMap.keySet()){
            if(codeIndex.contains(functionEmbedding)) return codeSourceMap.get(codeIndex)[1];
        }
        return "";
    }

    /** 用于获取得到类名，方法名以及方法返回值对应的唯一的函数的标识*/
    public static String MethodEmbedding(String className,String functionName,String returnType,List<String> paramTypes){
        return "_CLASSNAME_" + className.replace('<', '_').replace('[', '+').replace(']', '+').replace('>', '_').replace(", ", "+")
                + "_FUNCTIONNAME_" + functionName.replace('<', '_').replace('>', '_').replace('[', '+').replace(']', '+').replace(", ", "+")
                + "_RETURNTYPE_" + returnType.replace('<', '_').replace('>', '_').replace('[', '+').replace(']', '+').replace(", ", "+")
                + "_Parameters_" + paramTypes.toString().replace('<', '_').replace('>', '_').replace('[', '+').replace(']', '+').replace(", ", "+");
    }

    /** 用于获取得到指定的函数的cfg
     * Patameters:
     * className:String 代表类名
     * functionName:String 代表函数名
     * returnType:String 代表返回类型*/
    public CFGGeneration GetMethodCFGGeneration(String className,String functionName,String returnType,List<String> parametersList){
        return allFuncMethodMap.getOrDefault(MethodEmbedding(className, functionName, returnType,parametersList), null);
    }

    /** 用于将一个CFG序列化保存至本地文件
     * Parameters:
     * methodEmbedding:String 代表对应的路径
     * cfgGeneration:CFGGeneration 代表需要保存的cfg*/
    public static void SavaCFGGeneration(String methodEmbedding,CFGGeneration cfgGeneration) {
        final long MAX_FILE_SIZE = 10 * 1024 * 1024;
        if(methodEmbedding.length() >= 255){
            System.out.println("Could Not Save Cfg for fileName length Limit ");
            return;
        }
        cfgGeneration.StmtString2LineMap = new HashMap<>();cfgGeneration.Line2StmtStringMap = new HashMap<>();
        for(Stmt stmt:cfgGeneration.Stmt2LineMap.keySet()) cfgGeneration.StmtString2LineMap.put(stmt.toString(),cfgGeneration.Stmt2LineMap.get(stmt));
        for(Integer line:cfgGeneration.Line2StmtMap.keySet()) cfgGeneration.Line2StmtStringMap.put(line,cfgGeneration.Line2StmtMap.get(line).toString());
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream();
             ObjectOutputStream oos = new ObjectOutputStream(baos)) {
            // 先序列化到内存中
            oos.writeObject(cfgGeneration);
            oos.flush();

            // 获取字节长度
            byte[] serializedData = baos.toByteArray();
            if (serializedData.length > MAX_FILE_SIZE) {
                System.out.println("WriteObjectFail: 文件过大，放弃写入 (" + serializedData.length / 1024 + " KB)");
                return; // 或抛出异常、记录日志等
            }
            // 如果不大于限制，则写入磁盘
            try (FileOutputStream fos =  new FileOutputStream("CFGData/CFGResource" + methodEmbedding)) {
                fos.write(serializedData); // 写入实际文件
            }
        } catch (IOException e) {
            logger.logWarning("WriteObjectFail:" + e.getMessage());
        }
    }


    /** 用于从本地文件中读取得到cfg
     * Parameters:
     * methodEmbedding:String 代表对应的路径*/
    public static CFGGeneration ReadCFGFromFile(String methodEmbedding) {
        try (FileInputStream fis = new FileInputStream("CFGData" + methodEmbedding);
             ObjectInputStream ois = new ObjectInputStream(fis)) {
            return (CFGGeneration) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("GetObjectFail!!");
            return null;
        }
    }

    /** CFG的生成与路径获取
     * Parameters:
     * classPath:String 类所在文件夹
     * className:String 类名
     * functionName:String 函数名
     * returnType:String 返回值类型
     * parameters:List<String> 代表返回值类型
     * Return: CFGGeneration 的类实例*/
    public CFGGeneration GenerateCFGPath(String classPath,String className,String functionName,String returnType,List<String> parameters){
        CFG_generate(classPath,className,functionName,returnType,parameters);
        return this;
    }
}