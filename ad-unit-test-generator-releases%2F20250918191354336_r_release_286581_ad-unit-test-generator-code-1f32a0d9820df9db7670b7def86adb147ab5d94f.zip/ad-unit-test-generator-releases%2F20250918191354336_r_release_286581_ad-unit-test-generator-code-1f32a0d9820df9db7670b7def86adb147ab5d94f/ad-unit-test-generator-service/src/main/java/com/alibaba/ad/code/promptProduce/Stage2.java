//package com.alibaba.promptProduce;
//
//import com.alibaba.cfganalyser.code.DependencyUtil;
//import com.opencsv.CSVReader;
//import com.opencsv.exceptions.CsvValidationException;
//import org.json.JSONObject;
//import java.io.*;
//import java.nio.charset.StandardCharsets;
//import java.nio.file.Files;
//import java.nio.file.Paths;
//import java.util.LinkedHashMap;
//import java.util.List;
//import java.util.Map;
//
//public class stage2 {
//    public int path;
//    public String Role() {
//        String role = "# 角色：\n" +
//                "你是一个java单元测试类生成器。\n" +
//                "\n" +
//                "# 任务：\n" +
//                "我想请你帮忙给一个某个方法编写单元测试代码，现在我有以下信息：\n" +
//                "1. 该java方法的源代码，以及本次测试的测试意图和需要覆盖的路径；\n" +
//                "2. 我会指导你如何构造输入数据以及如何给出验证点；\n" +
//                "3. 我会给出该方法的相关依赖信息，确保你可以生成无编译错误、可运行的测试程序；"+
//                "\n" +
//                "你根据以下信息进行分析，生成单元测试类。\n" +
//                "\n";
//        return role;
//    }
//    public String method_java() {
//        StringBuilder result = new StringBuilder();
//        String method = "public boolean isBeforeLastStageAndOpen(CampaignViewDTO campaignViewDTO) {\n" +
//                "        ActivityOptimizeTransStageViewDTO stageViewDTO = campaignViewDTO.getActivityOptimizeTransStageViewDTO();\n" +
//                "        if (stageViewDTO != null && stageViewDTO.checkOpen()) {\n" +
//                "            List<ActivityOptimizeTransStageViewDTO.Stage> stages = campaignViewDTO.getActivityOptimizeTransStageViewDTO().getStages();\n" +
//                "            if (CollectionUtils.size(stages) < 2) {\n" +
//                "                log.warn(\"计划优化目标流转阶段不足2个\");\n" +
//                "                return false;\n" +
//                "            } else {\n" +
//                "                ActivityOptimizeTransStageViewDTO.Stage lastStages = (ActivityOptimizeTransStageViewDTO.Stage)stages.get(stages.size() - 1);\n" +
//                "                LocalDateTime startTime = LocalDateTime.parse(lastStages.getStartTime(), Constants.DATE_TIME_FORMATTER_1);\n" +
//                "                return LocalDateTime.now().isBefore(startTime);\n" +
//                "            }\n" +
//                "        } else {\n" +
//                "            return false;\n" +
//                "        }\n" +
//                "    }\n";
//        result.append(
//                "待测方法:\n" +
//                        method + "\n");
//        return result.toString();
//    }
//    public String stage1_output(String filePath) {
//        StringBuilder result = new StringBuilder();
//        String[] orderedKeys = {
//                "java method",
//                "test intention",
//                "path analysis",
//                "input data construction",
//                "verification points"
//        };
//
//        try {
//            String jsonContent = new String(Files.readAllBytes(Paths.get(filePath)));
//            JSONObject jsonObject = new JSONObject(jsonContent);
//            // 按预定义顺序输出
//            for (String key : orderedKeys) {
//                if (jsonObject.has(key)) {
//                    result.append("# ").append(key).append(": \n")
//                            .append(jsonObject.get(key))
//                            .append("\n");
//                }
//            }
//        } catch (IOException e) {
//            e.printStackTrace();
//            return "Error reading JSON file: " + e.getMessage();
//        } catch (Exception e) {
//            e.printStackTrace();
//            return "Error parsing JSON: " + e.getMessage();
//        }
//
//        return result.toString();
//    }
//    public String COT() {
//        StringBuilder result = new StringBuilder();
//        result.append("\n# 工作步骤：\n" +
//                "1. 理解该java方法，以及本次的测试目的、测试路径；\n" +
//                "2. 理解分析本次测试的“输入数据构造”和“验证点”\n" +
//                "3. 理解分析java方法涉及到的依赖信息\n" +
//                "4. 为该java方法生成完整的测试程序，并加入注释信息来说明测试意图\n"
//        );
//        return result.toString();
//    }
//    public String constraint() throws IOException {
//        StringBuilder result = new StringBuilder();
//        String targetContent = new String(Files.readAllBytes(Paths.get("./src/main/java/com/alibaba/config/target.json")));
//        JSONObject targetJson = new JSONObject(targetContent);
//        String test_out_path = targetJson.getString("test_out_path");
//        result.append(
//                "# 生成单元测试的要求: \n" +
//                        "* 使用java8，并使用Junit4,Mockito,PowerMockito框架进行单元测试代码编写,不要使用hamcrest框架\n" +
//                        "* 完整import代码中使用到的相关类,不要忘记import待测方法所在的类，import路径需要参考其对应在上下文java类信息中的实际`package`定义,保证可以被正确编译\n" +
//                        "* 代码中创建对象默认优先使用无参构造函数,再通过`setter`方法进行属性赋值；如果对应的class使用了`@Builder`或`@SuperBuilder`注释，才使用`.builder()...build()`模式进行对象的创建\n" +
//                        "* 如果一个被mock的方法没有返回值，或者返回`Void`类型，则使用`Mockito.doNothing().when(...)`的方式进行mock\n" +
//                        "* 只能使用目标类中已存在的方法和属性，不要臆测或假设存在其他方法\n" +
//                        "* 如果需要mock对象的某个方法返回值，必须先确认该方法在原代码中被调用\n" +
//                        "* 可以参考原始代码中的方法调用来确定应该mock哪些方法，比如if语句中的方法调用等\n" +
//                        "* 分析java类逻辑，对执行路径，调用方法和对象属性进行Assert检查\n" +
//                        "* 除了代码和测试意图注释信息之外，不需要任何解释或说明,不得添加额外内容\n"+
//                        "* 如果你要创建“AdgroupRealTimeOptimizeAlgoCrowdSaveAbilityParam abilityParam”类似的这种对象，请参考如下构造方式:\n"+
//                        "private AdgroupRealTimeOptimizeAlgoCrowdSaveAbilityParam abilityParam;\n"+
//                        "...\n"+
//                        "abilityParam = AdgroupRealTimeOptimizeAlgoCrowdSaveAbilityParam.builder()\n" +
//                        "                .abilityTarget(adgroupViewDTO)\n" +
//                        "                .dbCampaignCrowdMap(dbCampaignCrowdMap)\n" +
//                        "                .optimizeCrowdViewDTOList(optimizeCrowdViewDTOList)\n" +
//                        "                .build();\n"+
//                        "千万不要使用以下方式：\n"+
//                        "        abilityParam = new AdgroupInitForUpdateNReachAdgroupAbilityParam();\n" +
//                        "        abilityParam.setAbilityTarget(adgroupViewDTO);\n" +
//                        "        abilityParam.setCampaignViewDTO(campaignViewDTO);\n"+
//                        "因为这些参数对象类（通常以param结尾的类）都被`@SuperBuilder`注释，要使用`.builder()...build()`模式进行对象的创建\n"+
//                        "* 注意，对于一些通用类（如List）的导入不要忘记\n"+
//                        "* 注意，我希望你命名测试类的方式是\"待测类名_待测方法_本次路径编号（pathid="+this.path+")_Test\"\n"+
//                        "* 注意，我最终会将生成的代码保存到"+convertPathToPackageName(test_out_path)+"文件夹,请你据此给测试代码添加相应的\"package "+convertPathToPackageName(test_out_path)+"\"信息\n"+
//                        "* 注意，请你将最终生成的代码放入\"```java ```\"中"
//        );
//        return result.toString();
//    }
//    public static boolean isFileExist(String filePath) {
//        File file = new File(filePath);
//        return file.exists() && file.isFile();
//    }
//    public static String convertPathToPackageName(String path) {
//        // 1. 首先找到 "java/" 的位置
//        int javaIndex = path.indexOf("java/");
//        if (javaIndex == -1) {
//            return ""; // 如果没有找到 "java/"，返回空字符串或者可以抛出异常
//        }
//
//        // 2. 获取 "java/" 之后的字符串
//        String packagePath = path.substring(javaIndex + "java/".length());
//
//        // 3. 将路径分隔符替换为点号
//        String packageName = packagePath.replace('/', '.');
//
//        // 4. 处理Windows系统的路径分隔符（如果有的话）
//        packageName = packageName.replace('\\', '.');
//
//        // 5. 移除末尾的 .java（如果有的话）
//        if (packageName.endsWith(".java")) {
//            packageName = packageName.substring(0, packageName.length() - ".java".length());
//        }
//        if(packageName.endsWith(".")){
//            packageName = packageName.substring(0, packageName.length() - ".".length());
//        }
//
//        return packageName;
//    }
//    public String Example() {
//        StringBuilder result = new StringBuilder();
//        result.append("\n#输出结构示例:\n" +
//                "import com.alibaba.abf.governance.context.ServiceContext;\n" +
//                "import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;\n" +
//                "import com.alibaba.ad.brand.dto.campaign.adzone.CampaignAdzoneViewDTO;\n" +
//                "import com.alibaba.ad.brand.dto.campaign.audience.CampaignTargetScenarioViewDTO;\n" +
//                "import com.alibaba.ad.brand.dto.campaign.audience.CampaignTargetViewDTO;\n" +
//                "import com.alibaba.ad.brand.dto.campaign.ext.CampaignExtViewDTO;\n" +
//                "import com.alibaba.ad.brand.dto.campaign.guarantee.CampaignGuaranteeViewDTO;\n" +
//                "import com.alibaba.ad.brand.dto.campaign.resource.CampaignResourceViewDTO;\n" +
//                "import com.alibaba.ad.brand.dto.campaign.sale.CampaignSaleViewDTO;\n" +
//                "import com.alibaba.ad.brand.dto.monitor.ThirdMonitorUrlViewDTO;\n" +
//                "import com.google.common.collect.Lists;\n" +
//                "import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignUpdateAbilityParam;\n" +
//                "import lombok.extern.slf4j.Slf4j;\n" +
//                "import org.junit.Before;\n" +
//                "import org.junit.Test;\n" +
//                "import org.junit.runner.RunWith;\n" +
//                "import org.mockito.InjectMocks;\n" +
//                "import org.mockito.Mock;\n" +
//                "import org.powermock.modules.junit4.PowerMockRunner;\n" +
//                "\n" +
//                "import java.util.ArrayList;\n" +
//                "import java.util.Date;\n" +
//                "import java.util.List;\n" +
//                "\n" +
//                "import static org.junit.Assert.assertTrue;\n" +
//                "/**\n" +
//                " * 测试意图：...\n" +
//                " */"+
//                "\n" +
//                "@Slf4j\n" +
//                "@RunWith(PowerMockRunner.class)\n" +
//                "public class BrandCampaignUpdateJudgeForUpdateCampaignAbilityAutoTests {\n" +
//                "\n" +
//                "    @InjectMocks\n" +
//                "    private BrandCampaignUpdateJudgeForUpdateCampaignAbility ability;\n" +
//                "\n" +
//                "    @Mock\n" +
//                "    private ServiceContext serviceContext;\n" +
//                "\n" +
//                "    private CampaignViewDTO campaignViewDTO;\n" +
//                "    private CampaignViewDTO dbCampaignViewDTO;\n" +
//                "\n" +
//                "    @Before\n" +
//                "    public void setUp() {\n" +
//                "        campaignViewDTO = new CampaignViewDTO();\n" +
//                "        dbCampaignViewDTO = new CampaignViewDTO();\n" +
//                "    }\n" +
//                "\n" +
//                "    /**\n" +
//                "     * Test case: 【全域通】编辑计划-添加2组第三方监测\n" +
//                "     */\n" +
//                "    @Test\n" +
//                "    public void testUpdateCampaignWithThirdMonitor() {\n" +
//                "        log.info(\"Testing update campaign with third monitor settings\");\n" +
//                "\n" +
//                "        // Setup campaign base info\n" +
//                "        campaignViewDTO.setId(73286422668L);\n" +
//                "        campaignViewDTO.setCampaignGroupId(43287016L);\n" +
//                "        campaignViewDTO.setStartTime(new Date(1734624000000L));\n" +
//                "        campaignViewDTO.setEndTime(new Date(1734710399000L));\n" +
//                "        campaignViewDTO.setTitle(\"超级全域通_自动化测试_第三方监测20241219143455_update\");\n" +
//                "        campaignViewDTO.setStatus(0);\n" +
//                "\n" +
//                "        // Setup campaign ext info with third monitor settings\n" +
//                "        CampaignExtViewDTO extViewDTO = new CampaignExtViewDTO();\n" +
//                "\n" +
//                "        // Setup third monitor URLs\n" +
//                "        List<ThirdMonitorUrlViewDTO> monitorUrls = new ArrayList<>();\n" +
//                "        ThirdMonitorUrlViewDTO monitor1 = new ThirdMonitorUrlViewDTO();\n" +
//                "        monitor1.setClkMonitorUrl(\"https://cn.miaozhen.com/clk\");\n" +
//                "        monitor1.setPvMonitorUrl(\"https://cn.miaozhen.com/imp\");\n" +
//                "        monitor1.setDeviceType(5);\n" +
//                "        \n" +
//                "        ThirdMonitorUrlViewDTO monitor2 = new ThirdMonitorUrlViewDTO();\n" +
//                "        monitor2.setClkMonitorUrl(\"https://cn.miaozhen.com/clk2\");\n" +
//                "        monitor2.setPvMonitorUrl(\"https://cn.miaozhen.com/imp2\");\n" +
//                "        monitor2.setDeviceType(5);\n" +
//                "        \n" +
//                "        monitorUrls.add(monitor1);\n" +
//                "        monitorUrls.add(monitor2);\n" +
//                "        campaignViewDTO.setCampaignExtViewDTO(extViewDTO);\n" +
//                "\n" +
//                "        // Setup campaign sale info\n" +
//                "        CampaignSaleViewDTO saleViewDTO = new CampaignSaleViewDTO();\n" +
//                "        saleViewDTO.setResourcePackageProductId(6132397L);\n" +
//                "        saleViewDTO.setSaleGroupId(3030479L);\n" +
//                "        saleViewDTO.setSaleProductLine(5);\n" +
//                "        campaignViewDTO.setCampaignSaleViewDTO(saleViewDTO);\n" +
//                "\n" +
//                "        // Setup guarantee info\n" +
//                "        CampaignGuaranteeViewDTO guaranteeViewDTO = new CampaignGuaranteeViewDTO();\n" +
//                "        campaignViewDTO.setCampaignGuaranteeViewDTO(guaranteeViewDTO);\n" +
//                "\n" +
//                "        // Setup ssp resource info\n" +
//                "        CampaignResourceViewDTO sspResourceViewDTO = new CampaignResourceViewDTO();\n" +
//                "        sspResourceViewDTO.setSspProductId(35326L);\n" +
//                "        campaignViewDTO.setCampaignResourceViewDTO(sspResourceViewDTO);\n" +
//                "\n" +
//                "        // Setup target list\n" +
//                "        campaignViewDTO.setCampaignTargetScenarioViewDTO(new CampaignTargetScenarioViewDTO());\n" +
//                "        campaignViewDTO.getCampaignTargetScenarioViewDTO().setCampaignTargetViewDTOList(Lists.newArrayList());\n" +
//                "\n" +
//                "        // Setup DB campaign view\n" +
//                "        dbCampaignViewDTO.setId(73286422668L);\n" +
//                "        dbCampaignViewDTO.setCampaignGroupId(43287016L);\n" +
//                "        dbCampaignViewDTO.setStartTime(new Date(1734624000000L));\n" +
//                "        dbCampaignViewDTO.setEndTime(new Date(1734710399000L));\n" +
//                "        dbCampaignViewDTO.setTitle(\"超级全域通_自动化测试_第三方监测20241219143455\");\n" +
//                "        dbCampaignViewDTO.setCampaignLevel(1);\n" +
//                "        dbCampaignViewDTO.setCampaignModel(6007);\n" +
//                "        dbCampaignViewDTO.setCampaignType(101);\n" +
//                "        dbCampaignViewDTO.setMainCampaignGroupId(43348526L);\n" +
//                "        dbCampaignViewDTO.setMemberId(4279076301L);\n" +
//                "        dbCampaignViewDTO.setOnlineStatus(1);\n" +
//                "        dbCampaignViewDTO.setProductLineId(136001);\n" +
//                "        dbCampaignViewDTO.setSceneId(374);\n" +
//                "        dbCampaignViewDTO.setSspProgrammatic(1);\n" +
//                "        dbCampaignViewDTO.setStatus(0);\n" +
//                "\n" +
//                "        // Setup DB campaign ext info\n" +
//                "        CampaignExtViewDTO dbExtViewDTO = new CampaignExtViewDTO();\n" +
//                "        List<ThirdMonitorUrlViewDTO> dbMonitorUrls = new ArrayList<>();\n" +
//                "        dbMonitorUrls.add(monitor1);\n" +
//                "        dbCampaignViewDTO.setCampaignExtViewDTO(dbExtViewDTO);\n" +
//                "\n" +
//                "        // Setup DB sub campaign\n" +
//                "        CampaignViewDTO subCampaign = new CampaignViewDTO();\n" +
//                "\n" +
//                "        subCampaign.setId(73286422669L);\n" +
//                "        subCampaign.setCampaignGroupId(43287016L);\n" +
//                "        subCampaign.setParentCampaignId(73286422668L);\n" +
//                "        subCampaign.setStartTime(new Date(1734624000000L));\n" +
//                "        subCampaign.setEndTime(new Date(1734710399000L));\n" +
//                "        subCampaign.setTitle(\"超级全域通测试-联调使用跨域_测试媒体_1220_1220_428149\");\n" +
//                "        subCampaign.setCampaignLevel(2);\n" +
//                "        subCampaign.setCampaignModel(6005);\n" +
//                "        subCampaign.setCampaignType(101);\n" +
//                "        subCampaign.setMainCampaignGroupId(43348526L);\n" +
//                "        subCampaign.setMemberId(4279076301L);\n" +
//                "        subCampaign.setOnlineStatus(1);\n" +
//                "        subCampaign.setProductLineId(136001);\n" +
//                "        subCampaign.setSceneId(374);\n" +
//                "        subCampaign.setSspProgrammatic(1);\n" +
//                "        subCampaign.setStatus(0);\n" +
//                "\n" +
//                "        CampaignTargetScenarioViewDTO targetScenarioViewDTO = new CampaignTargetScenarioViewDTO();\n" +
//                "        subCampaign.setCampaignTargetScenarioViewDTO(targetScenarioViewDTO);\n" +
//                "\n" +
//                "        List<CampaignAdzoneViewDTO> subAdzoneList = new ArrayList<>();\n" +
//                "        CampaignAdzoneViewDTO adzone1 = new CampaignAdzoneViewDTO();\n" +
//                "        adzone1.setAdzoneId(63776549L);\n" +
//                "        adzone1.setPid(\"mm_10982364_973726_63776549\");\n" +
//                "        CampaignAdzoneViewDTO adzone2 = new CampaignAdzoneViewDTO();\n" +
//                "        adzone2.setAdzoneId(63780168L);\n" +
//                "        adzone2.setPid(\"mm_10982364_973726_63780168\");\n" +
//                "        subAdzoneList.add(adzone1);\n" +
//                "        subAdzoneList.add(adzone2);\n" +
//                "        targetScenarioViewDTO.setCampaignAdzoneViewDTOList(subAdzoneList);\n" +
//                "\n" +
//                "        List<CampaignTargetViewDTO> subTargetList = new ArrayList<>();\n" +
//                "        CampaignTargetViewDTO target = new CampaignTargetViewDTO();\n" +
//                "        target.setType(\"6507\");\n" +
//                "        target.setTargetValues(Lists.newArrayList(\"973726\"));\n" +
//                "        subTargetList.add(target);\n" +
//                "        targetScenarioViewDTO.setCampaignTargetViewDTOList(subTargetList);\n" +
//                "\n" +
//                "        dbCampaignViewDTO.setSubCampaignViewDTOList(Lists.newArrayList(subCampaign));\n" +
//                "\n" +
//                "        // Create ability param\n" +
//                "        CampaignUpdateAbilityParam abilityParam = CampaignUpdateAbilityParam.builder()\n" +
//                "                .abilityTarget(campaignViewDTO)\n" +
//                "                .dbCampaignViewDTO(dbCampaignViewDTO)\n" +
//                "                .build();\n" +
//                "\n" +
//                "        // Execute test\n" +
//                "        Boolean result = ability.handle(serviceContext, abilityParam);\n" +
//                "\n" +
//                "        // Verify result\n" +
//                "        assertTrue(\"Should allow update with third monitor settings\", result);\n" +
//                "    }\n" +
//                "}"
//        );
//        return result.toString();
//    }
//    public String dependency_stage2(String targetMethodInf,int pathId) {
//        StringBuilder result=new StringBuilder();
//        result.append("\n# 为了帮助你写出无编译错误的测试代码，我提供给你可能需要的依赖信息如下：\n");
//        result.append("```\n");
//        result.append(DependencyUtil.getRouteDeepClassDependency(targetMethodInf,pathId));
//        result.append("\n```\n");
//        return result.toString();
//    }
//    private static String combineElements(String fullClassName, String methodSignature) {
//        //提取类名（取最后一个点后面的部分）
//        String className = fullClassName.substring(fullClassName.lastIndexOf('.') + 1);
//
////        // 提取方法名（取第一个***之前的部分）
////        String methodName = methodSignature.split("\\*\\*\\*")[0];
////
////        // 提取返回类型（在第一个和第二个***之间的部分）
////        String returnType = "";
////        String[] parts = methodSignature.split("\\*\\*\\*");
////        if (parts.length >= 2) {
////            returnType = parts[1];
////        }
//        // 提取方法名
//        String methodName = extractBetween(methodSignature, "_FUNCTIONNAME_", "_RETURNTYPE_");
//
//        // 提取返回值类型
//        String returnType = extractBetween(methodSignature, "_RETURNTYPE_", "_Parameters_");
////        if(methodSignature.equals("_CLASSNAME_com.taobao.ad.brand.bp.domain.account.atomability.DefaultAccountAdcRoleGetAbility_FUNCTIONNAME_handle_RETURNTYPE_java.util.Set_Parameters_+com.alibaba.abf.governance.context.ServiceContext+com.taobao.ad.brand.bp.domain.sdk.account.atomability.param.AccountAdcRoleGetAbilityParam+")){
////            System.out.println("%%%%%%%%%%%%%%%%");
////            System.out.println(String.format("%s+%s+%s", className, methodName, returnType));
////            System.out.println("%%%%%%%%%%%%%%%%");
////        }
//
//        // 组合结果
//        return String.format("%s+%s+%s", className, methodName, returnType);
//    }
//    private static String extractBetween(String input, String startMarker, String endMarker) {
//        int startIndex = input.indexOf(startMarker) + startMarker.length();
//        int endIndex = input.indexOf(endMarker);
//        if (startIndex == -1 || endIndex == -1) {
//            throw new IllegalArgumentException("Markers not found in input string");
//        }
//        return input.substring(startIndex, endIndex);
//    }
//    public void PromptBulidAndSava2TXT(String dependencyFilePath, String targetMethodInf, String stage1outFilePath, String savePath,int pathId,String classname) throws IOException {
//        StringBuilder prompt = new StringBuilder();
//        prompt.append(this.Role());
//        prompt.append(this.stage1_output(stage1outFilePath));
//        prompt.append(this.dependency_stage2(targetMethodInf,pathId));
//        prompt.append(this.COT());
//        prompt.append(this.constraint());
//        try {
//            // 创建File对象
//            File file = new File(savePath);
//
//            // 获取文件的父目录
//            File parentDir = file.getParentFile();
//
//            // 如果父目录不存在，则创建所有必需的父目录
//            if (parentDir != null && !parentDir.exists()) {
//                boolean dirCreated = parentDir.mkdirs();
//                if (dirCreated) {
//                    System.out.println("成功创建目录: " + parentDir.getPath());
//                } else {
//                    System.out.println("创建目录失败: " + parentDir.getPath());
//                    return; // 如果目录创建失败，直接返回
//                }
//            }
//
//            // 创建或打开文件并写入内容
//            FileWriter fw = new FileWriter(file, false);
//            BufferedWriter bw = new BufferedWriter(fw);
//            bw.write(String.valueOf(prompt));
//            bw.close();
//            System.out.println("内容已成功写入 " + savePath);
//        } catch (IOException e) {
//            System.out.println("写入文件时发生错误：" + e.getMessage());
//            e.printStackTrace();
//        }
//
//
//    }
//    public static void main(String[] args) {
//        String csvFilePath = "AllDependency.csv";
//        try (CSVReader reader = new CSVReader(new FileReader(csvFilePath))) {
//            // 跳过标题行
//            reader.readNext();
//            String[] nextLine;
//            while ((nextLine = reader.readNext()) != null) {
//                if (nextLine.length > 0) {
//                    String firstColumnValue = nextLine[0].trim();
//                    String secondColumnValue=nextLine[1].trim();
//                    String DirPath="./Output/stage1/"+stage2.combineElements(firstColumnValue,secondColumnValue)+"/";
//                    System.out.println(stage2.combineElements(firstColumnValue,secondColumnValue));
//                    for(int i=1;;i++){
//                        String stage1outFilePath =DirPath+String.valueOf(i)+".json";
//                        if(!stage2.isFileExist(stage1outFilePath)) {
//                            System.out.println(stage1outFilePath+"不存在");
//                            break;
//                        }
//                        String savePath="./Prompt/stage2/"+stage2.combineElements(firstColumnValue,secondColumnValue)+"/"+String.valueOf(i)+".txt";
//                        stage2 promptbuilder=new stage2();
//                        promptbuilder.path=i;
//                        promptbuilder.PromptBulidAndSava2TXT(csvFilePath,secondColumnValue,stage1outFilePath,savePath,i,firstColumnValue);
//
//                    }
//                }
//            }
//
//        } catch (IOException | CsvValidationException e) {
//            System.err.println("读取文件时发生错误: " + e.getMessage());
//            e.printStackTrace();
//        }
//    }
//
//}



package com.alibaba.ad.code.promptProduce;

import com.alibaba.ad.code.cfganalyser.code.util.DependencyUtil;
import com.alibaba.ad.code.dto.StageInfo;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;

@NoArgsConstructor
@AllArgsConstructor
@Slf4j
public class Stage2 {
    public String taskCreateTime;
    public int path;
    public String Role(String unitTestFilePath) {
        String role = "# Task:\n" +
                "I would like you to help write unit test code for a method. I have the following information:\n" +
                "1. The source code of the Java method, test intention, and paths to be covered;\n" +
                "2. I will guide you on how to construct input data and provide verification points;\n" +
                "3. I will provide the method's dependency information to ensure you can generate compilable, runnable test programs;\n" +
                "4. You should generate unit test code to java file at \"" + unitTestFilePath + "\".\n" +
                "\n" +
                "Please analyze the following information to generate a unit test class.\n" +
                "\n";
        return role;
    }
    public String method_java() {
        StringBuilder result = new StringBuilder();
        String method = "public boolean isBeforeLastStageAndOpen(CampaignViewDTO campaignViewDTO) {\n" +
                "        ActivityOptimizeTransStageViewDTO stageViewDTO = campaignViewDTO.getActivityOptimizeTransStageViewDTO();\n" +
                "        if (stageViewDTO != null && stageViewDTO.checkOpen()) {\n" +
                "            List<ActivityOptimizeTransStageViewDTO.Stage> stages = campaignViewDTO.getActivityOptimizeTransStageViewDTO().getStages();\n" +
                "            if (CollectionUtils.size(stages) < 2) {\n" +
                "                log.warn(\"计划优化目标流转阶段不足2个\");\n" +
                "                return false;\n" +
                "            } else {\n" +
                "                ActivityOptimizeTransStageViewDTO.Stage lastStages = (ActivityOptimizeTransStageViewDTO.Stage)stages.get(stages.size() - 1);\n" +
                "                LocalDateTime startTime = LocalDateTime.parse(lastStages.getStartTime(), Constants.DATE_TIME_FORMATTER_1);\n" +
                "                return LocalDateTime.now().isBefore(startTime);\n" +
                "            }\n" +
                "        } else {\n" +
                "            return false;\n" +
                "        }\n" +
                "    }\n";
        result.append(
                "待测方法:\n" +
                        method + "\n");
        return result.toString();
    }
    public String stage1_output(String filePath) {
        StringBuilder result = new StringBuilder();
        String[] orderedKeys = {
                "java method",
                "test intention",
                "path analysis",
                "input data construction",
                "verification points"
        };

        try {
            String jsonContent = new String(Files.readAllBytes(Paths.get(filePath)));
            JSONObject jsonObject = new JSONObject(jsonContent);
            // 按预定义顺序输出
            for (String key : orderedKeys) {
                if (jsonObject.has(key)) {
                    result.append("# ").append(key).append(": \n")
                            .append(jsonObject.get(key))
                            .append("\n");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            return "Error reading JSON file: " + e.getMessage();
        } catch (Exception e) {
            e.printStackTrace();
            return "Error parsing JSON: " + e.getMessage();
        }

        return result.toString();
    }
    public String COT() {
        StringBuilder result = new StringBuilder();
        result.append("\n# Work Steps:\n" +
                "1. Understand the Java method, test purpose, and test paths;\n" +
                "2. Understand and analyze the 'input data construction' and 'verification points' for this test;\n" +
                "3. Understand and analyze the dependency information for the Java method;\n" +
                "4. Generate a complete test program for the Java method, including comments explaining test intentions;\n"
        );
        return result.toString();
    }
    public String constraint() throws IOException {
        StringBuilder result = new StringBuilder();
        String targetContent = new String(Files.readAllBytes(Paths.get(this.taskCreateTime+"/target.json")));
        JSONObject targetJson = new JSONObject(targetContent);
        String test_out_path = targetJson.getString("test_out_path");
        result.append(
                "# Unit Test Requirements:\n" +
                        //"* Use Java 8 with JUnit 4, Mockito, PowerMockito frameworks for unit testing, do not use Hamcrest framework\n" +
                        "* Complete import statements for all used classes, don't forget to import the tested class based on its actual package path in the Java class context to ensure correct compilation\n" +
                        "* For object creation, prefer using no-arg constructors first, then use setter methods for property assignment; only use .builder()...build() pattern if the class has @Builder or @SuperBuilder annotation\n" +
                        "* For mocked methods with no return value or Void type, use Mockito.doNothing().when(...) pattern for mocking\n" +
                        "* Only use existing methods and properties from the target class, do not assume or speculate about other methods\n" +
                        "* When mocking a method's return value, first verify that the method is called in the original code\n" +
                        "* Reference method calls in original code to determine which methods to mock, such as method calls in if statements\n" +
                        "* Analyze Java class logic to perform Assert checks on execution paths, method calls and object properties\n" +
                        "* Do not add any explanations or content other than code and test intention comments\n" +
                        "* If you need to create objects like 'AdgroupRealTimeOptimizeAlgoCrowdSaveAbilityParam abilityParam', please follow this construction pattern:\n" +
                        "private AdgroupRealTimeOptimizeAlgoCrowdSaveAbilityParam abilityParam;\n" +
                        "```java\n" +
                        "abilityParam = AdgroupRealTimeOptimizeAlgoCrowdSaveAbilityParam.builder()\n" +
                        "                .abilityTarget(adgroupViewDTO)\n" +
                        "                .dbCampaignCrowdMap(dbCampaignCrowdMap)\n" +
                        "                .optimizeCrowdViewDTOList(optimizeCrowdViewDTOList)\n" +
                        "                .build();\n" +
                        "```\n" +
                        "Never use this pattern:\n" +
                        "```java\n" +
                        "        abilityParam = new AdgroupInitForUpdateNReachAdgroupAbilityParam();\n" +
                        "        abilityParam.setAbilityTarget(adgroupViewDTO);\n" +
                        "        abilityParam.setCampaignViewDTO(campaignViewDTO);\n" +
                        "```\n" +
                        "Because these parameter classes (usually ending with param) are annotated with @SuperBuilder, use .builder()...build() pattern for object creation\n" +
                        "* Note: Don't forget to import common classes (like List)\n" +
                        "* Note: Test class should be named as \"TestedClassName_TestedMethod_CurrentPathNumber(pathid=" + this.path + ")_Test\"\n" +
                        "* Note: Generated code will be saved to " + convertPathToPackageName(test_out_path) + " folder, please add corresponding \"package " + convertPathToPackageName(test_out_path) + "\" information\n" +
                        "* Note: Please put the final generated code inside \"```java ```\""+
                        "Do not attempt to mock system classes or core classes from third-party libraries.\n" +
                        "For enum classes use them directly instead of mocking.\n" +
                        "Both PowerMock and Mockito can be used but please check if youve confused the API usage of PowerMock and Mockito which might lead to program errors.\n" +
                        "PowerMock and Mockitos MockedStatic may conflict when handling static methods Its recommended to choose one method to mock static methods and avoid using two different approaches simultaneously.\n" +
                        "When methods are overloaded provide explicit type casting For example this syntax will report an error AssertUtilnotEmptyany anyString because the method call is ambiguous matching both AssertUtilnotEmptyObjectString and AssertUtilnotEmptyCollectionString.\n" +
                        "All variables needed in the verification stage should be defined in the outermost scope.\n" +
                        "Mock objects should be defined in setUp or at the beginning of the test method.\n" +
                        "When using the any matcher it may cause Mockito to enter infinite recursion when verifying parameters Its recommended to use more specific parameter matching.\n" +
                        "For mocking void methods use the doNothingwhenmockmethod approach.\n" +
                        "For methods with return values use the whenmockmethodthenReturnvalue approach.\n"
        );
        result.append("Proper use of @Spy annotation: Always provide an actual instance for @Spy fields.\n" +
                "Choose the appropriate test runner: Only use specialized runners like PowerMockRunner when necessary.\n" +
                "Understand annotation compatibility: Correct combination of @Mock, @Spy, and @InjectMocks.\n" +
                "Adopt suitable Spy creation strategies: Field-level initialization or programmatic creation in test methods.\n" +
                "Maintain consistency in test data: Ensure coherence in object relationships and ID references.\n" +
                "Carefully analyze execution paths of code under test: Understand conditional branches and method call order.\n" +
                "Correctly set up and verify Mocks: Configure and verify Mock objects based on actual execution paths.\n" +
                "Focus on testing public behavior: Avoid directly testing private methods and implementation details.\n" +
                "Mock static methods and cryptographic operations: Use @PrepareForTest and mock operations that may cause runtime issues.\n" +
                "Systematically debug test failures: Carefully read error messages, trace execution paths.\n" +
                "Use PowerMock judiciously: Only when necessary, consider alternative designs.\n" +
                "Follow test design principles: Focus each test method on a single scenario, maintain clear test intentions.");
        return result.toString();
    }
    public String Pom(){
        StringBuilder result = new StringBuilder();
        result.append("\n# The Maven dependencies related to unit testing in the project:\n"+
                "```xml\n" +
                "        <dependency>\n" +
                "            <groupId>junit</groupId>\n" +
                "            <artifactId>junit</artifactId>\n" +
                "            <version>4.13.2</version>\n" +
                "        </dependency>\n" +
                "\n" +
                "        <!-- Mockito -->\n" +
                "        <dependency>\n" +
                "            <groupId>org.mockito</groupId>\n" +
                "            <artifactId>mockito-core</artifactId>\n" +
                "            <version>3.8.0</version>\n" +
                "        </dependency>\n" +
                "        <dependency>\n" +
                "            <groupId>org.mockito</groupId>\n" +
                "            <artifactId>mockito-inline</artifactId>\n" +
                "            <version>3.8.0</version>\n" +
                "        </dependency>\n" +
                "\n" +
                "        <!-- PowerMock -->\n" +
                "        <dependency>\n" +
                "            <groupId>org.powermock</groupId>\n" +
                "            <artifactId>powermock-module-junit4</artifactId>\n" +
                "            <version>2.0.9</version>\n" +
                "        </dependency>\n" +
                "        <dependency>\n" +
                "            <groupId>org.powermock</groupId>\n" +
                "            <artifactId>powermock-api-mockito2</artifactId>\n" +
                "            <version>2.0.9</version>\n" +
                "        </dependency>\n" +
                "        <!-- ByteBuddy -->\n" +
                "        <dependency>\n" +
                "            <groupId>net.bytebuddy</groupId>\n" +
                "            <artifactId>byte-buddy</artifactId>\n" +
                "            <version>1.10.20</version>\n" +
                "        </dependency>\n" +
                "        <dependency>\n" +
                "            <groupId>net.bytebuddy</groupId>\n" +
                "            <artifactId>byte-buddy-agent</artifactId>\n" +
                "            <version>1.10.20</version>\n" +
                "        </dependency>\n"
            + "```");
        return result.toString();
    }
    public static boolean isFileExist(String filePath) {
        File file = new File(filePath);
        return file.exists() && file.isFile();
    }
    public Stage2(String taskCreateTime){
        this.taskCreateTime=taskCreateTime;
    }
    public static String convertPathToPackageName(String path) {
        // 1. 首先找到 "java/" 的位置
        int javaIndex = path.indexOf("java/");
        if (javaIndex == -1) {
            return ""; // 如果没有找到 "java/"，返回空字符串或者可以抛出异常
        }

        // 2. 获取 "java/" 之后的字符串
        String packagePath = path.substring(javaIndex + "java/".length());

        // 3. 将路径分隔符替换为点号
        String packageName = packagePath.replace('/', '.');

        // 4. 处理Windows系统的路径分隔符（如果有的话）
        packageName = packageName.replace('\\', '.');

        // 5. 移除末尾的 .java（如果有的话）
        if (packageName.endsWith(".java")) {
            packageName = packageName.substring(0, packageName.length() - ".java".length());
        }
        if(packageName.endsWith(".")){
            packageName = packageName.substring(0, packageName.length() - ".".length());
        }

        return packageName;
    }
    public String dependency_stage2(String targetMethodInf,int pathId) {
        StringBuilder result=new StringBuilder();
        result.append("\n# Here are the dependencies you might need to write error-free test code:\n");
        result.append("```\n");
        DependencyUtil dependencyUtil = new DependencyUtil(this.taskCreateTime);
        result.append(dependencyUtil.getRouteDeepClassDependency(this.taskCreateTime,targetMethodInf,pathId));
        result.append("\n```\n");
        return result.toString();
    }

    public StageInfo PromptBuildAndSaveForAllCfgRoute(String dependencyFilePath, String targetMethodInf, String stage1OutDir, String savePath, ArrayList<Integer> routeIndexList, String className) throws Exception{
        String targetContent = new String(Files.readAllBytes(Paths.get(this.taskCreateTime+"/target.json")));
        JSONObject targetJson = new JSONObject(targetContent);
        String moduleName = targetJson.getString("module_name");
        String[] splitResult = StringUtils.splitByWholeSeparator(className, ".target.classes.");
        String fullClassName = splitResult[splitResult.length - 1];
        String unitTestFilePath = "{testFilePath}/" + moduleName + "/src/test/java/" + StringUtils.replace(fullClassName, ".", "/") + "Tests.java";
        log.info("unitTestFilePath: {}", unitTestFilePath);
        StringBuilder prompt = new StringBuilder();
        StageInfo stageInfo = new StageInfo();
        prompt.append(this.Role(unitTestFilePath));
        boolean hasParseJava = false;

        for(int i = 0; i < routeIndexList.size(); i++) {
            //if (i == 15) {
            //    log.warn("Too many routes, only show 10 routes, className: {}", className);
            //    break;
            //}
            Integer index = routeIndexList.get(i);
            String stage1OutFilePath = stage1OutDir + "/" + index + ".json";
            if(!hasParseJava) {
                hasParseJava = true;
                prompt.append("Here is the Source Code:\n").append(parseStage1JavaCode(stage1OutFilePath)).append("\n");
                prompt.append("# Test Cases:\n");
            }
            prompt.append(parseAllInputDataFromStage1(stage1OutFilePath,index));
        }

        prompt.append(this.getAllRouteDependencyInStage2(targetMethodInf));
        //prompt.append(this.COT());
        //prompt.append(this.constraint());
        //prompt.append(this.Pom());
        log.info("prompt for {}:\n{}", fullClassName, prompt);
        try {
            File file = new File(savePath);
            File parentDir = file.getParentFile();

            if (parentDir != null && !parentDir.exists()) {
                boolean dirCreated = parentDir.mkdirs();
                if (dirCreated) {
                    log.info("成功创建目录: {}", parentDir.getPath());
                } else {
                    log.error("创建目录失败: {}", parentDir.getPath());
                    return null;
                }
            }

            // 暂时不写本地
            //FileWriter fw = new FileWriter(file, false);
            //BufferedWriter bw = new BufferedWriter(fw);
            //bw.write(String.valueOf(prompt));
            //bw.close();
            //log.info("内容已成功写入 {}", savePath);
            stageInfo.setSavePath(savePath);
            stageInfo.setData(prompt.toString());
            return stageInfo;
        } catch (Exception e) {
            log.error("写入文件时发生错误：{}", e.getMessage(), e);
        }
        return null;
    }

    public static String parseStage1JavaCode(String filePath){
        try{
            String jsonContent = new String(Files.readAllBytes(Paths.get(filePath)));
            JSONObject jsonObject = new JSONObject(jsonContent);
            if(jsonObject.has("java method")){
                return jsonObject.getString("java method");
            }
            else {
                return "";
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static String parseAllInputDataFromStage1(String filePath,Integer routeIndex){
        StringBuilder result = new StringBuilder();
        String[] orderedKeys = {
                "test intention",
                "path analysis",
                "input data construction",
                "verification points"
        };

        try {
            String jsonContent = new String(Files.readAllBytes(Paths.get(filePath)));
            JSONObject jsonObject = new JSONObject(jsonContent);
            // 按预定义顺序输出
            result.append("\n\n## Test case  NO.").append(routeIndex).append("\n");
            for (String key : orderedKeys) {
                if (jsonObject.has(key)) {
                    result.append("### ").append(key).append(": \n")
                            .append(jsonObject.get(key))
                            .append("\n");
                }
            }
        }  catch (Exception e) {
            e.printStackTrace();
            return "Error parsing JSON: " + e.getMessage();
        }
        return result.toString();
    }

    public String getAllRouteDependencyInStage2(String targetMethodInf){
        DependencyUtil dependencyUtil = new DependencyUtil();
        return "\n# Dependency Information:\n"
            + "Here are the dependencies you might need to write error-free test code:\n" +
                "```\n" +
            dependencyUtil.getClassDeepDependencyForAllCfgPath(targetMethodInf) +
                "\n```\n";
    }

    public static String combineElements(String fullClassName, String methodSignature) {
         //提取类名（取最后一个点后面的部分）
        String className = fullClassName.substring(fullClassName.lastIndexOf('.') + 1);

//        // 提取方法名（取第一个***之前的部分）
//        String methodName = methodSignature.split("\\*\\*\\*")[0];
//
//        // 提取返回类型（在第一个和第二个***之间的部分）
//        String returnType = "";
//        String[] parts = methodSignature.split("\\*\\*\\*");
//        if (parts.length >= 2) {
//            returnType = parts[1];
//        }
        // 提取方法名
        String methodName = extractBetween(methodSignature, "_FUNCTIONNAME_", "_RETURNTYPE_");

        // 提取返回值类型
        String returnType = extractBetween(methodSignature, "_RETURNTYPE_", "_Parameters_");
//        if(methodSignature.equals("_CLASSNAME_com.taobao.ad.brand.bp.domain.account.atomability.DefaultAccountAdcRoleGetAbility_FUNCTIONNAME_handle_RETURNTYPE_java.util.Set_Parameters_+com.alibaba.abf.governance.context.ServiceContext+com.taobao.ad.brand.bp.domain.sdk.account.atomability.param.AccountAdcRoleGetAbilityParam+")){
//            System.out.println("%%%%%%%%%%%%%%%%");
//            System.out.println(String.format("%s+%s+%s", className, methodName, returnType));
//            System.out.println("%%%%%%%%%%%%%%%%");
//        }

        // 组合结果
        return String.format("%s+%s+%s", className, methodName, returnType);
    }
    private static String extractBetween(String input, String startMarker, String endMarker) {
        int startIndex = input.indexOf(startMarker) + startMarker.length();
        int endIndex = input.indexOf(endMarker);
        if (startIndex == -1 || endIndex == -1) {
            throw new IllegalArgumentException("Markers not found in input string");
        }
        return input.substring(startIndex, endIndex);
    }
    public void PromptBulidAndSava2TXT(String dependencyFilePath, String targetMethodInf, String savePath,int pathId,String classname) throws IOException {
        StringBuilder prompt = new StringBuilder();
        String[] splitResult = StringUtils.splitByWholeSeparator(classname, ".target.classes.");
        String fullClassName = splitResult[splitResult.length - 1];
        String unitTestFilePath = "src/test/java" + StringUtils.replace(fullClassName, ".", "/") + "Tests.java";
        prompt.append(this.Role(unitTestFilePath));
        //prompt.append("OK,Now Generate a complete test program for the Java method, including comments explaining test intentions;\n");
        prompt.append(this.dependency_stage2(targetMethodInf,pathId));
//        prompt.append(this.stage1_output(stage1outFilePath));
        prompt.append(this.COT());
        prompt.append(this.constraint());
        prompt.append(this.Pom());
        try {
            // 创建File对象
            File file = new File(savePath);

            // 获取文件的父目录
            File parentDir = file.getParentFile();

            // 如果父目录不存在，则创建所有必需的父目录
            if (parentDir != null && !parentDir.exists()) {
                boolean dirCreated = parentDir.mkdirs();
                if (dirCreated) {
                    System.out.println("成功创建目录: " + parentDir.getPath());
                } else {
                    System.out.println("创建目录失败: " + parentDir.getPath());
                    return; // 如果目录创建失败，直接返回
                }
            }

            // 创建或打开文件并写入内容
            FileWriter fw = new FileWriter(file, false);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(String.valueOf(prompt));
            bw.close();
            System.out.println("内容已成功写入 " + savePath);
        } catch (IOException e) {
            System.out.println("写入文件时发生错误：" + e.getMessage());
            e.printStackTrace();
        }


    }
    public static void main(String[] args) {
        String className = ".home.admin.uinttest.result.brand-onebp.brand-onebp-domain.08251155-qwen3.target.classes.com.taobao.ad.brand.bp.domain.account.atomability.DefaultAccountShopExistJudgeAbility";
        String[] splitResult = StringUtils.splitByWholeSeparator(className, ".target.classes.");
        String fullClassName = splitResult[splitResult.length - 1];
        String unitTestFilePath = StringUtils.replace(fullClassName, ".", "/") + "Tests.java";
        log.info("unitTestFilePath: {}", unitTestFilePath);
    }

}
