package com.alibaba.ad.code.dto;

import com.alibaba.fastjson.JSONObject;
import lombok.Data;

/**
 * controller层响应结构体
 *
 * @author zhangheng
 */
@Data
public class ResultDTO {

    private final Info info;

    private Object data;

    private ResultDTO(boolean isOk) {
        this.info = new Info(isOk);
    }

    public static ResultDTO successResult() {
        return new ResultDTO(true);
    }

    public static ResultDTO successResultWithObject(Object data) {
        ResultDTO resultDTO = new ResultDTO(true);
        resultDTO.data = data;
        return resultDTO;
    }

    public static ResultDTO errorResult(String message) {
        ResultDTO result = new ResultDTO(false);
        result.getInfo().setMessage(message);
        return result;
    }

    public static ResultDTO errorResult(String message, String errorCode) {
        ResultDTO result = new ResultDTO(false);
        result.getInfo().setMessage(message);
        result.getInfo().setErrorCode(errorCode);
        return result;
    }

    public static ResultDTO errorWithRedirectUrl(String message, String redirectUrl) {
        ResultDTO result = new ResultDTO(false);
        result.getInfo().setMessage(message);
        result.getInfo().setUnlockUrl(redirectUrl);
        return result;
    }

    @Override
    public String toString() {
        return JSONObject.toJSONString(this);
    }
}
