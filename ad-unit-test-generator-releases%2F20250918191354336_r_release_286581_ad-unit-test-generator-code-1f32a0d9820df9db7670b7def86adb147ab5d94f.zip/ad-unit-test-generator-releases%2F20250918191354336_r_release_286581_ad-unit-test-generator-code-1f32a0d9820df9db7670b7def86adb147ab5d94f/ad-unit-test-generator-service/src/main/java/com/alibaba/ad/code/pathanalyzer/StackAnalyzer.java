package com.alibaba.ad.code.pathanalyzer;

import sootup.core.jimple.common.stmt.Stmt;

import java.util.HashMap;
import java.util.Map;

public class StackAnalyzer {
    /**
     * 分析所有栈信息，储存每个栈针对应的内容。
     * 永远不应该调用该方法，调用接口被封装在 PathAnalyzer 中。
     *
     * @param index index 与 stmt 的映射关系
     * @return 所有栈信息。
     * @throws Exception 输入或输出为空。
     */
    public Map<Integer, String> analyse(Map<Integer, Stmt> index) throws Exception {
        Map<Integer, String> stackMap = new HashMap<>();
        int size = index.size();
        if(size == 0) {
            throw new Exception("stack analyze meet an empty input!");
        }
        for(int i = 1; i <= size; i++) {
            String stmt = index.get(i).toString();
            if(stmt.length() <= 12) {
                continue;
            }
            if(stmt.substring(0,6).equals("$stack")) {
                String[] stackInfos = stmt.split(" ");
                int num = Integer.parseInt(stackInfos[0].substring(6));
                String stackInfo = stackInfos[2];
                for(int j = 3 ; j < stackInfos.length; j++) {
                    stackInfo += stackInfos[j];
                }
                stackMap.put(num, stackInfo);
            }
        }
        return stackMap;
    }
}
