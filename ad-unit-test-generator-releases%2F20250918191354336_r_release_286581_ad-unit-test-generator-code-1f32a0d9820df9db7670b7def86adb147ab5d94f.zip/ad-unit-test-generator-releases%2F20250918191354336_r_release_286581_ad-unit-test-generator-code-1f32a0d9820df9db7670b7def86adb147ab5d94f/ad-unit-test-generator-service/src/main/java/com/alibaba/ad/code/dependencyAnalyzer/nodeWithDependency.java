package com.alibaba.ad.code.dependencyAnalyzer;

import java.util.ArrayList;

public class nodeWithDependency {
    public int pathnode;//实际的node编号
    public ArrayList<Dependency> dependencies;
    public nodeWithDependency(int pathnode){
        this.pathnode=pathnode;
        this.dependencies=new ArrayList<>();
    }
    public String getDependencyInf(){
        String s="";
        for(Dependency dependency:this.dependencies){
            s=s+"The variable \""+dependency.value+"\" in the statement numbered "+pathnode+" was assigned: ###"+dependency.lastAssignPathnode+" "+dependency.lastAssignStmt+";"+"\n";
        }

        return s;
    }
}
