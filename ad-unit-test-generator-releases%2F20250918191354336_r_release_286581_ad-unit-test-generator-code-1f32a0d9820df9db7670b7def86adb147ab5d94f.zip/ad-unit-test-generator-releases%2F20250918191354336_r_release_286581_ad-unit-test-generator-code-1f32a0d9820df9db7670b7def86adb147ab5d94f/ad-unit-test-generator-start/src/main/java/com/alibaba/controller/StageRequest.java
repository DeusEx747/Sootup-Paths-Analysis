package com.alibaba.controller;

import java.util.Set;

import lombok.Data;

/**
 * @author nanfeng.jys
 * @date 2025/8/6 19:36
 * @description
 */
@Data
public class StageRequest {

    private String uuid;

    private String appName;

    private String moduleName;

    private String subPath;

    /**
     * 目标类需要实现的注解
     */
    private Set<String> hasAnnotations;

    /**
     * 目标类需要实现的接口
     */
    private Set<String> implementInterfaces;

    /**
     * 目标类集合
     */
    private Set<String> classNames;

    private String callbackUrl;

    private String workDir;

}
