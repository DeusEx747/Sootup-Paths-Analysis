package com.alibaba;

import com.alibaba.ad.code.cfganalyser.code.CFGGeneration;
import com.alibaba.ad.code.cfganalyser.code.DependencyGeneration;
import com.alibaba.ad.code.promptProduce.PathUtils;
import com.alibaba.ad.code.promptProduce.Stage2;
import com.alibaba.ad.code.promptProduce.JavaMethodFind;
import com.alibaba.ad.code.promptProduce.Stage1;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.LocalDateTime;
import java.util.HashMap;

/*
classPath-->cfgGeneration-->AllCFGPath.csv
classPath,javaPath-->dependency-->AllDependency.csv
javaPath,AllCFGPath.csv-->stage_1-->prompt_1
 */
public class Starter {
    public String taskCreateTime;
    public String class_path;
    public String java_path;
    public String find_dependency_path;
    public String maven_repository;
    public String testoutputPath;

    public static void cleanupDirectories(String rootPath) {
        try {
            Files.walkFileTree(Paths.get(rootPath), new SimpleFileVisitor<Path>() {
                @Override
                public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                    // 检查目录名是否以"+handle+java.lang.Object"结尾
                    if (dir.getFileName().toString().endsWith("+handle+java.lang.Object")) {
                        try {
                            // 获取目录中的文件列表
                            File[] files = dir.toFile().listFiles();

                            // 检查目录是否只包含一个文件
                            if (files != null && files.length == 1 && files[0].isFile()) {
                                // 先删除文件
                                Files.delete(files[0].toPath());
                                // 再删除目录
                                Files.delete(dir);
                                System.out.println("Deleted directory: " + dir);
                                return FileVisitResult.SKIP_SUBTREE;
                            }
                        } catch (IOException e) {
                            System.err.println("Error processing directory: " + dir);
                            e.printStackTrace();
                        }
                    }
                    return FileVisitResult.CONTINUE;
                }

                @Override
                public FileVisitResult visitFileFailed(Path file, IOException exc) {
                    System.err.println("Failed to access file: " + file);
                    return FileVisitResult.CONTINUE;
                }
            });
        } catch (IOException e) {
            System.err.println("Error walking through directory tree");
            e.printStackTrace();
        }
    }

    /**
     * 递归搜索并删除目录
     *
     * @param directory 要搜索的目录
     * @return true如果目录被删除，false否则
     */
    private static boolean searchAndDelete(File directory) {
        // 如果当前目录名包含"Campaign"
        if (directory.getName().contains("Campaign")) {
            // 删除该目录及其所有内容
            deleteDirectoryRecursively(directory);
            System.out.println("已删除目录：" + directory.getAbsolutePath());
            return true;
        }

        // 获取所有子文件和子目录
        File[] files = directory.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    // 递归处理子目录
                    searchAndDelete(file);
                }
            }
        }

        return false;
    }

    /**
     * 递归删除目录及其内容
     *
     * @param directory 要删除的目录
     * @return true如果删除成功，false否则
     */
    private static boolean deleteDirectoryRecursively(File directory) {
        File[] files = directory.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    deleteDirectoryRecursively(file);
                } else {
                    if (!file.delete()) {
                        System.out.println("无法删除文件：" + file.getAbsolutePath());
                    }
                }
            }
        }
        return directory.delete();
    }

    public Starter(String class_path, String java_path, String find_dependency_path, String maven_repository,
        String testoutputPath) throws IOException {
        this.taskCreateTime = String.valueOf(LocalDateTime.now());
        //this.taskCreateTime = "2025-07-24T02:04:12.394226";
        this.class_path = class_path;
        this.maven_repository = maven_repository;
        this.find_dependency_path = find_dependency_path;
        this.java_path = java_path;
        this.testoutputPath = testoutputPath;
        // 定义输出目录
        String outputDir = "./" + this.taskCreateTime; // 修改为你的目录路径
        String fileName = "target.json";
        // 创建 JSON 对象并填充数据
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("class_path", class_path);
        jsonObject.put("java_path", java_path);
        jsonObject.put("find_dependency_path", find_dependency_path);
        jsonObject.put("maven_repository", maven_repository);
        jsonObject.put("test_out_path", testoutputPath);
        // 写 JSON 到文件
        File directory = new File(outputDir);
        if (!directory.exists()) {
            directory.mkdirs(); // 创建目标目录
        }
        Files.write(Path.of(outputDir + "/" + fileName), jsonObject.toString(4).getBytes());
        System.out.println(outputDir + "/" + fileName + "写入文件成功!");
    }

    public void run() {
        //依赖提取
        DependencyGeneration dependencyGeneration = new DependencyGeneration(this.taskCreateTime, maven_repository,
            find_dependency_path, find_dependency_path);
        dependencyGeneration.FetchAllDependency(class_path);
        //cfg路径分析
        CFGGeneration cfgGeneration = new CFGGeneration(this.taskCreateTime, false, true);
        cfgGeneration.AllCfgGenerate(class_path);
        cfgGeneration.CfgToRouteClassDependency(cfgGeneration);

        //stage1-Prompt
        String csvFilePath = this.taskCreateTime + "/" + "AllCFGPath.csv";
        String[] targetMethodInfs = Stage1.getUniqueFirstColumnValues(csvFilePath);
        for (String targetMethodInf : targetMethodInfs) {
            System.out.println("targetMethodInf:" + targetMethodInf);
            JavaMethodFind processor = new JavaMethodFind();
            if (!processor.ExistMethod(this.taskCreateTime, targetMethodInf)) {//判断条件：存在且为public，且返回值一样
                continue;
            }
            String methodContent = processor.getClassContent(this.taskCreateTime, targetMethodInf);
            String classname = processor.extractClassName(targetMethodInf);
            if (!methodContent.isEmpty()) {
                Stage1 promprBuilder = new Stage1(this.taskCreateTime);
                promprBuilder.method_java = methodContent;
                promprBuilder.Class_java = classname;
                String saveDir = "./" + this.taskCreateTime + "/Prompt/stage1/"
                    + promprBuilder.parseSimpleClassAndMethodName(targetMethodInf);
                boolean result = PathUtils.ensureDirectoryExists(saveDir);
                if (result) {
                    System.out.println("目录存在或已成功创建。" + saveDir);
                } else {
                    System.out.println("目录创建失败或路径被占用。");
                }
                //prompt产生
                promprBuilder.AllPromptBuildAndSave2TXT(csvFilePath, targetMethodInf, saveDir, new HashMap<>());
            }
        }
        Starter.cleanupDirectories("./" + this.taskCreateTime + "/Prompt/stage1");
        //
        //stage2:没改完，找依赖信息的没确认
        csvFilePath = this.taskCreateTime + "/AllDependency.csv";
        try (CSVReader reader = new CSVReader(new FileReader(csvFilePath))) {
            // 跳过标题行
            reader.readNext();
            String[] nextLine;
            while ((nextLine = reader.readNext()) != null) {
                if (nextLine.length > 0) {
                    String firstColumnValue = nextLine[0].trim();
                    String secondColumnValue = nextLine[1].trim();
                    String DirPath = this.taskCreateTime + "/Prompt/stage1/" + Stage2.combineElements(firstColumnValue,
                        secondColumnValue) + "/";
                    System.out.println(Stage2.combineElements(firstColumnValue, secondColumnValue));
                    for (int i = 1; ; i++) {
                        String stage1PromptFilePath = DirPath + String.valueOf(i) + ".txt";
                        if (!Stage2.isFileExist(stage1PromptFilePath)) {
                            System.out.println(stage1PromptFilePath + "不存在");
                            break;
                        }
                        String savePath = this.taskCreateTime + "/Prompt/stage2/" + Stage2.combineElements(
                            firstColumnValue, secondColumnValue) + "/" + String.valueOf(i) + ".txt";
                        Stage2 promptbuilder = new Stage2(this.taskCreateTime);
                        promptbuilder.path = i;
                        promptbuilder.PromptBulidAndSava2TXT(csvFilePath, secondColumnValue, savePath, i,
                            firstColumnValue);
                    }
                }
            }
        } catch (IOException | CsvValidationException e) {
            System.err.println("读取文件时发生错误: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void main(String[] args) throws IOException {
        String class_path = "/Users/chaiyuelin/Desktop/alimama/mergeV1_0/brand-onebp-domain/target/classes";
        String java_path = "/Users/chaiyuelin/Desktop/alimama/mergeV1_0/brand-onebp-domain/src/main/java/";
        String find_dependency_path = "/Users/chaiyuelin/Desktop/alimama/brand-bp-cyl/";
        String maven_repository = "/Users/chaiyuelin/.m2/repository/com/alibaba";
        String testoutputPath = "/Users/chaiyuelin/Desktop/alimama/brand-bp-cyl/brand-onebp-domain/src/test/java/";
        Starter starter = new Starter(class_path, java_path, find_dependency_path, maven_repository, testoutputPath);
        starter.run();
    }

}