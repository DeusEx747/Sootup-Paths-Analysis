package com.alibaba.ad.code;

import com.alibaba.Starter;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.IOException;

/**
 * Spring Mvc的根路径、健康检查等。
 */
@Controller
public class MainController {

    /**
     * 健康检查，系统部署需要
     * 请不要删除！！
     */
    @GetMapping("/checkpreload.htm")
    public @ResponseBody String checkPreload() {
        return "success";
    }

    @GetMapping("/")
    public String index(){
        return "index.html";
    }

    @GetMapping("/hsf")
    public String hsf() {
        return "hsf.html";
    }

    @GetMapping("/diamond")
    public String diamond() {
        return "diamond.html";
    }
    @GetMapping("/metaq")
    public String metaq() {
        return "metaq.html";
    }

    @PostMapping("/runStarter")
    public @ResponseBody String runStarter(
            @RequestParam("classPath") String classPath,
            @RequestParam("javaPath") String javaPath,
            @RequestParam("findDependencyPath") String findDependencyPath,
            @RequestParam("mavenRepository") String mavenRepository,
            @RequestParam("testoutputPath") String testoutputPath
    ) throws IOException {
        Starter starter = new Starter(classPath, javaPath, findDependencyPath, mavenRepository, testoutputPath);
        try {
            starter.run();
            return "Starter run completed successfully!";
        } catch (Exception e) {
            e.printStackTrace();
            return "Starter run failed: " + e.getMessage();
        }
    }
}

