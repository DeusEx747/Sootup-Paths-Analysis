package com.alibaba.controller;

import lombok.Data;

/**
 * @author nanfeng.jys
 * @date 2025/8/6 19:36
 * @description
 */
@Data
public class OssRequest {

    private String localFilePath;

    private String ossFilePath;

}
