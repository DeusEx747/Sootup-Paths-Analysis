package com.alibaba.ad.code.metaq;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;


/**
 * Metaq使用详情见 https://gitlab.alibaba-inc.com/middleware-container/pandora-boot/wikis/spring-boot-metaq
 */
@Controller
public class MetaqController {

    @Autowired
    private MessageSender messageSender;

    @ResponseBody
    @RequestMapping("/invoke/metaq")
    public String invokeMetaq(@RequestParam String message) throws Exception {
        StringBuilder result = new StringBuilder();
        // avoid xss vulnerability
        if (!message.matches("[a-zA-Z0-9 ]+")) {
            throw new IllegalArgumentException("message contains invalid characters.");
        }
        messageSender.sendMessage(message);
        return "send message: " + message + " successfully.";
    }
}

