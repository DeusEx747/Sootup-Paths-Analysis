# 源码自动生成模板 pandora-boot-initializr

### 概述

* 模板: pandora-boot-initializr
* 模板使用时间: 2025-07-15 10:19:50

### Docker
* Image: reg.docker.alibaba-inc.com/bootstrap2/pandora-boot
* Tag: 0.2
* SHA256: eb7881697d25310df646b4a2a4cf9bc53392274e2812eca4a8dffa289654c95c

### 用户输入参数
* bootVersion: "3.2.5" 
* date: "Tue 
* Jul: Jul 
* 15: 15 
* 2025": 2025" 
* repoUrl: "git@gitlab.alibaba-inc.com:air-code-research/ad-unit-test-generator.git" 
* ownerFullName: "琦域(261451)" 
* javaVersion: "21" 
* appName: "ad-unit-test-generator" 
* groupId: "com.alibaba.ad.code" 
* dockerfile: "dockerfile" 
* sarVersion: "2025-06-release-fix" 
* operator: "261451" 
* objectType: "Application" 
* ownerEmail: "qiyu.gl@taobao.com" 
* appId: "286581" 
* objectSubtype: "NORMAL" 
* artifactId: "ad-unit-test-generator" 
* style: "hsf,eagleeye,metaq,diamond" 
* applicationName: "ad-unit-test-generator" 

### 上下文参数
* appName: ad-unit-test-generator
* operator: 261451
* gitUrl: git@gitlab.alibaba-inc.com:air-code-research/ad-unit-test-generator.git
* branch: master


### 命令行
	sudo docker run --rm -v /home/admin/44_20250715101940988_560767420_code/ad-unit-test-generator/1752545980422_ad-unit-test-generator:/workspace -e bootVersion="3.2.5" -e date="Tue Jul 15 2025" -e repoUrl="git@gitlab.alibaba-inc.com:air-code-research/ad-unit-test-generator.git" -e ownerFullName="琦域(261451)" -e javaVersion="21" -e appName="ad-unit-test-generator" -e groupId="com.alibaba.ad.code" -e dockerfile="dockerfile" -e sarVersion="2025-06-release-fix" -e operator="261451" -e objectType="Application" -e ownerEmail="qiyu.gl@taobao.com" -e appId="286581" -e objectSubtype="NORMAL" -e artifactId="ad-unit-test-generator" -e style="hsf,eagleeye,metaq,diamond" -e applicationName="ad-unit-test-generator"  reg.docker.alibaba-inc.com/bootstrap2/pandora-boot:0.2

